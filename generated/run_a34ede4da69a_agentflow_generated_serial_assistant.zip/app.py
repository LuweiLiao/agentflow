"""
app.py — PyQt5 串口调试助手 GUI 层

基于 serial_core.py 实现，核心逻辑与 GUI 完全解耦。
支持 Mock 模式 (MOCK_SERIAL=1) 自测。

特性:
  - 端口选择 / 波特率 / 数据位 / 停止位 / 校验位
  - 打开 / 关闭串口
  - 发送文本 / HEX
  - 接收显示（时间戳可选）
  - 自动滚屏
  - 清空接收区
  - 保存日志

设计原则:
  1. QApplication 使用模块级变量强引用，支持 offscreen 测试
  2. 测试/Mock 模式下模态对话框替换为状态栏消息
  3. 空发送直接返回，不产生 TX 帧
  4. 串口接收在 QThread 中运行，通过信号回传数据
  5. import 时不会弹窗或阻塞
"""

from __future__ import annotations

import os
import sys
import time
from typing import List, Optional

# ── PyQt5 安全导入 ──
try:
    from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QThread
    from PyQt5.QtGui import QFont, QTextCursor
    from PyQt5.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QFileDialog,
        QGridLayout,
        QGroupBox,
        QHBoxLayout,
        QLabel,
        QMainWindow,
        QMessageBox,
        QPushButton,
        QStatusBar,
        QTextEdit,
        QVBoxLayout,
        QWidget,
    )
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False

from serial_core import (
    MockSerialBackend,
    SerialBackend,
    SerialFrame,
    SerialPortConfig,
    create_backend,
    format_log,
    hex_decode,
    hex_encode,
    is_empty_payload,
    make_frame,
    save_log,
)


# =========================================================================
# 全局 QApplication 管理（模块级变量保持强引用）
# =========================================================================

_qapp: Optional[QApplication] = None


def get_qapp() -> QApplication:
    """获取或创建 QApplication（模块级强引用，支持 offscreen 测试）

    测试时无需手动创建 QApplication，直接实例化 MainWindow 即可。
    """
    global _qapp
    if _qapp is None:
        _qapp = QApplication.instance()
        if _qapp is None:
            _qapp = QApplication(sys.argv)
    return _qapp


# =========================================================================
# 测试模式检测
# =========================================================================

def _is_test_mode() -> bool:
    """检测当前是否处于测试模式（弹窗应替换为状态栏消息）"""
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        return True
    if os.environ.get("MOCK_SERIAL") == "1":
        return True
    if "pytest" in sys.modules:
        return True
    return False


# =========================================================================
# 常量
# =========================================================================

BAUDRATES = ["9600", "19200", "38400", "57600", "115200", "256000"]
BYTESIZES = ["5", "6", "7", "8"]
STOPBITS = ["1", "1.5", "2"]
PARITIES = ["None", "Even", "Odd", "Mark", "Space"]
POLL_INTERVAL_MS = 50  # 接收轮询间隔（毫秒）


# =========================================================================
# SerialWorker — 后台接收线程
# =========================================================================

class SerialWorker(QThread):
    """串口接收工作线程

    在后台循环调用 backend.receive()，有数据时通过信号发射 SerialFrame。
    通过 stop() 方法安全退出循环。
    """

    data_received = pyqtSignal(object)  # SerialFrame
    error_occurred = pyqtSignal(str)

    def __init__(self, backend: SerialBackend, parent=None):
        super().__init__(parent)
        self.backend = backend
        self._running = False

    def run(self) -> None:
        """线程主循环"""
        self._running = True
        while self._running:
            if self.backend and self.backend.is_open():
                try:
                    data = self.backend.receive()
                    if data is not None and len(data) > 0:
                        frame = make_frame(data, "RX")
                        self.data_received.emit(frame)
                except Exception as e:
                    self.error_occurred.emit(str(e))
            self.msleep(POLL_INTERVAL_MS)

    def stop(self) -> None:
        """安全停止线程"""
        self._running = False
        self.wait(2000)


# =========================================================================
# MainWindow — 串口调试助手主窗口
# =========================================================================

class MainWindow(QMainWindow):
    """串口调试助手主窗口

    控件布局:
      ┌─ 串口配置区 ──────────────────────────────────────┐
      │ 端口: [ComboBox]  波特率: [ComboBox]  [刷新]       │
      │ 数据位: [ComboBox] 停止位: [ComboBox] 校验位: [CB] │
      │              [ 打开串口 ]                          │
      ├─ 发送区 ──────────────────────────────────────────┤
      │  [QTextEdit 多行输入]                              │
      │  ☐ HEX发送  [ 发送 ]                              │
      ├─ 接收区 ──────────────────────────────────────────┤
      │  [QTextEdit 只读显示]                              │
      │  ☐ 时间戳  ☐ 自动滚屏  [清空] [保存日志]          │
      └───────────────────────────────────────────────────┘
    """

    def __init__(self) -> None:
        if not PYQT5_AVAILABLE:
            raise ImportError("PyQt5 未安装，无法创建 GUI 窗口")

        super().__init__()
        self.setWindowTitle("串口调试助手")
        self.setMinimumSize(700, 550)

        # ── 后端与数据 ──
        self.backend: SerialBackend = create_backend()
        self.config: Optional[SerialPortConfig] = None
        self.records: List[SerialFrame] = []
        self.worker: Optional[SerialWorker] = None
        self._is_auto_scroll: bool = True
        self._is_open: bool = False

        # ── 初始化 UI（不依赖外部 QApplication 创建） ──
        self._init_ui()
        self._connect_signals()
        self._refresh_ports()

    # ─────────────── UI 构建 ───────────────

    def _init_ui(self) -> None:
        """构建完整 UI 布局"""
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(6)

        # ── 顶部：串口配置区 ──
        config_group = QGroupBox("串口配置")
        config_layout = QGridLayout(config_group)
        config_layout.setSpacing(4)

        # 行0：端口 + 波特率 + 刷新
        self.combo_port = QComboBox()
        self.combo_port.setMinimumWidth(140)
        self.combo_port.setToolTip("串口端口号")

        self.combo_baudrate = QComboBox()
        self.combo_baudrate.addItems(BAUDRATES)
        self.combo_baudrate.setCurrentText("115200")

        self.btn_refresh = QPushButton("刷新")
        self.btn_refresh.setToolTip("刷新串口列表")
        self.btn_refresh.setFixedWidth(60)

        config_layout.addWidget(QLabel("端口:"), 0, 0)
        config_layout.addWidget(self.combo_port, 0, 1)
        config_layout.addWidget(QLabel("波特率:"), 0, 2)
        config_layout.addWidget(self.combo_baudrate, 0, 3)
        config_layout.addWidget(self.btn_refresh, 0, 4)

        # 行1：数据位 + 停止位 + 校验位
        self.combo_bytesize = QComboBox()
        self.combo_bytesize.addItems(BYTESIZES)
        self.combo_bytesize.setCurrentText("8")

        self.combo_stopbits = QComboBox()
        self.combo_stopbits.addItems(STOPBITS)
        self.combo_stopbits.setCurrentText("1")

        self.combo_parity = QComboBox()
        self.combo_parity.addItems(PARITIES)
        self.combo_parity.setCurrentText("None")

        config_layout.addWidget(QLabel("数据位:"), 1, 0)
        config_layout.addWidget(self.combo_bytesize, 1, 1)
        config_layout.addWidget(QLabel("停止位:"), 1, 2)
        config_layout.addWidget(self.combo_stopbits, 1, 3)
        config_layout.addWidget(QLabel("校验位:"), 1, 4)
        config_layout.addWidget(self.combo_parity, 1, 5)

        # 行2：打开/关闭按钮
        self.btn_open = QPushButton("打开串口")
        self.btn_open.setMinimumHeight(32)
        self.btn_open.setStyleSheet("font-weight: bold;")
        config_layout.addWidget(self.btn_open, 2, 0, 1, 6)

        layout.addWidget(config_group)

        # ── 发送区 ──
        send_group = QGroupBox("发送区")
        send_layout = QVBoxLayout(send_group)

        self.text_send = QTextEdit()
        self.text_send.setPlaceholderText("输入要发送的数据...")
        self.text_send.setMaximumHeight(100)
        self.text_send.setAcceptRichText(False)

        send_ctl_layout = QHBoxLayout()
        self.check_hex_send = QCheckBox("HEX 发送")
        self.btn_send = QPushButton("发送")
        self.btn_send.setMinimumWidth(100)
        self.btn_send.setEnabled(False)

        send_ctl_layout.addWidget(self.check_hex_send)
        send_ctl_layout.addStretch()
        send_ctl_layout.addWidget(self.btn_send)

        send_layout.addWidget(self.text_send)
        send_layout.addLayout(send_ctl_layout)
        layout.addWidget(send_group)

        # ── 接收区 ──
        recv_group = QGroupBox("接收区")
        recv_layout = QVBoxLayout(recv_group)

        self.text_recv = QTextEdit()
        self.text_recv.setReadOnly(True)
        self.text_recv.setFont(QFont("Courier New", 10))

        recv_ctl_layout = QHBoxLayout()
        self.check_timestamp = QCheckBox("时间戳")
        self.check_timestamp.setChecked(True)
        self.check_autoscroll = QCheckBox("自动滚屏")
        self.check_autoscroll.setChecked(True)
        self.btn_clear = QPushButton("清空")
        self.btn_save_log = QPushButton("保存日志")

        recv_ctl_layout.addWidget(self.check_timestamp)
        recv_ctl_layout.addWidget(self.check_autoscroll)
        recv_ctl_layout.addStretch()
        recv_ctl_layout.addWidget(self.btn_clear)
        recv_ctl_layout.addWidget(self.btn_save_log)

        recv_layout.addWidget(self.text_recv)
        recv_layout.addLayout(recv_ctl_layout)
        layout.addWidget(recv_group)

        # ── 状态栏 ──
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪")

        # ── 存储用于测试的控件引用 ──
        self._controls = {
            "combo_port": self.combo_port,
            "combo_baudrate": self.combo_baudrate,
            "combo_bytesize": self.combo_bytesize,
            "combo_stopbits": self.combo_stopbits,
            "combo_parity": self.combo_parity,
            "btn_open": self.btn_open,
            "btn_refresh": self.btn_refresh,
            "btn_send": self.btn_send,
            "btn_clear": self.btn_clear,
            "btn_save_log": self.btn_save_log,
            "text_send": self.text_send,
            "text_recv": self.text_recv,
            "check_hex_send": self.check_hex_send,
            "check_timestamp": self.check_timestamp,
            "check_autoscroll": self.check_autoscroll,
        }

    # ─────────────── 信号连接 ───────────────

    def _connect_signals(self) -> None:
        """连接控件信号与槽函数"""
        self.btn_open.clicked.connect(self._on_open_close)
        self.btn_refresh.clicked.connect(self._refresh_ports)
        self.btn_send.clicked.connect(self._on_send)
        self.btn_clear.clicked.connect(self._on_clear)
        self.btn_save_log.clicked.connect(self._on_save_log)
        self.check_autoscroll.toggled.connect(self._on_auto_scroll_toggled)

    # ─────────────── 串口号刷新 ───────────────

    def _refresh_ports(self) -> None:
        """刷新串口列表"""
        current = self.combo_port.currentText()
        self.combo_port.clear()
        try:
            ports = self.backend.list_ports()
            for p in ports:
                self.combo_port.addItem(p)
        except Exception:
            pass
        # 恢复选中的端口
        idx = self.combo_port.findText(current)
        if idx >= 0:
            self.combo_port.setCurrentIndex(idx)
        elif self.combo_port.count() > 0:
            self.combo_port.setCurrentIndex(0)

    # ─────────────── 打开/关闭串口 ───────────────

    def _on_open_close(self) -> None:
        """打开或关闭串口（按钮状态联动）"""
        if self._is_open:
            self._close_serial()
        else:
            self._open_serial()

    def _open_serial(self) -> None:
        """打开串口"""
        port = self.combo_port.currentText().strip()
        if not port:
            self._show_message("请选择串口端口")
            return

        # 从控件读取配置
        try:
            baudrate = int(self.combo_baudrate.currentText())
            bytesize = int(self.combo_bytesize.currentText())
            stopbits = float(self.combo_stopbits.currentText())
            parity = self.combo_parity.currentText()
        except ValueError:
            self._show_message("参数格式错误")
            return

        config = SerialPortConfig(
            port=port,
            baudrate=baudrate,
            bytesize=bytesize,
            parity=parity,
            stopbits=stopbits,
            timeout=0.5,
        )

        # 校验配置
        ok, err = config.validate()
        if not ok:
            self._show_message(f"配置校验失败: {err}")
            return

        # 尝试打开
        try:
            success = self.backend.open(config)
        except Exception as e:
            self._show_message(f"打开串口失败: {e}")
            return

        if not success:
            self._show_message(f"无法打开串口 {port}")
            return

        self.config = config
        self._is_open = True
        self.btn_open.setText("关闭串口")
        self.btn_open.setStyleSheet("font-weight: bold; color: red;")
        self.btn_send.setEnabled(True)
        self._update_port_controls_enabled(False)
        self.status_bar.showMessage(f"串口已打开: {port}  {baudrate} {bytesize}{parity[0]}{int(stopbits)}")

        # 启动接收线程
        self._start_worker()

    def _close_serial(self) -> None:
        """关闭串口"""
        self._stop_worker()

        try:
            self.backend.close()
        except Exception:
            pass

        self._is_open = False
        self.config = None
        self.btn_open.setText("打开串口")
        self.btn_open.setStyleSheet("font-weight: bold; color: black;")
        self.btn_send.setEnabled(False)
        self._update_port_controls_enabled(True)
        self.status_bar.showMessage("串口已关闭")

    def _update_port_controls_enabled(self, enabled: bool) -> None:
        """更新串口配置控件的启用状态"""
        self.combo_port.setEnabled(enabled)
        self.combo_baudrate.setEnabled(enabled)
        self.combo_bytesize.setEnabled(enabled)
        self.combo_stopbits.setEnabled(enabled)
        self.combo_parity.setEnabled(enabled)
        self.btn_refresh.setEnabled(enabled)

    # ─────────────── 接收线程管理 ───────────────

    def _start_worker(self) -> None:
        """启动接收工作线程"""
        if self.worker is not None and self.worker.isRunning():
            self.worker.stop()
        self.worker = SerialWorker(self.backend)
        self.worker.data_received.connect(self._on_receive)
        self.worker.error_occurred.connect(lambda e: self._show_message(f"接收错误: {e}"))
        self.worker.start()

    def _stop_worker(self) -> None:
        """停止接收工作线程"""
        if self.worker is not None:
            self.worker.stop()
            self.worker = None

    # ─────────────── 接收数据处理 ───────────────

    def _on_receive(self, frame: SerialFrame) -> None:
        """处理接收到的数据帧（在主线程执行）"""
        self.records.append(frame)
        self._update_receive_display(frame)

    def _update_receive_display(self, frame: SerialFrame) -> None:
        """将帧内容追加到接收显示区"""
        if self.check_timestamp.isChecked():
            from serial_core import _format_timestamp
            ts = _format_timestamp(frame.timestamp)
            line = f"{ts} RX: {frame.hex_str}    {frame.text_str}\n"
        else:
            line = f"RX: {frame.hex_str}    {frame.text_str}\n"

        self.text_recv.moveCursor(QTextCursor.End)
        self.text_recv.insertPlainText(line)

        if self.check_autoscroll.isChecked():
            self.text_recv.moveCursor(QTextCursor.End)

    # ─────────────── 发送数据 ───────────────

    def _on_send(self) -> None:
        """发送数据（文本或 HEX）"""
        if not self._is_open:
            self._show_message("串口未打开，无法发送")
            return

        text = self.text_send.toPlainText()
        if not text or text.strip() == "":
            # 空发送直接返回，不产生 TX 帧
            return

        try:
            if self.check_hex_send.isChecked():
                # HEX 发送
                data = hex_decode(text.strip())
            else:
                # 文本发送
                data = text.encode("utf-8")
        except ValueError as e:
            self._show_message(f"HEX 格式错误: {e}")
            return

        if is_empty_payload(data):
            return

        # 发送
        try:
            sent_len = self.backend.send(data)
        except Exception as e:
            self._show_message(f"发送失败: {e}")
            return

        if sent_len > 0:
            # 记录 TX 帧
            frame = make_frame(data[:sent_len], "TX")
            self.records.append(frame)
            self._update_send_display(frame)
            self.status_bar.showMessage(f"已发送 {sent_len} 字节")

    def _update_send_display(self, frame: SerialFrame) -> None:
        """在接收区显示发送的帧（回显）"""
        if self.check_timestamp.isChecked():
            from serial_core import _format_timestamp
            ts = _format_timestamp(frame.timestamp)
            line = f"{ts} TX: {frame.hex_str}    {frame.text_str}\n"
        else:
            line = f"TX: {frame.hex_str}    {frame.text_str}\n"

        self.text_recv.moveCursor(QTextCursor.End)
        self.text_recv.insertPlainText(line)

        if self.check_autoscroll.isChecked():
            self.text_recv.moveCursor(QTextCursor.End)

    # ─────────────── 清空接收区 ───────────────

    def _on_clear(self) -> None:
        """清空接收区和记录"""
        self.text_recv.clear()
        self.records.clear()
        self.status_bar.showMessage("接收区已清空")

    # ─────────────── 保存日志 ───────────────

    def _on_save_log(self) -> None:
        """保存日志到文件"""
        if not self.records:
            self._show_message("没有日志可保存")
            return

        if _is_test_mode():
            # 测试模式：直接写入固定路径，不弹对话框
            filepath = "test_log_output.txt"
            success = save_log(filepath, self.records, include_timestamp=self.check_timestamp.isChecked())
            if success:
                self.status_bar.showMessage(f"日志已保存到 {filepath}")
                # 记录路径到属性，供测试断言
                self._last_log_path = filepath
            else:
                self.status_bar.showMessage("保存日志失败")
            return

        # 正常模式：弹出文件保存对话框
        filepath, _ = QFileDialog.getSaveFileName(
            self, "保存日志", "serial_log.txt", "文本文件 (*.txt);;所有文件 (*)"
        )
        if not filepath:
            return

        success = save_log(filepath, self.records, include_timestamp=self.check_timestamp.isChecked())
        if success:
            self.status_bar.showMessage(f"日志已保存到 {filepath}")
        else:
            self._show_message(f"保存日志失败: {filepath}")

    # ─────────────── 自动滚屏 ───────────────

    def _on_auto_scroll_toggled(self, checked: bool) -> None:
        """自动滚屏开关"""
        self._is_auto_scroll = checked

    # ─────────────── 消息提示（测试友好） ───────────────

    def _show_message(self, text: str) -> None:
        """显示消息

        测试模式下使用状态栏，非测试模式使用 QMessageBox。
        """
        if _is_test_mode():
            self.status_bar.showMessage(text)
            # 将最近消息记录到属性，供测试断言
            self._last_message = text
        else:
            QMessageBox.warning(self, "提示", text)

    # ─────────────── 窗口关闭事件 ───────────────

    def closeEvent(self, event) -> None:
        """关闭窗口时清理资源"""
        self._stop_worker()
        if self._is_open:
            try:
                self.backend.close()
            except Exception:
                pass
        super().closeEvent(event)


# =========================================================================
# 入口（仅在作为主程序运行时执行）
# =========================================================================

def main() -> None:
    """应用入口函数"""
    if not PYQT5_AVAILABLE:
        print("错误: PyQt5 未安装，请先安装依赖: pip install PyQt5", file=sys.stderr)
        sys.exit(1)

    app = get_qapp()
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
