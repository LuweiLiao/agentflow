# PyQt 串口调试助手 — 架构设计文档 (ARCHITECTURE.md)

---

## 修订历史

| 版本 | 日期 | 描述 | 作者 |
|------|------|------|------|
| v1.0 | 2025-07 | 初版架构设计 | design-agent |

---

## 一、总体架构概览

### 1.1 三层架构

```
┌──────────────────────────────────────────────────────────┐
│                     GUI 层 (View)                         │
│                    serial_gui.py                         │
│   MainWindow(QMainWindow)  ←控制→  WorkerThread(QThread) │
│                                                          │
│  控件: QComboBox / QTextEdit / QPushButton / QCheckBox   │
│  信号/槽: pyqtSignal → 主线程 safe update                │
└──────────────────────┬───────────────────────────────────┘
                       │ 调用 Backend 接口
                       ▼
┌──────────────────────────────────────────────────────────┐
│                 核心逻辑层 (Model/Controller)              │
│                   serial_core.py                         │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────┐ │
│  │SerialPortConfig│  │ SerialFrame   │  │HEX编解码/日志  │ │
│  │  (数据类+校验) │  │  (数据帧)     │  │格式化工具函数  │ │
│  └──────┬───────┘  └──────┬───────┘  └───────┬────────┘ │
│         │                  │                   │          │
│         ▼                  ▼                   ▼          │
│  ┌────────────────────────────────────────────────────┐  │
│  │              Backend 抽象层                         │  │
│  │          SerialBackend (ABC)                       │  │
│  │    open/close/send/receive/is_open/list_ports      │  │
│  └────────────┬───────────────────────┬──────────────┘  │
│               │                       │                  │
│       ┌───────▼───────┐       ┌──────▼────────┐         │
│       │RealSerialBackend│      │MockSerialBackend│        │
│       │  (pyserial)    │      │  (内存队列)    │         │
│       └───────────────┘       └───────────────┘         │
└──────────────────────┬───────────────────────────────────┘
                       │  pytest 测试覆盖
                       ▼
┌──────────────────────────────────────────────────────────┐
│                   测试层 (Tests)                          │
│                                                          │
│  test_serial_core.py  ← 核心逻辑单元测试 (TC01~TC20)     │
│  test_serial_gui.py   ← GUI smoke 测试 (TC21~TC25)       │
│                                                          │
│  测试工具: pytest + unittest.mock + offscreen QPA        │
└──────────────────────────────────────────────────────────┘
```

### 1.2 技术选型与理由

| 技术 | 选型理由 |
|------|----------|
| **PyQt5** | 成熟、跨平台的 Qt 绑定，文档丰富，控件齐全（QComboBox/QTextEdit 等） |
| **pyserial** | 业界标准串口库，跨平台统一接口，支持超时/奇偶校验等全部需求 |
| **pytest** | 轻量但强大的测试框架，fixture 机制便于 Mock，assert 更直观 |
| **unittest.mock** | Python 内置，零依赖，可 patch 外部依赖 |
| **dataclasses** | Python 3.7+ 内置，零开销数据容器，自带 `__repr__`/`__eq__` |
| **abc (Abstract Base Class)** | 定义 Backend 契约接口，保证 Real/Mock 互换性 |

### 1.3 架构原则

1. **核心逻辑零依赖**：`serial_core.py` 仅使用 Python 标准库（dataclasses, abc, time, typing），不依赖 PyQt5 或 pyserial
2. **依赖反转**：GUI 通过抽象接口 `SerialBackend` 操作串口，不直接引用 pyserial
3. **环境切换**：`MOCK_SERIAL=1` 环境变量决定使用 Real 还是 Mock Backend
4. **线程隔离**：串口接收在 QThread 中运行，通过 pyqtSignal 回传数据
5. **闭环可测试**：所有核心逻辑函数均可脱离 GUI 单独单元测试

---

## 二、文件结构与职责

### 2.1 完整文件树

```
├── ARCHITECTURE.md         # 本架构文档
├── SPEC.md                 # 规格细化文档 (PRD + 验收清单 + 测试矩阵)
├── serial_core.py          # 核心逻辑层 (~300行)
├── serial_gui.py           # GUI 层 (~450行)
├── test_serial_core.py     # 核心逻辑单元测试 (~250行)
├── test_serial_gui.py      # GUI smoke 测试 (~100行)
├── requirements.txt        # Python 依赖清单
└── run.sh                  # 一键运行脚本 (挂载 MOCK_SERIAL=1)
```

### 2.2 各文件职责边界

| 文件 | 职责 | 依赖 | 可脱离 GUI 测试? |
|------|------|------|:---:|
| `serial_core.py` | 数据模型、校验、编解码、日志、Backend 接口与实现 | 仅 Python 标准库 | ✅ |
| `serial_gui.py` | 窗口布局、控件事件、线程管理、信号/槽绑定 | PyQt5 + serial_core | ❌ (需 offscreen) |
| `test_serial_core.py` | 覆盖 TC01~TC20 全部核心逻辑测试 | pytest + serial_core | ✅ |
| `test_serial_gui.py` | 覆盖 TC21~TC25 GUI smoke 测试 | pytest + PyQt5 + serial_gui | N/A |

---

## 三、核心逻辑层详细设计 (serial_core.py)

### 3.1 `SerialPortConfig` — 串口参数配置

```python
@dataclass(frozen=True)
class SerialPortConfig:
    """串口参数配置（不可变数据类）"""
    port: str          # 端口名，如 "COM3" 或 "/dev/ttyUSB0"
    baudrate: int = 115200
    bytesize: int = 8
    parity: str = "None"
    stopbits: float = 1.0
    timeout: float = 1.0

    # 合法值常量
    VALID_BAUDRATES = {9600, 19200, 38400, 57600, 115200, 256000}
    VALID_BYTESIZES = {5, 6, 7, 8}
    VALID_PARITIES = {"None", "Even", "Odd", "Mark", "Space"}
    VALID_STOPBITS = {1, 1.5, 2}
```

**方法**:
- `validate() -> tuple[bool, str]` — 校验所有参数，返回 `(是否合法, 错误信息)`
  - `port` 不能为空字符串（strip 后为空也视为空）
  - `baudrate` 必须在 `VALID_BAUDRATES` 中
  - `bytesize` 必须在 `VALID_BYTESIZES` 中
  - `parity` 必须在 `VALID_PARITIES` 中
  - `stopbits` 必须在 `VALID_STOPBITS` 中（注意 float 比较容差）
- `to_dict() -> dict` — 转为字典，方便传给 pyserial

### 3.2 `SerialFrame` — 数据帧

```python
@dataclass
class SerialFrame:
    """统一数据帧"""
    timestamp: float       # time.time() 时间戳
    direction: str         # "TX" 或 "RX"
    raw_data: bytes        # 原始字节
    hex_str: str           # 如 "48 65 6C 6C 6F"
    text_str: str          # 可打印字符保留，不可打印替换为 '.'
```

**工厂函数**:
- `make_frame(data: bytes, direction: str) -> SerialFrame` — 从原始字节构造帧，自动生成 hex_str 和 text_str

### 3.3 HEX 编解码模块

```python
def hex_encode(data: bytes) -> str:
    """字节 → 空格分隔大写HEX字符串
    >>> hex_encode(b"Hello")
    '48 65 6C 6C 6F'
    """
    return " ".join(f"{b:02X}" for b in data)


def hex_decode(hex_str: str) -> bytes:
    """HEX字符串 → 字节
    支持格式: "48 65", "4865", "48\\t65", "48\\n65"
    非法输入(含非HEX字符/奇数长度)抛出 ValueError
    """
    # 1. 去除空白字符
    # 2. 检查是否只含合法HEX字符 [0-9A-Fa-f]
    # 3. 检查长度是否为偶数
    # 4. 使用 bytes.fromhex() 解码
```

### 3.4 日志格式化模块

```python
def format_frame(frame: SerialFrame, include_timestamp: bool = True) -> str:
    """格式化单帧为日志行
    include_timestamp=True:  "[10:30:45.123] TX: 48 65 6C 6C 6F"
    include_timestamp=False: "TX: 48 65 6C 6C 6F"
    """

def format_log(records: list[SerialFrame], include_timestamp: bool = True) -> str:
    """格式化多帧日志"""

def save_log(filepath: str, records: list[SerialFrame],
             include_timestamp: bool = True) -> bool:
    """保存日志到文件，成功返回 True"""
```

### 3.5 `SerialBackend` — 抽象基类

```python
class SerialBackend(ABC):
    """串口后端抽象接口"""

    @abstractmethod
    def open(self, config: SerialPortConfig) -> bool: ...

    @abstractmethod
    def close(self) -> bool: ...

    @abstractmethod
    def send(self, data: bytes) -> int: ...

    @abstractmethod
    def receive(self) -> bytes | None: ...

    @abstractmethod
    def is_open(self) -> bool: ...

    @staticmethod
    @abstractmethod
    def list_ports() -> list[str]: ...
```

### 3.6 `MockSerialBackend` — 模拟后端

```python
class MockSerialBackend(SerialBackend):
    """内存模拟串口，支持回显和预设接收数据"""

    def __init__(self):
        self._is_open = False
        self._tx_buffer: list[bytes] = []   # 发送历史
        self._rx_queue: deque[bytes] = ...  # 预设接收队列
        self._echo_mode: bool = True        # 默认回显模式

    def open(self, config: SerialPortConfig) -> bool:
        # 忽略 config，直接标记为已打开
        ...

    def close(self) -> bool:
        ...

    def send(self, data: bytes) -> int:
        # 记录到 tx_buffer
        # 如果 echo_mode，自动回填 rx_queue
        ...

    def receive(self) -> bytes | None:
        # 从 rx_queue 弹出（带超时模拟）
        ...

    def is_open(self) -> bool:
        ...

    @staticmethod
    def list_ports() -> list[str]:
        return ["MOCK_COM1", "MOCK_COM2"]
```

### 3.7 `RealSerialBackend` — 真实后端

```python
class RealSerialBackend(SerialBackend):
    """基于 pyserial 的真实串口实现"""

    def __init__(self):
        self._serial: serial.Serial | None = None

    def open(self, config: SerialPortConfig) -> bool:
        # 用 pyserial.Serial 打开端口
        ...

    def close(self) -> bool:
        ...

    def send(self, data: bytes) -> int:
        # serial.write(data)
        ...

    def receive(self) -> bytes | None:
        # serial.read(size) 或 read_until
        # 超时返回 None
        ...

    def is_open(self) -> bool:
        ...

    @staticmethod
    def list_ports() -> list[str]:
        # serial.tools.list_ports.comports()
        ...
```

### 3.8 后端工厂函数

```python
def create_backend() -> SerialBackend:
    """根据环境变量 MOCK_SERIAL 创建对应的后端实例"""
    if os.environ.get("MOCK_SERIAL") == "1":
        return MockSerialBackend()
    try:
        import serial  # noqa
        return RealSerialBackend()
    except ImportError:
        print("警告: pyserial 未安装，使用 MockSerialBackend")
        return MockSerialBackend()
```

---

## 四、GUI 层详细设计 (serial_gui.py)

### 4.1 MainWindow 类结构

```python
class MainWindow(QMainWindow):
    """主窗口，负责所有控件布局与事件处理"""

    # 自定义信号
    data_received = pyqtSignal(object)  # SerialFrame

    def __init__(self):
        super().__init__()
        self.backend = create_backend()       # 后端实例
        self.config = SerialPortConfig()      # 当前配置
        self.records: list[SerialFrame] = []  # 所有收发记录
        self._init_ui()                       # 布局控件
        self._connect_signals()               # 绑定信号/槽
        self._refresh_ports()                 # 刷新端口列表
```

### 4.2 控件布局 (使用 QVBoxLayout/QHBoxLayout 组合)

```
┌──────────────────────────────────────────────────────────────┐
│  [端口: ┌──────────┐] [波特率: ┌──────────┐] [刷新]         │
│  [数据位: ┌──┐] [停止位: ┌──┐] [校验位: ┌──────┐]           │
│  [         打开串口         ]  ← QPushButton                 │
├──────────────────────────────────────────────────────────────┤
│  ┌─ 发送区 ───────────────────────────────────────────────┐  │
│  │ [QTextEdit 多行输入框]                                 │  │
│  │                                                        │  │
│  │ ☐ HEX发送    [         发送          ]                 │  │
│  └────────────────────────────────────────────────────────┘  │
├──────────────────────────────────────────────────────────────┤
│  ┌─ 接收区 ───────────────────────────────────────────────┐  │
│  │ [QTextEdit 只读显示]                                   │  │
│  │                                                        │  │
│  │ ☐ 时间戳  ☐ 自动滚屏  [清空] [保存日志]                │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

### 4.3 信号/槽绑定

| 控件事件 | 处理函数 | 说明 |
|----------|----------|------|
| 打开/关闭按钮 clicked | `toggle_serial()` | 根据当前状态打开或关闭 |
| 发送按钮 clicked | `send_data()` | 获取发送区内容，根据 HEX 勾选编码发送 |
| 清空按钮 clicked | `clear_receive()` | 清空接收区 QTextEdit |
| 保存日志按钮 clicked | `save_log()` | QFileDialog 选路径后保存 |
| data_received 信号 | `on_data_received(frame)` | 主线程更新接收区显示 |
| 端口 ComboBox currentTextChanged | — | 更新 config.port |

### 4.4 接收线程管理

```python
class SerialWorker(QThread):
    """后台接收线程"""
    frame_received = pyqtSignal(object)  # SerialFrame

    def __init__(self, backend: SerialBackend):
        super().__init__()
        self.backend = backend
        self._running = False

    def run(self):
        """循环读取，直到停止"""
        self._running = True
        while self._running:
            data = self.backend.receive()
            if data and len(data) > 0:
                frame = make_frame(data, "RX")
                self.frame_received.emit(frame)
            self.msleep(10)  # 10ms 轮询间隔

    def stop(self):
        self._running = False
```

### 4.5 关键方法逻辑

**`toggle_serial()`**:
1. 如果当前关闭 → 读取配置 → config.validate() → 验证通过则 backend.open()
2. 如果当前打开 → backend.close() → worker.stop() → 等待线程结束
3. 更新按钮文字 ("打开串口" ↔ "关闭串口")
4. 更新端口 ComboBox 的 enabled 状态

**`send_data()`**:
1. 获取 QTextEdit 文本内容
2. 如果为空 → 直接返回
3. 如果勾选 HEX → hex_decode(文本) → 若抛出 ValueError → QMessageBox.warning
4. 如果未勾选 HEX → 文本.encode("utf-8")
5. backend.send(data)
6. 构造 SerialFrame 并追加到 records，更新发送区显示（可选）

**`on_data_received(frame)`**:
1. records.append(frame)
2. 根据时间戳勾选状态，format_frame 生成显示行
3. 追加到接收区 QTextEdit
4. 如果勾选自动滚屏 → 滚动到底部

---

## 五、测试层详细设计

### 5.1 测试文件组织

```
test_serial_core.py  -- 20 个测试用例 (TC01~TC20)
  ├── TestSerialPortConfig   (TC01~TC05)
  ├── TestHexCodec           (TC06~TC10)
  ├── TestSerialFrame        (TC13~TC15)
  ├── TestSendReceive        (TC11~TC12, TC19~TC20)
  └── TestLogFormat          (TC16~TC18)

test_serial_gui.py   -- 5 个测试用例 (TC21~TC25)
  ├── TestImport             (TC21)
  ├── TestClassExists        (TC22)
  ├── TestOffscreenCreate    (TC23)
  ├── TestControls           (TC24)
  └── TestMockImport         (TC25)
```

### 5.2 测试策略

**核心逻辑测试** (独立于 GUI)：
- 直接 import `serial_core` 中的函数/类
- 使用 `pytest.raises` 验证异常
- 使用 `assert` 验证返回值
- MockSerialBackend 直接在测试中实例化使用

**GUI 测试** (offscreen 模式)：
- 设置 `QT_QPA_PLATFORM=offscreen` 环境变量
- 使用 `QApplication([])` 在测试中创建应用实例
- 验证控件存在性、信号绑定、不验证渲染效果
- Mock 模式下验证无真实串口也能正常运行

### 5.3 测试用例与核心逻辑映射

| 测试用例 | 覆盖代码 | 测试方式 |
|----------|----------|----------|
| TC01 | `SerialPortConfig.validate()` 合法参数 | assert True |
| TC02~TC05 | `SerialPortConfig.validate()` 非法参数 | assert False |
| TC06~TC10 | `hex_encode()` / `hex_decode()` | assert 相等 / pytest.raises |
| TC11~TC12 | `MockSerialBackend.send()` + 发送逻辑 | assert buffer 内容 |
| TC13~TC15 | `SerialFrame` / `make_frame()` | assert 字段值 |
| TC16~TC18 | `format_log()` / `save_log()` | assert 字符串 / 文件存在 |
| TC19~TC20 | `MockSerialBackend` 全生命周期 | assert 状态 + 回显内容 |
| TC21~TC25 | GUI import / 类存在 / 窗口创建 | 无异常 / 无崩溃 |

---

## 六、闭环反馈流程 (AgentFlow 编排)

### 6.1 流程拓扑

```
┌──────────┐    ┌──────────┐    ┌──────────┐
│  开发节点  │───→│  测试节点  │───→│  审查节点  │
│  (generate)│   │  (pytest) │   │ (quality) │
└─────┬────┘    └─────┬────┘    └─────┬────┘
      │ 失败          │ 失败          │ 失败
      └───────────────┴───────────────┘
                feedback_history
```

### 6.2 feedback_history 数据结构

```json
{
  "feedback_history": [
    {
      "round": 1,
      "source": "test_node",
      "failures": [
        {
          "test": "TC03",
          "type": "AssertionError",
          "detail": "assert validate(baudrate=12345) == False, got True",
          "location": "test_serial_core.py::TestSerialPortConfig::test_invalid_baudrate"
        }
      ],
      "summary": "2/20 测试失败：TC03 非法波特率校验未通过, TC09 奇数长度 HEX 未抛出异常"
    },
    {
      "round": 2,
      "source": "review_node",
      "failures": [
        {
          "check": "keyword_check",
          "detail": "SPEC.md 中缺少关键词 '闭环'",
          "location": "SPEC.md"
        }
      ],
      "summary": "审查失败：关键词缺失"
    }
  ]
}
```

### 6.3 节点间合约

| 节点 | 输入 | 输出 | 失败时 |
|------|------|------|--------|
| 开发节点 (n3_develop) | `SPEC.md`, `ARCHITECTURE.md`, `feedback_history` | 源文件 (serial_core.py, serial_gui.py, test_*.py 等) | — |
| 测试节点 (n4_test) | 源文件 | pytest 结果 | 收集失败断言/traceback → feedback |
| 审查节点 (n5_review) | 源文件 + 测试结果 | 审查报告 | 收集缺失项 → feedback |

### 6.4 质量门禁

测试节点和审查节点各自独立验证，只要其中一个失败，就构造 feedback_history 返回开发节点。开发节点读取 feedback_history 后：

1. 解析每轮失败的具体证据（断言信息、行号、异常类型）
2. 定位到对应源代码
3. 修改后重新提交
4. 在 feedback_history 中追加新一轮记录

最多循环 3 轮，超过则标记为 FAILED。

---

## 七、模块依赖关系图

```
serial_core.py (零外部依赖)
├── dataclasses (stdlib)
├── abc (stdlib)
├── time (stdlib)
├── typing (stdlib)
├── os (stdlib)
├── collections.deque (stdlib)
└── struct (stdlib) [可选，用于字节处理]

serial_gui.py
├── PyQt5.QtWidgets
├── PyQt5.QtCore (QThread, pyqtSignal, Qt)
├── PyQt5.QtGui (QFont)
└── serial_core (同目录)

test_serial_core.py
├── pytest
├── serial_core
└── tempfile / pathlib (stdlib) [用于日志测试]

test_serial_gui.py
├── pytest
├── PyQt5.QtWidgets (QApplication)
└── serial_gui
```

---

## 八、关键设计决策 (ADR)

### ADR-1: 为什么用 `@dataclass(frozen=True)` 而非普通类？

**决定**：使用不可变数据类。
**理由**：
- 串口参数配置应是值对象，创建后不应修改
- 不可变对象天然线程安全
- 自动生成 `__init__`/`__repr__`/`__eq__`/`__hash__`
- 可在 GUI 中安全地作为信号参数传递

### ADR-2: 为什么接收线程用 QThread 而非 threading.Thread？

**决定**：使用 QThread。
**理由**：
- 需要 pyqtSignal 直接发射到主线程
- QThread 生命周期可由主窗口管理
- 子类化 QThread 比 moveToThread 模式更直观

### ADR-3: 为什么 RealSerialBackend 放在 serial_core.py 而非单独文件？

**决定**：放在同一文件中。
**理由**：
- 代码量不大（~80 行）
- RealSerialBackend 和 MockSerialBackend 共享同一抽象接口，放在一起便于对照
- 减少文件数量，降低闭环传递复杂度

### ADR-4: 为什么 validate() 返回 tuple 而非抛出异常？

**决定**：返回 `(bool, str)`。
**理由**：
- GUI 需要区分"校验失败"和"程序异常"
- 纯函数无副作用，便于测试
- 调用方可自行决定如何处理（GUI 弹窗 / 测试 assert）

---

## 九、附录：接口速查表

| 接口 | 签名 | 返回值 |
|------|------|--------|
| `SerialPortConfig.validate()` | `(self) -> tuple[bool, str]` | `(True, "")` 或 `(False, "错误信息")` |
| `hex_encode(data)` | `(bytes) -> str` | 空格分隔大写 HEX |
| `hex_decode(s)` | `(str) -> bytes` | 解码后字节 / 抛出 ValueError |
| `make_frame(data, dir)` | `(bytes, str) -> SerialFrame` | 完整帧对象 |
| `format_frame(frame, ts)` | `(SerialFrame, bool) -> str` | 格式化行 |
| `format_log(records, ts)` | `(list[SerialFrame], bool) -> str` | 多行字符串 |
| `save_log(path, records, ts)` | `(str, list, bool) -> bool` | 成功 True/失败 False |
| `create_backend()` | `() -> SerialBackend` | Mock 或 Real 实例 |
| `backend.open(config)` | `(SerialPortConfig) -> bool` | 成功 True/失败 False |
| `backend.close()` | `() -> bool` | 成功 True |
| `backend.send(data)` | `(bytes) -> int` | 发送字节数 |
| `backend.receive()` | `() -> bytes / None` | 数据或 None |
| `backend.is_open()` | `() -> bool` | 状态 |
| `backend.list_ports()` | `() -> list[str]` | 端口列表 |

---

*本文档由 design Agent 生成，与 SPEC.md 配套使用，作为后续开发节点的核心参考。*
