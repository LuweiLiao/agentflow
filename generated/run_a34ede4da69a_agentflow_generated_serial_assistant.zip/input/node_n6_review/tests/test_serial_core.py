"""
test_serial_core.py — 核心逻辑单元测试

覆盖 TC01~TC20 全部测试用例，不依赖 PyQt5 / pyserial。

测试类别:
  - TC01~TC05: 配置校验
  - TC06~TC10: HEX 编解码
  - TC11~TC12: 文本/HEX 发送（通过 Mock）
  - TC13~TC15: 接收帧格式（SerialFrame）
  - TC16~TC18: 日志保存
  - TC19~TC20: MockSerialBackend 打开/关闭/发送接收
"""

import os
import sys
import time
import tempfile
import pytest

# 确保能从项目根目录导入 serial_core
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from serial_core import (
    SerialPortConfig,
    SerialFrame,
    make_frame,
    hex_encode,
    hex_decode,
    format_frame,
    format_log,
    save_log,
    MockSerialBackend,
    RealSerialBackend,
    create_backend,
    is_empty_payload,
    _bytes_to_printable,
)


# =========================================================================
# TC01~TC05: 配置校验
# =========================================================================

class TestSerialPortConfig:
    """SerialPortConfig 校验测试"""

    def test_tc01_valid_config_passes(self):
        """TC01: 有效配置校验通过"""
        config = SerialPortConfig(port="COM3")
        ok, msg = config.validate()
        assert ok is True, f"合法配置应通过校验: {msg}"
        assert msg == "", f"错误信息应为空: {msg}"

    def test_tc01_valid_config_with_all_params(self):
        """TC01: 所有参数均为合法值的配置"""
        config = SerialPortConfig(
            port="/dev/ttyUSB0",
            baudrate=9600,
            bytesize=7,
            parity="Even",
            stopbits=1.5,
            timeout=2.0,
        )
        ok, msg = config.validate()
        assert ok is True, f"合法配置应通过校验: {msg}"

    def test_tc01_valid_baudrate_256000(self):
        """TC01: 波特率 256000 合法"""
        config = SerialPortConfig(port="COM1", baudrate=256000)
        ok, _ = config.validate()
        assert ok is True

    def test_tc02_empty_port_fails(self):
        """TC02: 空端口名校验失败"""
        config = SerialPortConfig(port="")
        ok, msg = config.validate()
        assert ok is False
        assert "端口名不能为空" in msg

    def test_tc02_whitespace_port_fails(self):
        """TC02: 空格端口名校验失败"""
        config = SerialPortConfig(port="   ")
        ok, msg = config.validate()
        assert ok is False
        assert "端口名不能为空" in msg

    def test_tc03_invalid_baudrate_fails(self):
        """TC03: 非法波特率 12345 校验失败"""
        config = SerialPortConfig(port="COM1", baudrate=12345)
        ok, msg = config.validate()
        assert ok is False
        assert "非法波特率" in msg

    def test_tc03_invalid_baudrate_0_fails(self):
        """TC03: 波特率 0 校验失败"""
        config = SerialPortConfig(port="COM1", baudrate=0)
        ok, msg = config.validate()
        assert ok is False
        assert "非法波特率" in msg

    def test_tc04_invalid_bytesize_fails(self):
        """TC04: 非法数据位 9 校验失败"""
        config = SerialPortConfig(port="COM1", bytesize=9)
        ok, msg = config.validate()
        assert ok is False
        assert "非法数据位" in msg

    def test_tc04_invalid_bytesize_4_fails(self):
        """TC04: 数据位 4（不在{5,6,7,8}中）校验失败"""
        config = SerialPortConfig(port="COM1", bytesize=4)
        ok, msg = config.validate()
        assert ok is False
        assert "非法数据位" in msg

    def test_tc05_invalid_stopbits_fails(self):
        """TC05: 非法停止位 3 校验失败"""
        config = SerialPortConfig(port="COM1", stopbits=3.0)
        ok, msg = config.validate()
        assert ok is False
        assert "非法停止位" in msg

    def test_tc05_invalid_stopbits_0_fails(self):
        """TC05: 停止位 0 校验失败"""
        config = SerialPortConfig(port="COM1", stopbits=0.0)
        ok, msg = config.validate()
        assert ok is False
        assert "非法停止位" in msg

    def test_invalid_parity_fails(self):
        """非法校验位校验失败"""
        config = SerialPortConfig(port="COM1", parity="Invalid")
        ok, msg = config.validate()
        assert ok is False
        assert "非法校验位" in msg

    def test_to_dict_conversion(self):
        """to_dict() 转换正确"""
        config = SerialPortConfig(
            port="COM3",
            baudrate=115200,
            bytesize=8,
            parity="None",
            stopbits=1.0,
            timeout=0.5,
        )
        d = config.to_dict()
        assert d["port"] == "COM3"
        assert d["baudrate"] == 115200
        assert d["bytesize"] == 8
        assert d["parity"] == "N"  # pyserial 格式
        assert d["stopbits"] == 1.0
        assert d["timeout"] == 0.5

    def test_to_dict_parity_even(self):
        """to_dict: Even 校验转为 E"""
        config = SerialPortConfig(port="COM1", parity="Even")
        assert config.to_dict()["parity"] == "E"

    def test_to_dict_parity_odd(self):
        """to_dict: Odd 校验转为 O"""
        config = SerialPortConfig(port="COM1", parity="Odd")
        assert config.to_dict()["parity"] == "O"

    def test_frozen_immutable(self):
        """frozen=True 确保配置不可变"""
        config = SerialPortConfig(port="COM1")
        with pytest.raises(AttributeError):
            config.port = "COM2"  # type: ignore[misc]


# =========================================================================
# TC06~TC10: HEX 编解码
# =========================================================================

class TestHexEncode:
    """HEX 编码测试"""

    def test_hex_encode_hello(self):
        """hex_encode(b\"Hello\") → \"48 65 6C 6C 6F\""""
        assert hex_encode(b"Hello") == "48 65 6C 6C 6F"

    def test_hex_encode_empty(self):
        """hex_encode(b\"\") → \"\""""
        assert hex_encode(b"") == ""

    def test_hex_encode_binary(self):
        """hex_encode 对二进制数据正确编码"""
        data = bytes([0x00, 0xFF, 0xAB, 0x01])
        assert hex_encode(data) == "00 FF AB 01"

    def test_hex_encode_single_byte(self):
        """hex_encode 单字节"""
        assert hex_encode(b"A") == "41"


class TestHexDecode:
    """HEX 解码测试"""

    def test_tc06_hex_decode_spaced(self):
        """TC06: 空格分隔的HEX \"48 65 6C 6C 6F\" → b\"Hello\""""
        assert hex_decode("48 65 6C 6C 6F") == b"Hello"

    def test_tc07_hex_decode_compact(self):
        """TC07: 紧凑HEX \"48656C6C6F\" → b\"Hello\""""
        assert hex_decode("48656C6C6F") == b"Hello"

    def test_hex_decode_lowercase(self):
        """小写HEX也能正确解码"""
        assert hex_decode("48 65 6c 6c 6f") == b"Hello"

    def test_hex_decode_tab_separated(self):
        """Tab 分隔的HEX"""
        assert hex_decode("48\t65\t6C\t6C\t6F") == b"Hello"

    def test_hex_decode_newline_separated(self):
        """换行分隔的HEX"""
        assert hex_decode("48\n65\n6C\n6C\n6F") == b"Hello"

    def test_hex_decode_mixed_whitespace(self):
        """混合空白分隔"""
        assert hex_decode("48  65 \t 6C\n6C\t6F") == b"Hello"

    def test_hex_decode_single_byte(self):
        """单字节HEX"""
        assert hex_decode("41") == b"A"

    def test_tc08_hex_decode_invalid_char(self):
        """TC08: 非法HEX含 \"GG\" 抛出 ValueError"""
        with pytest.raises(ValueError) as exc:
            hex_decode("48 65 GG")
        assert "非法字符" in str(exc.value)

    def test_tc08_hex_decode_invalid_char_percent(self):
        """含 % 的非法HEX"""
        with pytest.raises(ValueError):
            hex_decode("48%65")

    def test_tc09_hex_decode_odd_length(self):
        """TC09: 奇数长度HEX \"48 6\" 抛出 ValueError"""
        with pytest.raises(ValueError) as exc:
            hex_decode("48 6")
        assert "必须为偶数" in str(exc.value)

    def test_tc09_hex_decode_odd_length_compact(self):
        """奇数长度紧凑HEX \"486\" 抛出 ValueError"""
        with pytest.raises(ValueError):
            hex_decode("486")

    def test_tc10_hex_decode_empty(self):
        """TC10: 空字符串HEX解码 → b\"\""""
        assert hex_decode("") == b""

    def test_hex_decode_whitespace_only(self):
        """仅空白字符 → b\"\""""
        assert hex_decode("   \t  \n  ") == b""

    def test_hex_decode_zero_byte(self):
        """\"00\" 解码为单字节 0x00"""
        assert hex_decode("00") == bytes([0x00])

    def test_hex_decode_ff(self):
        """\"FF\" 解码为 0xFF"""
        assert hex_decode("FF") == bytes([0xFF])


# =========================================================================
# TC11~TC12: 文本/HEX 发送（通过 Mock 验证）
# =========================================================================

class TestMockSend:
    """通过 MockSerialBackend 验证发送行为"""

    def test_tc11_text_send(self):
        """TC11: 文本发送，通过 Mock 验证发送内容"""
        backend = MockSerialBackend(echo_mode=False)
        config = SerialPortConfig(port="MOCK_COM1")
        backend.open(config)

        data = b"Hello"
        sent_len = backend.send(data)
        assert sent_len == len(data) == 5
        assert backend.tx_buffer == [b"Hello"]

    def test_tc11_text_send_multiple(self):
        """多次文本发送"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        backend.send(b"Hello")
        backend.send(b"World")
        assert backend.tx_buffer == [b"Hello", b"World"]

    def test_tc11_text_send_non_ascii(self):
        """发送非ASCII文本（中文字符UTF-8编码）"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        data = "你好".encode("utf-8")
        sent_len = backend.send(data)
        assert sent_len == len(data)
        assert backend.tx_buffer[0] == data

    def test_tc11_text_send_empty(self):
        """发送空数据返回 0 且不记录"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        sent_len = backend.send(b"")
        assert sent_len == 0
        assert len(backend.tx_buffer) == 0

    def test_tc12_hex_send(self):
        """TC12: HEX 发送，通过 Mock 验证发送内容"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))

        # 模拟用户输入 "48656C6C6F" 并解码后发送
        data = hex_decode("48656C6C6F")
        sent_len = backend.send(data)
        assert sent_len == 5
        assert backend.tx_buffer[0] == b"Hello"

    def test_tc12_hex_send_binary(self):
        """HEX 发送二进制数据"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))

        data = hex_decode("00 FF AB 01")
        sent_len = backend.send(data)
        assert sent_len == 4
        assert backend.tx_buffer[0] == bytes([0x00, 0xFF, 0xAB, 0x01])


# =========================================================================
# TC13~TC15: 接收帧格式 (SerialFrame)
# =========================================================================

class TestSerialFrame:
    """SerialFrame 数据帧测试"""

    def test_tc13_timestamp_format(self):
        """TC13: SerialFrame 时间戳为 float，范围合理"""
        before = time.time()
        frame = make_frame(b"Hello", "TX")
        after = time.time()
        assert isinstance(frame.timestamp, float)
        assert before <= frame.timestamp <= after

    def test_tc14_hex_str_format(self):
        """TC14: SerialFrame HEX 字符串为大写，双字符，空格分隔"""
        frame = make_frame(b"Hello", "TX")
        assert frame.hex_str == "48 65 6C 6C 6F"
        # 验证格式: 全部大写且空格分隔
        parts = frame.hex_str.split(" ")
        for p in parts:
            assert len(p) == 2
            assert p == p.upper()
            assert all(c in "0123456789ABCDEF" for c in p)

    def test_tc14_hex_str_empty(self):
        """空数据帧 HEX 为空"""
        frame = make_frame(b"", "RX")
        assert frame.hex_str == ""

    def test_tc15_text_str_printable(self):
        """TC15: SerialFrame 可打印字符保留"""
        frame = make_frame(b"Hello World!", "RX")
        assert frame.text_str == "Hello World!"

    def test_tc15_text_str_non_printable_replaced(self):
        """TC15: SerialFrame 不可打印字符替换为 '.'"""
        data = bytes([0x00, 0x01, 0x02, 0x1F, 0x7F])
        frame = make_frame(data, "RX")
        assert frame.text_str == "....."
        assert all(c == "." for c in frame.text_str)

    def test_tc15_text_str_mixed(self):
        """混合可打印和不可打印字符"""
        data = b"Hello\x00World\x1F!"
        frame = make_frame(data, "RX")
        assert frame.text_str == "Hello.World.!"

    def test_frame_direction_tx(self):
        """方向为 TX"""
        frame = make_frame(b"data", "TX")
        assert frame.direction == "TX"

    def test_frame_direction_rx(self):
        """方向为 RX"""
        frame = make_frame(b"data", "RX")
        assert frame.direction == "RX"

    def test_frame_raw_data_immutability(self):
        """raw_data 保持原始字节"""
        data = b"\x00\xFF\xAB"
        frame = make_frame(data, "TX")
        assert frame.raw_data == data
        # bytes 是不可变对象，只要值相等即可
        assert frame.raw_data == data

    def test_make_frame_auto_fill(self):
        """make_frame 自动填充 hex_str 和 text_str"""
        frame = make_frame(b"Test", "TX")
        assert frame.hex_str == "54 65 73 74"
        assert frame.text_str == "Test"


# =========================================================================
# TC16~TC18: 日志保存
# =========================================================================

class TestLogFormatting:
    """日志格式化测试"""

    def test_tc16_log_with_timestamp(self):
        """TC16: 日志格式化包含时间戳，每行以 '[' 开头"""
        records = [
            make_frame(b"Hello", "TX"),
            make_frame(b"World", "RX"),
        ]
        log = format_log(records, include_timestamp=True)
        lines = log.split("\n")
        assert len(lines) == 2
        for line in lines:
            assert line.startswith("["), f"每行应以 '[' 开头: {line}"

    def test_tc16_log_timestamp_format(self):
        """时间戳格式 [HH:MM:SS.mmm]"""
        frame = make_frame(b"Test", "TX")
        line = format_frame(frame, include_timestamp=True)
        # 格式: [10:30:45.123] TX: 54 65 73 74
        import re
        assert re.match(r"^\[\d{2}:\d{2}:\d{2}\.\d{3}\]", line)

    def test_tc17_log_without_timestamp(self):
        """TC17: 日志格式化不包含时间戳，每行以 'TX:' 或 'RX:' 开头"""
        records = [
            make_frame(b"Hello", "TX"),
            make_frame(b"World", "RX"),
        ]
        log = format_log(records, include_timestamp=False)
        lines = log.split("\n")
        assert len(lines) == 2
        assert lines[0].startswith("TX:")
        assert lines[1].startswith("RX:")

    def test_tc17_log_without_timestamp_single(self):
        """单帧无时间戳"""
        frame = make_frame(b"Test", "TX")
        line = format_frame(frame, include_timestamp=False)
        assert line == "TX: 54 65 73 74"

    def test_empty_records(self):
        """空记录列表"""
        log = format_log([], include_timestamp=True)
        assert log == ""

    def test_tc18_save_log_to_file(self):
        """TC18: 保存日志到文件，文件存在且内容非空"""
        records = [
            make_frame(b"Hello", "TX"),
            make_frame(b"World", "RX"),
        ]
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".log", delete=False, encoding="utf-8"
        ) as f:
            temp_path = f.name

        try:
            result = save_log(temp_path, records, include_timestamp=True)
            assert result is True

            with open(temp_path, "r", encoding="utf-8") as f:
                content = f.read()

            assert len(content) > 0
            assert "TX:" in content
            assert "RX:" in content
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)

    def test_save_log_to_invalid_path(self):
        """保存到无效路径返回 False"""
        records = [make_frame(b"Test", "TX")]
        result = save_log("/nonexistent_dir/abc.log", records, include_timestamp=True)
        assert result is False

    def test_save_log_without_timestamp(self):
        """不带时间戳保存日志"""
        records = [make_frame(b"Test", "TX")]
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".log", delete=False, encoding="utf-8"
        ) as f:
            temp_path = f.name
        try:
            result = save_log(temp_path, records, include_timestamp=False)
            assert result is True
            with open(temp_path, "r", encoding="utf-8") as f:
                content = f.read()
            assert content.startswith("TX:")
            assert "[" not in content.split("\n")[0]
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)


# =========================================================================
# TC19~TC20: MockSerialBackend 打开/关闭/发送接收
# =========================================================================

class TestMockSerialBackend:
    """MockSerialBackend 功能测试"""

    def test_tc19_open_close(self):
        """TC19: MockSerialBackend 打开/关闭成功"""
        backend = MockSerialBackend()
        config = SerialPortConfig(port="MOCK_COM1")

        assert backend.is_open() is False

        open_ok = backend.open(config)
        assert open_ok is True
        assert backend.is_open() is True

        close_ok = backend.close()
        assert close_ok is True
        assert backend.is_open() is False

    def test_tc19_close_when_not_open(self):
        """关闭已关闭的串口返回 False"""
        backend = MockSerialBackend()
        assert backend.close() is False

    def test_tc19_open_already_open(self):
        """打开已打开的串口返回 True（幂等）"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        assert backend.open(SerialPortConfig(port="MOCK_COM2")) is True
        assert backend.is_open() is True

    def test_tc20_send_receive_echo(self):
        """TC20: MockSerialBackend 发送接收回显（echo模式）"""
        backend = MockSerialBackend(echo_mode=True)
        backend.open(SerialPortConfig(port="MOCK_COM1"))

        sent_len = backend.send(b"Hello")
        assert sent_len == 5

        received = backend.receive()
        assert received == b"Hello"

        # 第二次接收应为 None（队列已空）
        assert backend.receive() is None

    def test_send_without_open(self):
        """未打开时发送返回 0"""
        backend = MockSerialBackend()
        assert backend.send(b"data") == 0

    def test_receive_without_open(self):
        """未打开时接收返回 None"""
        backend = MockSerialBackend()
        assert backend.receive() is None

    def test_inject_rx(self):
        """注入预设接收数据"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="MOCK_COM1"))

        backend.inject_rx(b"Preset Data")
        assert backend.receive() == b"Preset Data"

    def test_inject_rx_multiple(self):
        """注入多条预设数据"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="MOCK_COM1"))

        backend.inject_rx(b"First")
        backend.inject_rx(b"Second")
        backend.inject_rx(b"Third")

        assert backend.receive() == b"First"
        assert backend.receive() == b"Second"
        assert backend.receive() == b"Third"
        assert backend.receive() is None

    def test_list_ports(self):
        """list_ports 返回虚拟端口列表"""
        ports = MockSerialBackend.list_ports()
        assert "MOCK_COM1" in ports
        assert "MOCK_COM2" in ports

    def test_echo_mode_disabled(self):
        """关闭 echo 模式后，发送不自动回填接收队列"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))

        backend.send(b"Hello")
        # echo_mode=False 时接收队列为空
        assert backend.receive() is None
        # tx_buffer 仍有记录
        assert len(backend.tx_buffer) == 1

    def test_reset(self):
        """reset() 完全重置状态"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        backend.send(b"Hello")
        backend.reset()
        assert backend.is_open() is False
        assert len(backend.tx_buffer) == 0
        assert backend.receive() is None

    def test_clear_tx_buffer(self):
        """清空发送历史"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        backend.send(b"Data1")
        backend.send(b"Data2")
        assert len(backend.tx_buffer) == 2
        backend.clear_tx_buffer()
        assert len(backend.tx_buffer) == 0

    def test_tx_buffer_copy(self):
        """tx_buffer 属性返回副本，外部修改不影响内部"""
        backend = MockSerialBackend(echo_mode=False)
        backend.open(SerialPortConfig(port="MOCK_COM1"))
        backend.send(b"Data")
        buf = backend.tx_buffer
        buf.append(b"Hacked")
        assert len(backend.tx_buffer) == 1  # 内部未被改变


# =========================================================================
# 辅助函数测试
# =========================================================================

class TestIsEmptyPayload:
    """空载荷检查"""

    def test_empty_bytes(self):
        """b\"\" 为空"""
        assert is_empty_payload(b"") is True

    def test_non_empty(self):
        """非空数据"""
        assert is_empty_payload(b"data") is False

    def test_none(self):
        """None 视为空"""
        assert is_empty_payload(None) is True  # type: ignore[arg-type]


class TestBytesToPrintable:
    """字节转可打印字符串"""

    def test_printable(self):
        """可打印字符保留"""
        assert _bytes_to_printable(b"Hello") == "Hello"

    def test_non_printable(self):
        """不可打印字符替换"""
        assert _bytes_to_printable(bytes([0x00])) == "."
        assert _bytes_to_printable(bytes([0x01, 0x1F, 0x7F])) == "..."

    def test_mixed(self):
        """混合"""
        assert _bytes_to_printable(b"ABC\x00DEF") == "ABC.DEF"


# =========================================================================
# create_backend 工厂函数测试
# =========================================================================

class TestCreateBackend:
    """后端工厂函数测试"""

    def test_create_backend_mock_env(self):
        """MOCK_SERIAL=1 时返回 MockSerialBackend"""
        os.environ["MOCK_SERIAL"] = "1"
        backend = create_backend()
        assert isinstance(backend, MockSerialBackend)

    def test_create_backend_fallback(self):
        """无 MOCK_SERIAL 且无 pyserial 时回退到 Mock"""
        if "MOCK_SERIAL" in os.environ:
            del os.environ["MOCK_SERIAL"]

        # 删除 serial 模块缓存，测试回退逻辑
        saved_serial = sys.modules.pop("serial", None)

        try:
            backend = create_backend()
            # 验证函数不抛出异常，返回有效后端
            assert backend is not None
        finally:
            # 恢复 serial 模块缓存
            if saved_serial is not None:
                sys.modules["serial"] = saved_serial


class TestRealSerialBackend:
    """RealSerialBackend 接口存在性测试"""

    def test_class_exists(self):
        """RealSerialBackend 类存在"""
        from serial_core import RealSerialBackend
        assert RealSerialBackend is not None

    def test_implements_serial_backend(self):
        """RealSerialBackend 继承自 SerialBackend"""
        from serial_core import SerialBackend, RealSerialBackend
        assert issubclass(RealSerialBackend, SerialBackend)

    def test_open_without_serial(self):
        """无 pyserial 时 open 返回 False"""
        # 模拟 pyserial 未安装
        import builtins
        original_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "serial":
                raise ImportError("No module named 'serial'")
            return original_import(name, *args, **kwargs)

        builtins.__import__ = mock_import
        try:
            backend = RealSerialBackend()
            config = SerialPortConfig(port="COM1")
            result = backend.open(config)
            assert result is False
        finally:
            builtins.__import__ = original_import

    def test_list_ports_interface(self):
        """list_ports 返回列表（即使为空）"""
        # 不模拟 import，真实执行（如果无 pyserial 返回空列表）
        try:
            ports = RealSerialBackend.list_ports()
            assert isinstance(ports, list)
        except Exception:
            pass  # 允许异常，因为可能系统限制
