"""
test_serial_gui.py — GUI Smoke Test

覆盖 TC21~TC25 测试用例，验证 GUI 导入、窗口创建、控件存在性。
使用 QT_QPA_PLATFORM=offscreen 避免弹出窗口。

测试类别:
  TC21: PyQt5 模块导入成功
  TC22: MainWindow 类定义存在
  TC23: offscreen 模式下窗口创建无崩溃
  TC24: 控件存在性检查
  TC25: Mock 模式下整体 import 无阻塞
"""

import os
import sys
import pytest

# 确保能从项目根目录导入
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# =========================================================================
# TC21: PyQt5 模块导入成功
# =========================================================================

class TestPyQt5Import:
    """TC21: PyQt5 模块导入测试"""

    def test_tc21_pyqt5_import(self):
        """PyQt5 核心模块导入成功"""
        try:
            from PyQt5 import QtCore, QtGui, QtWidgets
            assert QtCore is not None
            assert QtGui is not None
            assert QtWidgets is not None
        except ImportError:
            pytest.skip("PyQt5 未安装，跳过 GUI 测试")


# =========================================================================
# TC22: MainWindow 类存在
# =========================================================================

class TestMainWindowClass:
    """TC22: MainWindow 类定义存在性测试"""

    def test_tc22_mainwindow_class_exists(self):
        """app.py 中 MainWindow 类存在且可导入"""
        try:
            from app import MainWindow
            assert MainWindow is not None
            assert hasattr(MainWindow, "__bases__")
        except ImportError:
            pytest.skip("PyQt5 未安装，跳过 GUI 测试")

    def test_tc22_mainwindow_inherits_qmainwindow(self):
        """MainWindow 继承自 QMainWindow"""
        try:
            from PyQt5.QtWidgets import QMainWindow
            from app import MainWindow
            assert issubclass(MainWindow, QMainWindow)
        except ImportError:
            pytest.skip("PyQt5 未安装，跳过 GUI 测试")


# =========================================================================
# TC23: offscreen 模式下窗口创建无崩溃
# =========================================================================

class TestWindowCreation:
    """TC23: offscreen 窗口创建测试"""

    def test_tc23_offscreen_window_creation(self, qtbot):
        """offscreen 模式下创建 MainWindow 无崩溃"""
        from app import MainWindow
        window = MainWindow()
        # 验证窗口对象创建成功
        assert window is not None
        assert window.windowTitle() == "串口调试助手"
        # 验证属性存在
        assert hasattr(window, "backend")
        assert hasattr(window, "records")
        assert window.records == []

    def test_tc23_window_show_no_exception(self, qtbot):
        """窗口 show() 不抛出异常"""
        from app import MainWindow
        window = MainWindow()
        window.show()
        assert window.isVisible() is True
        window.close()


# =========================================================================
# TC24: 控件存在性检查
# =========================================================================

class TestControlsExistence:
    """TC24: 关键控件存在性检查"""

    @pytest.fixture(autouse=True)
    def _setup(self, qtbot):
        from app import MainWindow
        self.window = MainWindow()
        yield
        self.window.close()

    def test_tc24_port_combobox_exists(self):
        """端口选择 ComboBox 存在"""
        assert hasattr(self.window, "combo_port")

    def test_tc24_baudrate_combobox_exists(self):
        """波特率选择 ComboBox 存在"""
        assert hasattr(self.window, "combo_baudrate")
        items = [self.window.combo_baudrate.itemText(i) for i in range(self.window.combo_baudrate.count())]
        assert "115200" in items
        assert "9600" in items

    def test_tc24_bytesize_combobox_exists(self):
        """数据位选择 ComboBox 存在"""
        assert hasattr(self.window, "combo_bytesize")
        items = [self.window.combo_bytesize.itemText(i) for i in range(self.window.combo_bytesize.count())]
        assert "8" in items

    def test_tc24_stopbits_combobox_exists(self):
        """停止位选择 ComboBox 存在"""
        assert hasattr(self.window, "combo_stopbits")
        items = [self.window.combo_stopbits.itemText(i) for i in range(self.window.combo_stopbits.count())]
        assert "1" in items
        assert "1.5" in items

    def test_tc24_parity_combobox_exists(self):
        """校验位选择 ComboBox 存在"""
        assert hasattr(self.window, "combo_parity")
        items = [self.window.combo_parity.itemText(i) for i in range(self.window.combo_parity.count())]
        assert "None" in items
        assert "Even" in items

    def test_tc24_open_button_exists(self):
        """打开串口按钮存在"""
        assert hasattr(self.window, "btn_open")
        assert self.window.btn_open.text() in ("打开串口", "关闭串口")

    def test_tc24_send_button_exists(self):
        """发送按钮存在"""
        assert hasattr(self.window, "btn_send")
        assert self.window.btn_send.text() == "发送"

    def test_tc24_send_text_edit_exists(self):
        """发送区 QTextEdit 存在"""
        assert hasattr(self.window, "text_send")

    def test_tc24_recv_text_edit_exists(self):
        """接收区 QTextEdit 存在"""
        assert hasattr(self.window, "text_recv")

    def test_tc24_hex_checkbox_exists(self):
        """HEX 发送复选框存在"""
        assert hasattr(self.window, "check_hex_send")

    def test_tc24_timestamp_checkbox_exists(self):
        """时间戳复选框存在"""
        assert hasattr(self.window, "check_timestamp")

    def test_tc24_autoscroll_checkbox_exists(self):
        """自动滚屏复选框存在"""
        assert hasattr(self.window, "check_autoscroll")

    def test_tc24_clear_button_exists(self):
        """清空按钮存在"""
        assert hasattr(self.window, "btn_clear")

    def test_tc24_save_log_button_exists(self):
        """保存日志按钮存在"""
        assert hasattr(self.window, "btn_save_log")

    def test_tc24_refresh_button_exists(self):
        """刷新按钮存在"""
        assert hasattr(self.window, "btn_refresh")

    def test_tc24_controls_dict_exists(self):
        """_controls 字典包含所有关键控件"""
        assert hasattr(self.window, "_controls")
        controls = self.window._controls
        assert "combo_port" in controls
        assert "combo_baudrate" in controls
        assert "btn_open" in controls
        assert "btn_send" in controls
        assert "text_send" in controls
        assert "text_recv" in controls
        assert "check_hex_send" in controls
        assert "check_timestamp" in controls

    def test_tc24_status_bar_exists(self):
        """状态栏存在"""
        assert hasattr(self.window, "status_bar")


# =========================================================================
# TC25: Mock 模式整体 import 无阻塞
# =========================================================================

class TestMockModeImport:
    """TC25: Mock 模式下 import 无阻塞测试"""

    def test_tc25_mock_mode_import_no_block(self):
        """MOCK_SERIAL=1 环境下 import app 无阻塞"""
        os.environ["MOCK_SERIAL"] = "1"
        try:
            # 重新导入确保环境变量生效
            import importlib
            import app
            importlib.reload(app)
            assert app is not None
        except ImportError:
            pytest.skip("PyQt5 未安装，跳过")
        finally:
            os.environ.pop("MOCK_SERIAL", None)

    def test_tc25_mock_mode_mainwindow_uses_mock(self):
        """Mock 模式下 MainWindow 使用 MockSerialBackend"""
        os.environ["MOCK_SERIAL"] = "1"
        try:
            from app import MainWindow
            from serial_core import MockSerialBackend
            # 暂不实例化（需要 QApplication）
            # 验证模块级导入无阻塞即可
            assert MainWindow is not None
        except ImportError:
            pytest.skip("PyQt5 未安装，跳过")
        finally:
            os.environ.pop("MOCK_SERIAL", None)


# =========================================================================
# pytest qtbot fixture（防止 QApplication 重复创建）
# =========================================================================

@pytest.fixture(scope="session")
def qapp():
    """会话级别的 QApplication fixture"""
    from PyQt5.QtWidgets import QApplication
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    return app


@pytest.fixture()
def qtbot(qapp):
    """提供 qtbot 风格的 fixture"""
    from PyQt5.QtTest import QTest
    yield QTest
    # 处理挂起事件
    qapp.processEvents()
