"""
test_gui_functional.py — GUI 功能集成测试

覆盖 Mock 模式下端到端流程：
  1. 打开 Mock 串口
  2. 发送文本/HEX 数据
  3. 验证接收回显
  4. 时间戳开关
  5. 清空接收区
  6. 保存日志
  7. 空发送不产生 TX 帧
  8. 非法 HEX 输入提示
"""

import os
import sys
import time
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestGUIFunctional:
    """GUI 功能集成测试（Mock 模式 + offscreen）"""

    @pytest.fixture(autouse=True)
    def _setup(self):
        """每个测试前创建窗口实例"""
        os.environ["MOCK_SERIAL"] = "1"
        os.environ["QT_QPA_PLATFORM"] = "offscreen"

        from PyQt5.QtWidgets import QApplication
        self.qapp = QApplication.instance()
        if self.qapp is None:
            self.qapp = QApplication(sys.argv)

        from app import MainWindow
        self.window = MainWindow()
        self.window.show()
        self.qapp.processEvents()

        yield

        self.window.close()
        self.qapp.processEvents()
        if "MOCK_SERIAL" in os.environ:
            del os.environ["MOCK_SERIAL"]
        if "QT_QPA_PLATFORM" in os.environ:
            del os.environ["QT_QPA_PLATFORM"]

    def _flush(self, n: int = 5):
        """处理挂起的 Qt 事件（多次以确保 worker 信号处理）"""
        for _ in range(n):
            self.qapp.processEvents()
            time.sleep(0.01)

    def test_open_mock_serial(self):
        """打开 Mock 串口"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        assert self.window._is_open is True
        assert self.window.btn_open.text() == "关闭串口"
        assert self.window.btn_send.isEnabled() is True
        assert "已打开" in self.window.status_bar.currentMessage()

    def test_send_text_message(self):
        """发送文本消息并验证回显"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        # 发送文本
        self.window.text_send.setPlainText("Hello World")
        self.window.btn_send.click()
        self._flush(10)  # 多次 flush 让 worker 有时间处理

        # 验证记录中有 TX 帧
        tx_frames = [r for r in self.window.records if r.direction == "TX"]
        assert len(tx_frames) >= 1
        assert tx_frames[0].raw_data == b"Hello World"

        # 验证接收区有内容
        assert len(self.window.text_recv.toPlainText()) > 0

        # 验证 RX 帧也到达（echo 模式，异步）
        rx_frames = [r for r in self.window.records if r.direction == "RX"]
        if len(rx_frames) == 0:
            # 如果 worker 还没处理完，再等一会儿
            time.sleep(0.2)
            self._flush(10)
            rx_frames = [r for r in self.window.records if r.direction == "RX"]
        assert len(rx_frames) >= 1, "RX 帧应通过 echo 模式回显"
        assert rx_frames[0].raw_data == b"Hello World"

    def test_send_empty_returns_directly(self):
        """空发送直接返回，不产生 TX 帧"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        initial_count = len(self.window.records)
        self.window.text_send.setPlainText("")
        self.window.btn_send.click()
        self._flush()
        assert len(self.window.records) == initial_count

        # 发送空白
        self.window.text_send.setPlainText("   ")
        self.window.btn_send.click()
        self._flush()
        assert len(self.window.records) == initial_count

    def test_send_hex_message(self):
        """发送 HEX 数据"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        self.window.check_hex_send.setChecked(True)

        # 发送 HEX "48 65 6C 6C 6F" → "Hello"
        self.window.text_send.setPlainText("48 65 6C 6C 6F")
        self.window.btn_send.click()
        self._flush(10)

        tx_frames = [r for r in self.window.records if r.direction == "TX"]
        assert len(tx_frames) >= 1
        assert tx_frames[0].raw_data == b"Hello"

    def test_invalid_hex_shows_error(self):
        """非法 HEX 输入显示错误提示"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        self.window.check_hex_send.setChecked(True)
        self.window.text_send.setPlainText("48 65 GG")
        self.window.btn_send.click()
        self._flush()

        assert hasattr(self.window, "_last_message")
        assert "HEX 格式错误" in self.window._last_message or "非法字符" in self.window._last_message

    def test_clear_receive_area(self):
        """清空接收区"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        self.window.text_send.setPlainText("Test")
        self.window.btn_send.click()
        self._flush(10)
        assert len(self.window.text_recv.toPlainText()) > 0
        assert len(self.window.records) > 0

        self.window.btn_clear.click()
        self._flush()
        assert len(self.window.text_recv.toPlainText()) == 0
        assert len(self.window.records) == 0

    def test_save_log(self):
        """保存日志（测试模式写入固定路径）"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        self.window.text_send.setPlainText("Hello")
        self.window.btn_send.click()
        self._flush(10)

        self.window.btn_save_log.click()
        self._flush()

        assert hasattr(self.window, "_last_log_path")
        log_path = self.window._last_log_path
        assert os.path.exists(log_path)
        with open(log_path, "r") as f:
            content = f.read()
        assert "TX:" in content
        assert "48 65 6C 6C 6F" in content
        os.remove(log_path)

    def test_timestamp_toggle(self):
        """时间戳开关"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        # 关闭时间戳
        self.window.check_timestamp.setChecked(False)

        self.window.text_send.setPlainText("Data")
        self.window.btn_send.click()
        self._flush(10)

        text = self.window.text_recv.toPlainText()
        lines = text.strip().split("\n")
        # 不带时间戳时，行以 TX: 开头（不是 [）
        assert all(not line.startswith("[") for line in lines if line.strip())

    def test_close_serial(self):
        """关闭串口"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()
        assert self.window._is_open is True

        self.window.btn_open.click()
        self._flush()
        assert self.window._is_open is False
        assert self.window.btn_open.text() == "打开串口"
        assert self.window.btn_send.isEnabled() is False

    def test_auto_scroll_toggle(self):
        """自动滚屏切换"""
        assert self.window.check_autoscroll.isChecked() is True
        self.window.check_autoscroll.setChecked(False)
        assert self.window._is_auto_scroll is False

    def test_multiple_sends(self):
        """多次发送累积记录"""
        self.window.combo_port.setCurrentText("MOCK_COM1")
        self.window.btn_open.click()
        self._flush()

        for i in range(5):
            self.window.text_send.setPlainText(f"Msg{i}")
            self.window.btn_send.click()
            self._flush(5)

        tx_frames = [r for r in self.window.records if r.direction == "TX"]
        assert len(tx_frames) >= 5
        assert len(self.window.text_recv.toPlainText()) > 0
