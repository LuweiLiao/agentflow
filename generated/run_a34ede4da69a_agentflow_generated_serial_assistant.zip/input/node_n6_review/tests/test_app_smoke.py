"""
test_app_smoke.py — 综合烟雾测试（闭环反馈用）

覆盖以下场景：
  第1层：核心逻辑零依赖测试（无需 PyQt5 / pyserial）
    - 配置校验（合法/非法）
    - HEX 编解码（合法/非法/边界）
    - SerialFrame 构造与格式化
    - MockSerialBackend 打开/关闭/发送/接收
    - 日志格式化与保存
    - create_backend / is_empty_payload 工具函数

  第2层：GUI import / offscreen smoke 测试
    - PyQt5 模块导入
    - MainWindow 类定义
    - offscreen 窗口创建与控件存在性
    - Mock 模式 import 无阻塞

  第3层：Mock 模式端到端功能 smoke
    - 打开 Mock 串口 → 发送文本/HEX → 验证回显
    - 空发送检查 / 非法 HEX 提示
    - 清空 / 保存日志 / 时间戳 / 自动滚屏

执行方式：
  MOCK_SERIAL=1 QT_QPA_PLATFORM=offscreen python -m pytest tests/test_app_smoke.py -v

失败时保留完整 traceback 作为反馈证据。
"""

import os
import sys
import time
import tempfile
import traceback

# 确保能从项目根目录导入
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# =========================================================================
# 第1层：核心逻辑烟雾测试
# =========================================================================

# ── 这些测试完全不依赖 PyQt5，在任何 Python 环境均可运行 ──

def test_core_serial_port_config_valid():
    """核心层 TC01: 有效配置校验通过"""
    from serial_core import SerialPortConfig
    config = SerialPortConfig(port="COM3")
    ok, msg = config.validate()
    assert ok is True, f"合法配置应通过校验: {msg}"
    assert msg == ""


def test_core_serial_port_config_invalid_empty_port():
    """核心层 TC02: 空端口校验失败"""
    from serial_core import SerialPortConfig
    config = SerialPortConfig(port="")
    ok, msg = config.validate()
    assert ok is False
    assert "端口名不能为空" in msg


def test_core_serial_port_config_invalid_baudrate():
    """核心层 TC03: 非法波特率校验失败"""
    from serial_core import SerialPortConfig
    config = SerialPortConfig(port="COM1", baudrate=12345)
    ok, msg = config.validate()
    assert ok is False
    assert "非法波特率" in msg


def test_core_serial_port_config_invalid_bytesize():
    """核心层 TC04: 非法数据位校验失败"""
    from serial_core import SerialPortConfig
    config = SerialPortConfig(port="COM1", bytesize=9)
    ok, msg = config.validate()
    assert ok is False
    assert "非法数据位" in msg


def test_core_serial_port_config_invalid_stopbits():
    """核心层 TC05: 非法停止位校验失败"""
    from serial_core import SerialPortConfig
    config = SerialPortConfig(port="COM1", stopbits=3.0)
    ok, msg = config.validate()
    assert ok is False
    assert "非法停止位" in msg


def test_core_hex_encode_basic():
    """核心层 TC06: HEX 编码基本功能"""
    from serial_core import hex_encode
    assert hex_encode(b"Hello") == "48 65 6C 6C 6F"
    assert hex_encode(b"") == ""
    assert hex_encode(bytes([0x00, 0xFF])) == "00 FF"


def test_core_hex_decode_spaced():
    """核心层 TC07: 空格分隔 HEX 解码"""
    from serial_core import hex_decode
    assert hex_decode("48 65 6C 6C 6F") == b"Hello"


def test_core_hex_decode_compact():
    """核心层 TC07: 紧凑 HEX 解码"""
    from serial_core import hex_decode
    assert hex_decode("48656C6C6F") == b"Hello"


def test_core_hex_decode_invalid_char():
    """核心层 TC08: 非法字符抛出 ValueError"""
    from serial_core import hex_decode
    try:
        hex_decode("48 65 GG")
        assert False, "应抛出 ValueError"
    except ValueError as e:
        assert "非法字符" in str(e)


def test_core_hex_decode_odd_length():
    """核心层 TC09: 奇数长度 HEX 抛出 ValueError"""
    from serial_core import hex_decode
    try:
        hex_decode("48 6")
        assert False, "应抛出 ValueError"
    except ValueError as e:
        assert "必须为偶数" in str(e)


def test_core_hex_decode_empty():
    """核心层 TC10: 空字符串解码返回空字节"""
    from serial_core import hex_decode
    assert hex_decode("") == b""
    assert hex_decode("   ") == b""


def test_core_make_frame():
    """核心层 TC13-15: SerialFrame 构造与格式"""
    from serial_core import make_frame
    frame = make_frame(b"Hello", "TX")
    assert frame.direction == "TX"
    assert frame.raw_data == b"Hello"
    assert frame.hex_str == "48 65 6C 6C 6F"
    assert frame.text_str == "Hello"


def test_core_format_log():
    """核心层 TC16-17: 日志格式化"""
    from serial_core import make_frame, format_frame, format_log
    frame = make_frame(b"AB", "TX")
    formatted = format_frame(frame, include_timestamp=True)
    assert "TX:" in formatted
    assert "41 42" in formatted

    log = format_log([frame], include_timestamp=False)
    assert log == "TX: 41 42"


def test_core_save_log():
    """核心层 TC18: 日志保存到文件"""
    from serial_core import make_frame, save_log
    frame = make_frame(b"Test", "TX")

    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False, encoding="utf-8") as f:
        path = f.name

    try:
        result = save_log(path, [frame], include_timestamp=False)
        assert result is True
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "TX:" in content
        assert "54 65 73 74" in content
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_core_mock_backend_open_close():
    """核心层 TC19: MockSerialBackend 打开/关闭"""
    from serial_core import MockSerialBackend, SerialPortConfig
    backend = MockSerialBackend(echo_mode=True)
    config = SerialPortConfig(port="MOCK_COM1")

    assert backend.is_open() is False
    result = backend.open(config)
    assert result is True
    assert backend.is_open() is True

    result = backend.close()
    assert result is True
    assert backend.is_open() is False


def test_core_mock_backend_send_receive():
    """核心层 TC20: MockSerialBackend 发送/接收回显"""
    from serial_core import MockSerialBackend, SerialPortConfig
    backend = MockSerialBackend(echo_mode=True)
    backend.open(SerialPortConfig(port="MOCK_COM1"))

    sent = backend.send(b"Hello")
    assert sent == 5
    assert backend.tx_buffer == [b"Hello"]

    # echo 模式下发送数据自动进入接收队列
    rx = backend.receive()
    assert rx == b"Hello"


def test_core_create_backend_mock():
    """核心层: create_backend 在 MOCK_SERIAL=1 时返回 Mock 实例"""
    os.environ["MOCK_SERIAL"] = "1"
    try:
        from serial_core import create_backend, MockSerialBackend
        backend = create_backend()
        assert isinstance(backend, MockSerialBackend)
    finally:
        os.environ.pop("MOCK_SERIAL", None)


def test_core_is_empty_payload():
    """核心层: is_empty_payload 边界检查"""
    from serial_core import is_empty_payload
    assert is_empty_payload(b"") is True
    assert is_empty_payload(b"data") is False


def test_core_serial_frame_post_init():
    """核心层: SerialFrame __post_init__ 自动填充"""
    from serial_core import SerialFrame
    frame = SerialFrame(timestamp=time.time(), direction="RX", raw_data=b"AB")
    assert frame.hex_str == "41 42"
    assert frame.text_str == "AB"


# =========================================================================
# 第2层：GUI smoke 测试（需要 PyQt5 + offscreen）
# =========================================================================

def test_gui_pyqt5_import():
    """GUI层 TC21: PyQt5 模块导入"""
    try:
        from PyQt5 import QtCore, QtGui, QtWidgets
        assert QtCore is not None
        assert QtGui is not None
        assert QtWidgets is not None
    except ImportError:
        pytest.skip("PyQt5 未安装")



def test_gui_mainwindow_class_exists():
    """GUI层 TC22: MainWindow 类定义存在"""
    try:
        from app import MainWindow
        from PyQt5.QtWidgets import QMainWindow
        assert MainWindow is not None
        assert issubclass(MainWindow, QMainWindow)
    except ImportError:
        pytest.skip("PyQt5 未安装")


def test_gui_offscreen_window_creation():
    """GUI层 TC23: offscreen 窗口创建无崩溃"""
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        assert window is not None
        assert window.windowTitle() == "串口调试助手"
        assert hasattr(window, "backend")
        assert hasattr(window, "records")
        assert window.records == []

        window.show()
        assert window.isVisible() is True
        app.processEvents()
        window.close()
    except ImportError:
        pytest.skip("PyQt5 未安装")


def test_gui_controls_existence():
    """GUI层 TC24: 关键控件存在性"""
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()

        # 配置区控件
        assert hasattr(window, "combo_port")
        assert hasattr(window, "combo_baudrate")
        assert hasattr(window, "combo_bytesize")
        assert hasattr(window, "combo_stopbits")
        assert hasattr(window, "combo_parity")
        assert hasattr(window, "btn_open")
        assert hasattr(window, "btn_refresh")

        # 发送区控件
        assert hasattr(window, "text_send")
        assert hasattr(window, "btn_send")
        assert hasattr(window, "check_hex_send")

        # 接收区控件
        assert hasattr(window, "text_recv")
        assert hasattr(window, "check_timestamp")
        assert hasattr(window, "check_autoscroll")
        assert hasattr(window, "btn_clear")
        assert hasattr(window, "btn_save_log")

        # 状态栏
        assert hasattr(window, "status_bar")

        # 下拉框默认值
        assert window.combo_baudrate.currentText() == "115200"
        assert window.combo_bytesize.currentText() == "8"
        assert window.combo_stopbits.currentText() == "1"
        assert window.combo_parity.currentText() == "None"

        app.processEvents()
        window.close()
    except ImportError:
        pytest.skip("PyQt5 未安装")


def test_gui_mock_mode_import():
    """GUI层 TC25: MOCK_SERIAL=1 时 import app 无阻塞"""
    os.environ["MOCK_SERIAL"] = "1"
    try:
        import importlib
        import app
        importlib.reload(app)
        assert app is not None
        assert hasattr(app, "MainWindow")
    except ImportError:
        pytest.skip("PyQt5 未安装")
    finally:
        os.environ.pop("MOCK_SERIAL", None)


def test_gui_app_no_pyqt5_fallback():
    """GUI层: 无 PyQt5 时 app.PYQT5_AVAILABLE 为 False"""
    # 这个测试模拟 PYQT5_AVAILABLE 的行为
    import app
    assert hasattr(app, "PYQT5_AVAILABLE")
    # 在当前环境下 PyQt5 已安装，所以应为 True
    assert app.PYQT5_AVAILABLE is True


# =========================================================================
# 第3层：Mock 模式端到端功能 smoke
# =========================================================================

def test_functional_open_mock_serial():
    """功能层: 打开 Mock 串口"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()

        assert window._is_open is True
        assert window.btn_open.text() == "关闭串口"
        assert window.btn_send.isEnabled() is True
        assert "已打开" in window.status_bar.currentMessage()

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_send_text():
    """功能层: 发送文本并验证 TX 帧"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()

        window.text_send.setPlainText("Hello World")
        window.btn_send.click()
        for _ in range(10):
            app.processEvents()

        tx_frames = [r for r in window.records if r.direction == "TX"]
        assert len(tx_frames) >= 1
        assert tx_frames[0].raw_data == b"Hello World"

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_send_hex():
    """功能层: 发送 HEX 数据"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()

        window.check_hex_send.setChecked(True)
        window.text_send.setPlainText("48 65 6C 6C 6F")
        window.btn_send.click()
        for _ in range(10):
            app.processEvents()

        tx_frames = [r for r in window.records if r.direction == "TX"]
        assert len(tx_frames) >= 1
        assert tx_frames[0].raw_data == b"Hello"

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_empty_send():
    """功能层: 空发送不产生 TX 帧"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()

        initial_count = len(window.records)
        window.text_send.setPlainText("")
        window.btn_send.click()
        app.processEvents()
        assert len(window.records) == initial_count

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_clear_and_save_log():
    """功能层: 清空接收区并保存日志"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()

        # 发送数据
        window.text_send.setPlainText("Test")
        window.btn_send.click()
        for _ in range(10):
            app.processEvents()
        assert len(window.records) > 0

        # 清空
        window.btn_clear.click()
        app.processEvents()
        assert len(window.text_recv.toPlainText()) == 0
        assert len(window.records) == 0

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_timestamp_toggle():
    """功能层: 时间戳开关切换"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()

        # 关闭时间戳
        window.check_timestamp.setChecked(False)

        window.text_send.setPlainText("Data")
        window.btn_send.click()
        for _ in range(10):
            app.processEvents()

        text = window.text_recv.toPlainText()
        lines = text.strip().split("\n")
        # 不带时间戳时行不以 [ 开头
        for line in lines:
            if line.strip():
                assert not line.strip().startswith("["), f"不应包含时间戳: {line}"

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_close_serial():
    """功能层: 关闭串口"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        window.combo_port.setCurrentText("MOCK_COM1")
        window.btn_open.click()
        app.processEvents()
        assert window._is_open is True

        window.btn_open.click()
        app.processEvents()
        assert window._is_open is False
        assert window.btn_open.text() == "打开串口"
        assert window.btn_send.isEnabled() is False

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


def test_functional_autoscroll_toggle():
    """功能层: 自动滚屏切换"""
    os.environ["MOCK_SERIAL"] = "1"
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    try:
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)

        from app import MainWindow
        window = MainWindow()
        window.show()
        app.processEvents()

        assert window.check_autoscroll.isChecked() is True
        assert window._is_auto_scroll is True

        window.check_autoscroll.setChecked(False)
        assert window._is_auto_scroll is False

        window.close()
    finally:
        os.environ.pop("MOCK_SERIAL", None)
        os.environ.pop("QT_QPA_PLATFORM", None)


# =========================================================================
# PyQt 可用时导入 pytest（仅用于测试收集）
# =========================================================================

try:
    import pytest
except ImportError:
    pass
