"""
serial_core.py — 串口调试助手核心逻辑层

完全独立于 PyQt5 / pyserial，仅使用 Python 标准库。
包含数据模型、校验、HEX编解码、日志格式化、后端抽象及 Mock 实现。

设计遵循:
  - 核心逻辑零依赖: 仅 dataclasses, abc, time, typing, os, collections, struct
  - 依赖反转: GUI 通过 SerialBackend 抽象接口操作，不直接引用 pyserial
  - 环境切换: MOCK_SERIAL=1 环境变量决定使用 Real/Mock Backend
"""

from __future__ import annotations

import os
import re
import time
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple


# =========================================================================
# 3.1 SerialPortConfig — 串口参数配置（不可变数据类 + 校验）
# =========================================================================

@dataclass(frozen=True)
class SerialPortConfig:
    """串口参数配置（frozen=True 确保不可变）

    Attributes:
        port: 端口名，如 "COM3" 或 "/dev/ttyUSB0"
        baudrate: 波特率，默认 115200
        bytesize: 数据位，默认 8
        parity: 校验位，默认 "None"
        stopbits: 停止位，默认 1.0
        timeout: 超时时间（秒），默认 1.0
    """
    port: str
    baudrate: int = 115200
    bytesize: int = 8
    parity: str = "None"
    stopbits: float = 1.0
    timeout: float = 1.0

    # 合法值常量
    VALID_BAUDRATES: Tuple[int, ...] = (9600, 19200, 38400, 57600, 115200, 256000)
    VALID_BYTESIZES: Tuple[int, ...] = (5, 6, 7, 8)
    VALID_PARITIES: Tuple[str, ...] = ("None", "Even", "Odd", "Mark", "Space")
    VALID_STOPBITS: Tuple[float, ...] = (1, 1.5, 2)

    def validate(self) -> Tuple[bool, str]:
        """校验所有串口参数

        Returns:
            (True, "") 如果所有参数合法
            (False, "错误描述") 如果存在非法参数
        """
        # 端口名不能为空
        if not self.port or self.port.strip() == "":
            return False, "端口名不能为空"

        # 波特率校验
        if self.baudrate not in self.VALID_BAUDRATES:
            valid_bps = ", ".join(str(b) for b in self.VALID_BAUDRATES)
            return False, f"非法波特率 {self.baudrate}，合法值: {valid_bps}"

        # 数据位校验
        if self.bytesize not in self.VALID_BYTESIZES:
            valid_bs = ", ".join(str(b) for b in self.VALID_BYTESIZES)
            return False, f"非法数据位 {self.bytesize}，合法值: {valid_bs}"

        # 校验位校验
        if self.parity not in self.VALID_PARITIES:
            valid_p = ", ".join(self.VALID_PARITIES)
            return False, f"非法校验位 '{self.parity}'，合法值: {valid_p}"

        # 停止位校验（float 比较容差）
        stop_ok = any(abs(self.stopbits - v) < 1e-9 for v in self.VALID_STOPBITS)
        if not stop_ok:
            valid_s = ", ".join(str(s) for s in self.VALID_STOPBITS)
            return False, f"非法停止位 {self.stopbits}，合法值: {valid_s}"

        return True, ""

    def to_dict(self) -> Dict:
        """转为字典格式，方便传给 pyserial"""
        return {
            "port": self.port,
            "baudrate": self.baudrate,
            "bytesize": self.bytesize,
            "parity": self._parity_to_pyserial(),
            "stopbits": self.stopbits,
            "timeout": self.timeout,
        }

    def _parity_to_pyserial(self) -> str:
        """将校验位字符串转为 pyserial 需要的格式"""
        mapping = {
            "None": "N",
            "Even": "E",
            "Odd": "O",
            "Mark": "M",
            "Space": "S",
        }
        return mapping.get(self.parity, "N")


# =========================================================================
# 3.2 SerialFrame — 统一数据帧
# =========================================================================

@dataclass
class SerialFrame:
    """统一数据帧，记录一次收发事件

    Attributes:
        timestamp: time.time() 时间戳
        direction: "TX" 或 "RX"
        raw_data: 原始字节数据
        hex_str: 空格分隔大写HEX字符串，如 "48 65 6C 6C 6F"
        text_str: 可打印字符保留，不可打印替换为 '.'
    """
    timestamp: float
    direction: str
    raw_data: bytes
    hex_str: str = ""
    text_str: str = ""

    def __post_init__(self):
        """如果 hex_str 或 text_str 未赋值，自动生成"""
        if not self.hex_str:
            self.hex_str = hex_encode(self.raw_data)
        if not self.text_str:
            self.text_str = _bytes_to_printable(self.raw_data)


def make_frame(data: bytes, direction: str) -> SerialFrame:
    """从原始字节构造 SerialFrame（工厂函数）

    Args:
        data: 原始字节数据
        direction: "TX" 或 "RX"

    Returns:
        自动填充 hex_str 和 text_str 的 SerialFrame 实例
    """
    return SerialFrame(
        timestamp=time.time(),
        direction=direction,
        raw_data=data,
        hex_str=hex_encode(data),
        text_str=_bytes_to_printable(data),
    )


def _bytes_to_printable(data: bytes) -> str:
    """将字节转为可打印字符串，不可打印字符替换为 '.'

    Args:
        data: 原始字节

    Returns:
        可打印字符串
    """
    return "".join(chr(b) if 32 <= b <= 126 else "." for b in data)


# =========================================================================
# 3.3 HEX 编解码模块
# =========================================================================

_HEX_STRIP_RE = re.compile(r"[ \t\n\r\f\v]+")
_HEX_VALID_RE = re.compile(r"^[0-9A-Fa-f]*$")


def hex_encode(data: bytes) -> str:
    """字节 → 空格分隔大写HEX字符串

    Args:
        data: 原始字节数据

    Returns:
        空格分隔的大写HEX字符串，如 b"Hello" → "48 65 6C 6C 6F"

    Examples:
        >>> hex_encode(b"Hello")
        '48 65 6C 6C 6F'
        >>> hex_encode(b"")
        ''
    """
    if not data:
        return ""
    return " ".join(f"{b:02X}" for b in data)


def hex_decode(hex_str: str) -> bytes:
    """HEX字符串 → 字节

    支持格式:
      - "48 65 6C 6C 6F" (空格分隔)
      - "48656C6C6F" (紧凑)
      - "48\\t65\\n6C" (其他空白)

    非法输入（含非HEX字符、奇数长度）抛出 ValueError

    Args:
        hex_str: HEX 编码字符串

    Returns:
        解码后的字节数据

    Raises:
        ValueError: 输入为空、含非法字符或奇数长度时抛出

    Examples:
        >>> hex_decode("48 65 6C 6C 6F")
        b'Hello'
        >>> hex_decode("48656C6C6F")
        b'Hello'
        >>> hex_decode("")
        b''
    """
    if not hex_str or hex_str.strip() == "":
        return b""

    # 1. 去除所有空白字符
    cleaned = _HEX_STRIP_RE.sub("", hex_str.strip())

    if not cleaned:
        return b""

    # 2. 检查是否只含合法HEX字符
    if not _HEX_VALID_RE.match(cleaned):
        # 找出非法字符
        invalid_chars = set(c for c in cleaned if c not in "0123456789ABCDEFabcdef")
        raise ValueError(f"HEX字符串包含非法字符: {''.join(sorted(invalid_chars))}")

    # 3. 检查长度是否为偶数
    if len(cleaned) % 2 != 0:
        raise ValueError(
            f"HEX字符串长度必须为偶数（当前长度 {len(cleaned)}）: {cleaned}"
        )

    # 4. 使用 bytes.fromhex() 解码
    return bytes.fromhex(cleaned)


# =========================================================================
# 3.4 日志格式化模块
# =========================================================================

def _format_timestamp(ts: float) -> str:
    """将时间戳格式化为 [HH:MM:SS.mmm]

    Args:
        ts: time.time() 时间戳

    Returns:
        格式化的时间戳字符串
    """
    t = time.localtime(ts)
    ms = int((ts - int(ts)) * 1000)
    return f"[{t.tm_hour:02d}:{t.tm_min:02d}:{t.tm_sec:02d}.{ms:03d}]"


def format_frame(frame: SerialFrame, include_timestamp: bool = True) -> str:
    """格式化单帧为日志行

    Args:
        frame: 数据帧
        include_timestamp: 是否包含时间戳前缀

    Returns:
        格式化后的日志行字符串

    Examples:
        include_timestamp=True:
          "[10:30:45.123] TX: 48 65 6C 6C 6F"
        include_timestamp=False:
          "TX: 48 65 6C 6C 6F"
    """
    if include_timestamp:
        ts_str = _format_timestamp(frame.timestamp)
        return f"{ts_str} {frame.direction}: {frame.hex_str}"
    else:
        return f"{frame.direction}: {frame.hex_str}"


def format_log(
    records: List[SerialFrame],
    include_timestamp: bool = True,
) -> str:
    """格式化多帧日志

    Args:
        records: 数据帧列表
        include_timestamp: 是否包含时间戳

    Returns:
        多行日志字符串（每行以换行符结尾，最后一行无多余换行）
    """
    lines = [format_frame(r, include_timestamp=include_timestamp) for r in records]
    return "\n".join(lines)


def save_log(
    filepath: str,
    records: List[SerialFrame],
    include_timestamp: bool = True,
) -> bool:
    """保存日志到文件

    Args:
        filepath: 文件路径
        records: 数据帧列表
        include_timestamp: 是否包含时间戳

    Returns:
        成功返回 True，失败返回 False
    """
    try:
        content = format_log(records, include_timestamp=include_timestamp)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
            f.write("\n")
        return True
    except OSError:
        return False


# =========================================================================
# 3.5 SerialBackend — 抽象基类
# =========================================================================

class SerialBackend(ABC):
    """串口后端抽象接口

    所有串口操作均通过此接口进行，支持 Real/Mock 切换。
    """

    @abstractmethod
    def open(self, config: SerialPortConfig) -> bool:
        """打开串口

        Args:
            config: 串口配置

        Returns:
            成功返回 True
        """
        ...

    @abstractmethod
    def close(self) -> bool:
        """关闭串口

        Returns:
            成功返回 True
        """
        ...

    @abstractmethod
    def send(self, data: bytes) -> int:
        """发送数据

        Args:
            data: 要发送的字节数据

        Returns:
            实际发送的字节数
        """
        ...

    @abstractmethod
    def receive(self) -> Optional[bytes]:
        """接收数据（非阻塞或带超时）

        Returns:
            接收到的字节数据；无数据或超时返回 None
        """
        ...

    @abstractmethod
    def is_open(self) -> bool:
        """串口是否已打开

        Returns:
            打开返回 True
        """
        ...

    @staticmethod
    @abstractmethod
    def list_ports() -> List[str]:
        """列出可用串口

        Returns:
            端口名列表
        """
        ...


# =========================================================================
# 3.6 MockSerialBackend — 模拟后端
# =========================================================================

class MockSerialBackend(SerialBackend):
    """内存模拟串口后端

    无需真实硬件，支持:
      - 模拟打开/关闭
      - 发送数据记录到 tx_buffer
      - 回显模式（echo_mode）：发送的数据自动进入接收队列
      - 预设接收数据（通过 inject_rx）
      - 通过 list_ports 返回虚拟端口列表
    """

    def __init__(self, echo_mode: bool = True):
        self._is_open = False
        self._tx_buffer: List[bytes] = []
        self._rx_queue: Deque[bytes] = deque()
        self._echo_mode = echo_mode
        self._open_config: Optional[SerialPortConfig] = None

    # --- 公开属性 ---

    @property
    def tx_buffer(self) -> List[bytes]:
        """已发送数据历史"""
        return list(self._tx_buffer)

    @property
    def rx_queue_size(self) -> int:
        """接收队列中待读取数据量"""
        return len(self._rx_queue)

    # --- 辅助方法 ---

    def inject_rx(self, data: bytes) -> None:
        """向接收队列注入数据（模拟从串口接收到数据）

        Args:
            data: 要注入的字节数据
        """
        self._rx_queue.append(data)

    def clear_tx_buffer(self) -> None:
        """清空发送历史"""
        self._tx_buffer.clear()

    def clear_rx_queue(self) -> None:
        """清空接收队列"""
        self._rx_queue.clear()

    def reset(self) -> None:
        """完全重置模拟器状态"""
        self._is_open = False
        self._tx_buffer.clear()
        self._rx_queue.clear()
        self._open_config = None

    # --- 后端接口实现 ---

    def open(self, config: SerialPortConfig) -> bool:
        if self._is_open:
            return True  # 已经打开视为成功
        self._is_open = True
        self._open_config = config
        return True

    def close(self) -> bool:
        if not self._is_open:
            return False
        self._is_open = False
        self._open_config = None
        return True

    def send(self, data: bytes) -> int:
        if not self._is_open:
            return 0
        if not data:
            return 0
        self._tx_buffer.append(data)
        if self._echo_mode:
            # 回显模式：发送的数据自动回填到接收队列
            self._rx_queue.append(data)
        return len(data)

    def receive(self) -> Optional[bytes]:
        if not self._is_open:
            return None
        if self._rx_queue:
            return self._rx_queue.popleft()
        return None

    def is_open(self) -> bool:
        return self._is_open

    @staticmethod
    def list_ports() -> List[str]:
        return ["MOCK_COM1", "MOCK_COM2"]


# =========================================================================
# 3.7 RealSerialBackend — 真实串口后端（基于 pyserial）
# =========================================================================

class RealSerialBackend(SerialBackend):
    """基于 pyserial 的真实串口实现

    当 pyserial 不可用时，open() 会返回失败。
    """

    def __init__(self):
        self._serial: Optional["serial.Serial"] = None
        self._serial_available = False
        self._import_error: Optional[str] = None

        # 尝试导入 pyserial
        try:
            import serial  # type: ignore[import-untyped]
            self._serial_module = serial
            self._serial_available = True
        except ImportError as e:
            self._serial_available = False
            self._import_error = str(e)

    def open(self, config: SerialPortConfig) -> bool:
        if not self._serial_available:
            return False

        if self._serial and self._serial.is_open:
            self.close()

        try:
            ser = self._serial_module.Serial(
                port=config.port,
                baudrate=config.baudrate,
                bytesize=config.bytesize,
                parity=config._parity_to_pyserial(),
                stopbits=config.stopbits,
                timeout=config.timeout,
            )
            self._serial = ser
            return True
        except Exception:
            self._serial = None
            return False

    def close(self) -> bool:
        if self._serial is None:
            return False
        try:
            if self._serial.is_open:
                self._serial.close()
            self._serial = None
            return True
        except Exception:
            self._serial = None
            return False

    def send(self, data: bytes) -> int:
        if self._serial is None or not self._serial.is_open:
            return 0
        try:
            return self._serial.write(data)
        except Exception:
            return 0

    def receive(self) -> Optional[bytes]:
        if self._serial is None or not self._serial.is_open:
            return None
        try:
            # 尝试读取所有可用的数据（最多 4096 字节）
            if self._serial.in_waiting > 0:
                data = self._serial.read(self._serial.in_waiting)
                return data if data else None
            return None
        except Exception:
            return None

    def is_open(self) -> bool:
        if self._serial is None:
            return False
        try:
            return self._serial.is_open
        except Exception:
            return False

    @staticmethod
    def list_ports() -> List[str]:
        """列出系统可用串口

        如果 pyserial 不可用或出错，返回空列表。
        """
        try:
            import serial.tools.list_ports  # type: ignore[import-untyped]
            return [p.device for p in serial.tools.list_ports.comports()]
        except (ImportError, Exception):
            return []


# =========================================================================
# 3.8 后端工厂函数
# =========================================================================

def create_backend() -> SerialBackend:
    """创建串口后端实例

    策略:
      1. 如果 MOCK_SERIAL=1，返回 MockSerialBackend
      2. 尝试导入 pyserial，成功则返回 RealSerialBackend
      3. 失败则回退到 MockSerialBackend 并打印警告

    Returns:
        SerialBackend 实例
    """
    if os.environ.get("MOCK_SERIAL") == "1":
        return MockSerialBackend()

    try:
        import serial  # noqa: F401
        return RealSerialBackend()
    except ImportError:
        import sys
        print("警告: pyserial 未安装，使用 MockSerialBackend", file=sys.stderr)
        return MockSerialBackend()


# =========================================================================
# 空发送检查工具
# =========================================================================

def is_empty_payload(data: bytes) -> bool:
    """检查数据是否为空载荷

    空数据（None 或 b""）应直接返回，不产生 TX 帧或写入日志。

    Args:
        data: 待检查的字节数据

    Returns:
        空数据返回 True
    """
    return data is None or len(data) == 0
