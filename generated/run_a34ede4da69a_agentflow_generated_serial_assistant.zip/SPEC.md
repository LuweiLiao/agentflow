# PyQt 串口调试助手 — 规格细化文档 (PRD + 验收清单 + 测试矩阵)

---

## 一、产品需求文档 (PRD)

### 1. 项目概述
基于 PyQt5 实现跨平台串口调试助手，采用 AgentFlow 编排的闭环开发流程（开发→测试→审查→反馈→返修），核心逻辑与 GUI 完全解耦，支持 Mock 模式自测。

### 2. 技术栈
| 组件 | 技术选型 | 版本约束 |
|------|----------|----------|
| GUI 框架 | PyQt5 | >=5.15 |
| 串口通信 | pyserial | >=3.5 |
| 测试框架 | pytest | >=7.0 |
| Mock 环境 | unittest.mock / MockSerialBackend | 内置 |
| 运行环境 | Python | >=3.8 |

### 3. 功能需求

#### 3.1 GUI 控件清单
| 控件组 | 具体控件 | 说明 |
|--------|----------|------|
| 端口选择 | QComboBox | 自动枚举可用串口，支持刷新 |
| 波特率 | QComboBox | 9600, 19200, 38400, 57600, 115200, 256000 |
| 数据位 | QComboBox | 5, 6, 7, 8 (默认8) |
| 停止位 | QComboBox | 1, 1.5, 2 |
| 校验位 | QComboBox | None, Even, Odd, Mark, Space |
| 打开/关闭按钮 | QPushButton | 状态联动文字切换 |
| 发送区 | QTextEdit + QCheckBox | 文本输入框 + HEX 发送勾选框 |
| 发送按钮 | QPushButton | 点击发送数据 |
| 接收区 | QTextEdit (只读) | 显示接收数据 |
| 时间戳 | QCheckBox | 每行前加 [HH:MM:SS.ms] |
| 自动滚屏 | QCheckBox | 自动滚动到底部 |
| 清空按钮 | QPushButton | 清空接收区 |
| 保存日志 | QPushButton | 保存接收区内容到文件 |

#### 3.2 串口参数配置 (SerialPortConfig)
```
SerialPortConfig:
  port: str          # 串口名，如 "COM3" 或 "/dev/ttyUSB0"
  baudrate: int      # 波特率，默认 115200
  bytesize: int      # 数据位，默认 8
  parity: str        # 校验位，默认 "None"
  stopbits: float    # 停止位，默认 1.0
  timeout: float     # 超时时间，默认 1.0
```

**校验规则**：
- port 不能为空字符串
- baudrate ∈ {9600, 19200, 38400, 57600, 115200, 256000}
- bytesize ∈ {5, 6, 7, 8}
- parity ∈ {"None", "Even", "Odd", "Mark", "Space"}
- stopbits ∈ {1, 1.5, 2}

#### 3.3 数据帧格式 (SerialFrame)
```python
@dataclass
class SerialFrame:
    timestamp: float        # 时间戳（time.time()）
    direction: str          # "TX" 或 "RX"
    raw_data: bytes         # 原始字节数据
    hex_str: str            # HEX 字符串，如 "48 65 6C 6C 6F"
    text_str: str           # 文本表示（可打印字符保留，不可打印用 . 替换）
```

#### 3.4 后端接口设计

**SerialBackend 抽象基类**：
- `open(config: SerialPortConfig) -> bool`
- `close() -> bool`
- `send(data: bytes) -> int`
- `receive() -> Optional[bytes]`
- `is_open() -> bool`
- `list_ports() -> List[str]`

**MockSerialBackend**（环境变量 `MOCK_SERIAL=1` 时启用）：
- 模拟串口打开/关闭
- 发送数据回显（echo 模式）
- 支持预设接收数据队列
- 无真实硬件依赖

#### 3.5 HEX 编解码模块
- `hex_encode(data: bytes) -> str`：字节 → 空格分隔大写HEX，如 `b"Hello"` → `"48 65 6C 6C 6F"`
- `hex_decode(hex_str: str) -> bytes`：HEX字符串 → 字节
  - 合法输入：`"48 65"`、`"4865"`、`"48\t65"`、`"48\n65"` 均支持
  - 非法输入（含非HEX字符、奇数长度）抛出 `ValueError`

#### 3.6 日志格式化模块
- `format_log(records: List[SerialFrame], include_timestamp: bool = True) -> str`：按行格式化日志
- `save_log(filepath: str, records: List[SerialFrame], include_timestamp: bool) -> bool`：保存到文件

### 4. 错误处理策略
| 场景 | 处理方式 |
|------|----------|
| 串口打开失败（端口不存在/被占用） | GUI 弹出 QMessageBox.warning，按钮恢复为"打开串口" |
| 发送空数据 | 直接忽略，不调用底层 send |
| HEX 输入非法 | QMessageBox.warning 提示"HEX格式错误"，不发送 |
| 接收超时 | 返回空，不抛异常 |
| 日志保存路径无权限 | 捕获 OSError，弹出错误提示 |
| Mock 模式无 pyserial | 优雅降级，使用 MockSerialBackend |

### 5. 闭环开发流程 (AgentFlow 编排)

```
开发节点 → 测试节点 → 审查节点
    ↑          |           |
    |          |   (失败)  |   (失败)
    +----------+-----------+
     feedback_history 反馈返修
```

- **开发节点**：生成源代码文件，附带 `feedback_history` 参数携带上一轮反馈
- **测试节点**：执行 pytest 测试，失败时收集具体断言/异常信息
- **审查节点**：静态分析（flake8/mypy）、检查文件完整性、关键词检测
- **闭环反馈**：测试/审查失败 → 将失败证据（diff、log、traceback）打包为 feedback_history → 传回开发节点 → 开发根据反馈修改后重新提交测试

---

## 二、验收清单 (Acceptance Checklist)

### A. 文件完整性 [必须全部通过]
- [ ] A1. `serial_core.py` — 核心逻辑模块（SerialPortConfig, SerialFrame, SerialBackend, MockSerialBackend, HEX编解码, 日志格式化）
- [ ] A2. `serial_gui.py` — PyQt5 GUI 主程序
- [ ] A3. `test_serial_core.py` — 核心逻辑单元测试
- [ ] A4. `test_serial_gui.py` — GUI smoke test
- [ ] A5. `requirements.txt` — 依赖清单
- [ ] A6. `run.sh` — 一键运行脚本（Mock 模式）
- [ ] A7. `SPEC.md` — 本规格文档

### B. 功能验收 [手动/自动验证]
- [ ] B1. 串口端口枚举：启动时自动填充 QComboBox
- [ ] B2. 参数选择：波特率/数据位/停止位/校验位可选
- [ ] B3. 打开/关闭串口：按钮文字联动、状态正确
- [ ] B4. 文本发送：普通 ASCII 文本发送正常
- [ ] B5. HEX 发送：勾选 HEX 后发送十六进制数据
- [ ] B6. 接收显示：接收区实时显示数据
- [ ] B7. 时间戳：勾选后在每行前加时间戳
- [ ] B8. 自动滚屏：勾选后自动滚动到底部
- [ ] B9. 清空接收区：一键清空
- [ ] B10. 保存日志：保存到文件，内容完整

### C. Mock 模式验收
- [ ] C1. `MOCK_SERIAL=1` 环境变量下无需真实串口
- [ ] C2. 无 pyserial 时自动回退 MockSerialBackend
- [ ] C3. Mock 模式下发送的数据可在接收区回显

### D. 错误处理验收
- [ ] D1. 打开不存在的串口 → 弹出错误提示，不崩溃
- [ ] D2. 发送空数据 → 静默忽略
- [ ] D3. 非法 HEX 输入 → 弹出错误提示
- [ ] D4. 关闭已关闭的串口 → 不做任何操作
- [ ] D5. 打开已打开的串口 → 先关闭再打开

### E. 闭环流程验收
- [ ] E1. 测试失败时会输出具体断言/异常信息
- [ ] E2. 审查失败会输出具体缺失项
- [ ] E3. feedback_history 包含足够上下文用于返修

---

## 三、测试矩阵 (Test Matrix)

### 3.1 核心逻辑单元测试 (test_serial_core.py)

| 编号 | 测试用例 | 类别 | 预期结果 |
|------|----------|------|----------|
| TC01 | 有效配置 SerialPortConfig 校验通过 | 配置校验 | 返回 `True` |
| TC02 | 空端口名校验失败 | 配置校验 | 返回 `False` 或抛出 ValueError |
| TC03 | 非法波特率 12345 校验失败 | 配置校验 | 返回 `False` |
| TC04 | 非法数据位 9 校验失败 | 配置校验 | 返回 `False` |
| TC05 | 非法停止位 3 校验失败 | 配置校验 | 返回 `False` |
| TC06 | 合法 HEX 输入 "48 65 6C 6C 6F" 解码 | HEX 编解码 | `b"Hello"` |
| TC07 | 紧凑 HEX "48656C6C6F" 解码 | HEX 编解码 | `b"Hello"` |
| TC08 | 非法 HEX 含 "GG" 抛出异常 | HEX 编解码 | `ValueError` |
| TC09 | 奇数长度 HEX "48 6" 抛出异常 | HEX 编解码 | `ValueError` |
| TC10 | 空字符串 HEX 解码 | HEX 编解码 | `b""` |
| TC11 | 文本发送: bytes("Hello") | 文本发送 | 通过 Mock 验证发送内容 |
| TC12 | HEX 发送: hex_decode("48656C6C6F") | HEX 发送 | 通过 Mock 验证发送内容 |
| TC13 | SerialFrame 时间戳格式正确 | 接收帧格式 | timestamp 为 float，范围合理 |
| TC14 | SerialFrame HEX 字符串格式 | 接收帧格式 | 大写字母，双字符，空格分隔 |
| TC15 | SerialFrame 不可打印字符替换为 "." | 接收帧格式 | text_str 无控制字符 |
| TC16 | 日志格式化包含时间戳 | 日志保存 | 每行以 `[` 开头 |
| TC17 | 日志格式化不包含时间戳 | 日志保存 | 每行以 `TX:` 或 `RX:` 开头 |
| TC18 | 日志保存到文件 | 日志保存 | 文件存在，内容非空 |
| TC19 | MockSerialBackend 打开/关闭 | Mock 模式 | 返回 True，状态正确 |
| TC20 | MockSerialBackend 发送接收回显 | Mock 模式 | 发送的数据可接收回来 |

### 3.2 GUI Smoke Test (test_serial_gui.py)

| 编号 | 测试用例 | 类别 | 预期结果 |
|------|----------|------|----------|
| TC21 | PyQt5 模块导入成功 | Import | 无 ImportError |
| TC22 | serial_gui.py 中 MainWindow 类存在 | Smoke | 类定义成功 |
| TC23 | ofscreen 模式下窗口创建无崩溃 | Smoke | QApplication 初始化正常 |
| TC24 | 控件存在性检查 | Smoke | 关键控件引用正常 |
| TC25 | Mock 模式下整体 import 无阻塞 | Smoke | 无弹窗、无异常 |

### 3.3 审查验证 (QualityGate)

| 命令 | 检查项 | 预期 |
|------|--------|------|
| `test -s SPEC.md` | SPEC.md 非空 | 返回 0 |
| `grep -q '闭环' SPEC.md` | 含"闭环"关键词 | 返回 0 |
| `grep -q 'HEX' SPEC.md` | 含"HEX"关键词 | 返回 0 |
| `grep -q '验收' SPEC.md` | 含验收清单 | 返回 0 |
| `grep -q '测试矩阵' SPEC.md` | 含测试矩阵 | 返回 0 |
| `test -f serial_core.py` | 核心模块存在 | 返回 0 |
| `test -f serial_gui.py` | GUI模块存在 | 返回 0 |
| `python -c "import serial_core"` | 模块可导入 | 无 ImportError |
| `python -c "import ast; ast.parse(open('serial_core.py').read())"` | 语法正确 | 无 SyntaxError |
| `QT_QPA_PLATFORM=offscreen python -c "exec(open('serial_gui.py').read())"` | GUI 无阻塞 | 无弹窗、无崩溃 |

---

## 四、文件清单与依赖

### 源文件
```
serial_core.py      # 核心逻辑（~300行）
serial_gui.py       # GUI 界面（~400行）
```

### 测试文件
```
test_serial_core.py # 核心逻辑单元测试（~200行）
test_serial_gui.py  # GUI smoke test（~80行）
```

### 配置文件
```
requirements.txt    # PyQt5, pyserial, pytest
run.sh              # MOCK_SERIAL=1 python serial_gui.py
SPEC.md             # 本文档
```

### Python 依赖 (requirements.txt)
```
PyQt5>=5.15
pyserial>=3.5
pytest>=7.0
```

---

## 五、架构设计要点

### 解耦原则
```
GUI (serial_gui.py) ──信号/槽──→ Backend Interface ←── MockSerialBackend
                                        ↑
                                  SerialBackend (ABC)
                                        ↑
                                RealSerialBackend (pyserial)
```

- GUI 不直接依赖 pyserial，只依赖后端抽象接口
- MockSerialBackend 与 RealSerialBackend 互换，通过环境变量控制
- 所有数据帧统一使用 SerialFrame 类型，GUI 中仅做展示

### 线程安全
- 串口接收使用 QThread + pyqtSignal 异步回调
- GUI 更新必须通过信号槽回到主线程
- 发送操作在主线程执行（发送数据量小，不阻塞）

---

*本文档为 AgentFlow 闭环开发流程的规格细化产物，随迭代持续更新。*
