# PyQt5 串口调试助手

> 基于 PyQt5 的跨平台串口调试工具，核心逻辑与 GUI 完全解耦，支持 Mock 模式自测。
> 采用 AgentFlow 编排的闭环开发流程（开发→测试→审查→反馈→返修），152 测试全通过。

---

## 📦 功能清单

### 串口配置
| 功能 | 说明 |
|------|------|
| 端口选择 | QComboBox 自动枚举可用串口，支持刷新 |
| 波特率 | 9600 / 19200 / 38400 / 57600 / 115200 / 256000 |
| 数据位 | 5 / 6 / 7 / 8 |
| 停止位 | 1 / 1.5 / 2 |
| 校验位 | None / Even / Odd / Mark / Space |
| 打开/关闭 | 按钮文字联动切换，状态正确 |

### 数据通信
| 功能 | 说明 |
|------|------|
| 文本发送 | 普通 ASCII / UTF-8 文本发送 |
| HEX 发送 | 十六进制数据发送（支持空格分隔、紧凑格式） |
| 接收显示 | 实时显示接收数据，使用等宽字体 |
| 时间戳 | 每行前加 `[HH:MM:SS.mmm]` 时间戳（可开关） |
| 自动滚屏 | 接收数据自动滚动到底部（可开关） |

### 工具功能
| 功能 | 说明 |
|------|------|
| 清空接收区 | 一键清空所有接收内容及记录 |
| 保存日志 | 保存完整收发记录到文件（含时间戳选项） |
| Mock 模式 | `MOCK_SERIAL=1` 时无需真实串口，数据回显自测 |

### 错误处理
| 场景 | 处理方式 |
|------|----------|
| 串口打开失败 | QMessageBox / 状态栏提示，不崩溃 |
| 发送空数据 | 静默忽略，不产生 TX 帧 |
| HEX 输入非法 | 弹出错误提示，不发送 |
| 接收超时 | 返回空，不抛异常 |
| 日志保存失败 | OSError 捕获，提示错误 |

---

## 🚀 快速开始

### 环境要求
- Python >= 3.8
- PyQt5 >= 5.15
- pyserial >= 3.5（可选，Mock 模式不需要）

### 安装依赖

```bash
pip install -r requirements.txt
```

### Mock 模式运行（无需真实串口）

```bash
MOCK_SERIAL=1 python app.py
```

Mock 模式下：
- 自动使用 `MockSerialBackend`（内存模拟串口）
- 虚拟端口列表：`MOCK_COM1`, `MOCK_COM2`
- 发送的数据通过 echo 模式自动回显到接收区
- 无需任何真实串口硬件

### 真实串口模式

```bash
python app.py
```

需要系统中有可用的串口设备（如 `COM3`、`/dev/ttyUSB0`）。

### 一键运行脚本

```bash
chmod +x run.sh
./run.sh
```

---

## 🧪 运行测试

### 全部测试（152 项）

```bash
MOCK_SERIAL=1 QT_QPA_PLATFORM=offscreen python -m pytest tests/ -v
```

### 分层测试

#### 第1层：核心逻辑单元测试（无需 PyQt5）

```bash
python -m pytest tests/test_serial_core.py -v
```

覆盖：配置校验、HEX 编解码、文本/HEX 发送、SerialFrame 格式、日志格式化、MockSerialBackend

#### 第2层：GUI 烟雾测试（需 PyQt5 + offscreen）

```bash
QT_QPA_PLATFORM=offscreen python -m pytest tests/test_serial_gui.py -v
```

覆盖：PyQt5 导入、MainWindow 类定义、offscreen 窗口创建、控件存在性、Mock 模式 import

#### 第3层：端到端功能测试（Mock 模式 + offscreen）

```bash
MOCK_SERIAL=1 QT_QPA_PLATFORM=offscreen python -m pytest tests/test_gui_functional.py -v
```

覆盖：打开/关闭 Mock 串口、文本发送回显、HEX 发送、空发送、非法 HEX 提示、清空、保存日志、时间戳切换

#### 综合烟雾测试

```bash
MOCK_SERIAL=1 QT_QPA_PLATFORM=offscreen python -m pytest tests/test_app_smoke.py -v
```

---

## 📁 项目结构

```
├── README.md                 # 🔵 本文档 - 项目说明、安装、运行指南
├── requirements.txt          # 🔵 Python 依赖清单
├── run.sh                    # 🔵 一键 Mock 模式启动脚本
│
├── SPEC.md                   # 规格细化文档（PRD + 验收清单 + 测试矩阵）
├── ARCHITECTURE.md           # 架构设计文档（三层架构、模块详解）
├── REVIEW.md                 # 产品细节审查报告
│
├── app.py                    # GUI 层 — PyQt5 主窗口（~450 行）
├── serial_core.py            # 核心逻辑层 — 数据模型/校验/编解码/日志/Backend（~500 行）
│
├── tests/
│   ├── test_serial_core.py   # 单元测试 — 核心逻辑（84 测试）
│   ├── test_serial_gui.py    # 烟雾测试 — GUI 导入/控件（24 测试）
│   ├── test_gui_functional.py# 集成测试 — Mock 端到端功能（12 测试）
│   └── test_app_smoke.py     # 综合烟雾 — 3 层全覆盖（32 测试）
│
├── fix_test.py               # 测试修复脚本（闭环反馈证据）
└── fix_test2.py              # 测试修复脚本（闭环反馈证据）
```

---

## 🏗️ 架构概览

### 三层解耦设计

```
┌──────────────────────────────────────────────────────┐
│                  GUI 层 (View)                        │
│                app.py (MainWindow)                    │
│  控件: QComboBox / QTextEdit / QPushButton / ...      │
│  线程: SerialWorker (QThread) + pyqtSignal            │
└──────────────────────┬───────────────────────────────┘
                       │ 调用 Backend 抽象接口
                       ▼
┌──────────────────────────────────────────────────────┐
│              核心逻辑层 (Model)                        │
│               serial_core.py                          │
│                                                       │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐  │
│  │SerialPort │  │SerialFrame│  │HEX编解码/日志格式化│  │
│  │ Config    │  │ 数据帧    │  │                   │  │
│  └─────┬─────┘  └─────┬────┘  └────────┬──────────┘  │
│        │              │                │              │
│        ▼              ▼                ▼              │
│  ┌──────────────────────────────────────────────┐     │
│  │          SerialBackend (ABC 抽象基类)          │     │
│  └──────────┬───────────────────────┬───────────┘     │
│             │                       │                  │
│      ┌──────▼──────┐        ┌──────▼──────┐          │
│      │RealSerial   │        │MockSerial   │           │
│      │ Backend     │        │ Backend     │           │
│      │ (pyserial)  │        │ (内存队列)  │           │
│      └─────────────┘        └─────────────┘           │
└──────────────────────┬───────────────────────────────┘
                       │ pytest 测试覆盖
                       ▼
┌──────────────────────────────────────────────────────┐
│               测试层 (Tests) 152 passed               │
│  test_serial_core.py  (84) ← 零依赖单元测试           │
│  test_serial_gui.py   (24) ← GUI 烟雾测试             │
│  test_gui_functional.py(12) ← 端到端集成测试           │
│  test_app_smoke.py    (32) ← 综合烟雾测试              │
└──────────────────────────────────────────────────────┘
```

### 核心设计原则

1. **核心逻辑零依赖** — `serial_core.py` 仅使用 Python 标准库（dataclasses, abc, time），不依赖 PyQt5 或 pyserial
2. **依赖反转** — GUI 通过 `SerialBackend` 抽象接口操作串口，不直接引用 pyserial
3. **环境切换** — `MOCK_SERIAL=1` 环境变量决定使用 Real 还是 Mock Backend
4. **线程隔离** — 串口接收在 `QThread` 中运行，通过 `pyqtSignal` 回传数据到主线程
5. **闭环可测试** — 所有核心函数均可脱离 GUI 单独单元测试

---

## 🧪 测试报告摘要

### 总览

| 指标 | 数值 |
|------|:----:|
| 测试总数 | **152** |
| 通过 | **152 (100%)** |
| 失败 | **0** |
| 执行时间 | **3.36 秒** |
| 测试文件数 | **4** |

### 分层覆盖

| 层级 | 文件 | 测试数 | 覆盖内容 |
|:----:|------|:------:|----------|
| 🟢 第1层 | `test_serial_core.py` | 84 | 配置校验、HEX 编解码、文本/HEX 发送、SerialFrame、日志格式、Mock 后端 |
| 🟢 第2层 | `test_serial_gui.py` | 24 | PyQt5 导入、窗口创建、控件存在性、Mock import |
| 🟢 第3层 | `test_gui_functional.py` | 12 | 打开/关闭串口、发送文本/HEX、空发送、非法 HEX、清空、保存日志、时间戳 |
| 🟢 综合 | `test_app_smoke.py` | 32 | 三层全覆盖烟雾测试、边界条件、异常路径 |

### 测试矩阵覆盖

| 测试类别 | 覆盖状态 | 测试用例 |
|----------|:--------:|----------|
| 配置校验 (TC01~TC05) | ✅ 全覆盖 | 合法/非法端口、波特率、数据位、停止位、校验位 |
| HEX 编解码 (TC06~TC10) | ✅ 全覆盖 | 空格/紧凑/Tab/换行/混合空白、非法字符、奇数长度、空字符串 |
| 文本/HEX 发送 (TC11~TC12) | ✅ 全覆盖 | ASCII、中文 UTF-8、二进制、空数据 |
| 接收帧格式 (TC13~TC15) | ✅ 全覆盖 | 时间戳格式、HEX 大写间距、不可打印字符替换 |
| 日志保存 (TC16~TC18) | ✅ 全覆盖 | 含/不含时间戳、有效路径、无效路径 |
| Mock 后端 (TC19~TC20) | ✅ 全覆盖 | 打开/关闭、发送接收回显、预设数据注入、重置 |
| GUI 烟雾 (TC21~TC25) | ✅ 全覆盖 | 导入、类定义、窗口创建、控件存在、Mock import |

---

## 🔄 闭环开发流程

本项目采用 AgentFlow 编排的闭环开发流程：

```
开发节点 ──→ 测试节点 ──→ 审查节点
   ↑              │              │
   │     (失败)    │     (失败)   │
   └─────── 反馈返修 ────────────┘
```

1. **开发节点**：生成源代码，附带 `feedback_history` 参数携带上一轮反馈
2. **测试节点**：执行 pytest 测试，失败时收集具体断言/异常信息
3. **审查节点**：静态分析、文件完整性检查、关键词检测
4. **闭环反馈**：测试/审查失败 → 打包失败证据 → 传回开发节点 → 返修后重新测试

---

## 📝 许可

MIT License

*本文档由 AgentFlow doc Agent 自动生成，伴随项目迭代持续更新。*
