"""
app.py — PyQt5 串口调试助手 GUI 应用

基于 serial_core.py 核心逻辑层构建，实现完整的串口调试界面。

特性：
- 端口/波特率/数据位/停止位/校验位配置
- 打开/关闭串口
- 文本/HEX 发送
- 接收数据显示（支持时间戳、自动滚屏）
- 清空接收区、保存日志
- MOCK_SERIAL=1 环境变量支持 Mock 模式自测

设计原则：
- 核心逻辑依赖 serial_core.py，GUI 与逻辑解耦
- PyQt5 导入异常时提供友好的 fallback，不阻塞测试
- 入口在 if __name__ == "__main__" 中
- create_test_app() 自动确保 QApplication 存在，防止测试框架遗漏
"""

from __future__ import annotations

import os
import sys
import time
from typing import Optional

# ---- PyQt5 导入保护 ----
try:
    from PyQt5.QtCore import QTimer, Qt
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QGridLayout, QGroupBox, QComboBox, QPushButton, QCheckBox,
        QPlainTextEdit, QLabel, QFileDialog, QMessageBox, QStatusBar,
        QSplitter, QFrame,
    )
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False
    # 提供桩类使得模块可以导入但不运行
    class QApplication:
        """桩类：支持 QApplication.instance()"""
        _instance = None
        def __init__(self, *args, **kwargs):
            QApplication._instance = self
        @classmethod
        def instance(cls):
            return cls._instance

    class QMainWindow: pass
    class QWidget: pass
    class QVBoxLayout: pass
    class QHBoxLayout: pass
    class QGridLayout: pass
    class QGroupBox: pass
    class QComboBox: pass
    class QPushButton: pass
    class QCheckBox: pass
    class QPlainTextEdit: pass
    class QLabel: pass
    class QFileDialog: pass
    class QMessageBox: pass
    class QStatusBar: pass
    class QSplitter: pass
    class QFrame: pass

    class QTimer:
        """桩类"""
        def __init__(self, *args, **kwargs): pass
        def timeout(self, *args, **kwargs): pass
        def start(self, *args, **kwargs): pass
        def stop(self, *args, **kwargs): pass
        class SingleShot:
            @staticmethod
            def singleShot(*args, **kwargs): pass

    class Qt:
        AlignLeft = 0
        AlignRight = 0
        ScrollBarAlwaysOn = 2
        ScrollBarAlwaysOff = 0


# ---- 从 serial_core 导入核心逻辑 ----
from serial_core import (
    SerialPortConfig,
    SerialFrame,
    MockSerialBackend,
    create_backend,
    hex_to_bytes,
    bytes_to_hex,
    is_valid_hex,
    format_frame,
    save_log,
)


# =====================================================================
# 工具函数：确保 QApplication 存在
# =====================================================================

# Keep a module-level strong reference to QApplication.
# PyQt can abort at C++ level if QApplication is created in a helper and
# immediately garbage-collected before QWidget/QMainWindow construction.
_QAPP_REF = None


def _ensure_qapplication() -> QApplication:
    """确保存在 QApplication 实例，如没有则创建并保持强引用

    这是防御性设计：当测试框架或外部调用者忘记创建 QApplication 时，
    自动创建实例并在模块级保存强引用，避免 Qt 报
    "QWidget: Must construct a QApplication before a QWidget" 后直接 abort。

    Returns:
        QApplication 实例
    """
    global _QAPP_REF
    if not PYQT5_AVAILABLE:
        _QAPP_REF = QApplication.instance() or _QAPP_REF or QApplication([])
        return _QAPP_REF
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    _QAPP_REF = app
    return app


def _is_headless_test_mode() -> bool:
    """Return True when modal dialogs would block automated/offscreen tests."""
    return (
        os.environ.get("QT_QPA_PLATFORM") == "offscreen"
        or os.environ.get("MOCK_SERIAL") == "1"
        or os.environ.get("PYTEST_CURRENT_TEST") is not None
    )


def _safe_message(parent, level: str, title: str, message: str):
    """Show a user message without blocking headless/offscreen test runs."""
    if _is_headless_test_mode() or not PYQT5_AVAILABLE:
        if parent is not None:
            try:
                parent._last_message = {"level": level, "title": title, "message": message}
                status_bar = parent.statusBar() if hasattr(parent, "statusBar") else None
                if status_bar is not None:
                    status_bar.showMessage(f"{title}: {message}")
            except Exception:
                pass
        return None
    if level == "warning":
        return QMessageBox.warning(parent, title, message)
    if level == "information":
        return QMessageBox.information(parent, title, message)
    return QMessageBox.information(parent, title, message)


# =====================================================================
# PortWidget — 串口配置控件组
# =====================================================================

class PortWidget(QGroupBox):
    """串口配置控件组：端口选择、波特率、数据位、停止位、校验位、打开/关闭"""

    VALID_BAUDRATES = [9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600]
    VALID_DATA_BITS = [5, 6, 7, 8]
    VALID_STOP_BITS = [1.0, 1.5, 2.0]
    VALID_PARITIES = [("N", "无"), ("E", "偶校验"), ("O", "奇校验"), ("S", "空格"), ("M", "标记")]

    def __init__(self, backend, parent=None):
        super().__init__("串口配置", parent)
        self._backend = backend
        self._is_open = False
        self._init_ui()
        self._connect_signals()

    def _init_ui(self):
        layout = QGridLayout()

        # 端口
        layout.addWidget(QLabel("端口:"), 0, 0)
        self.port_combo = QComboBox()
        self.port_combo.setEditable(True)
        self.port_combo.setMinimumWidth(120)
        self._populate_ports()
        layout.addWidget(self.port_combo, 0, 1)

        # 刷新端口按钮
        self.refresh_btn = QPushButton("🔄 刷新")
        self.refresh_btn.setToolTip("重新扫描可用串口")
        layout.addWidget(self.refresh_btn, 0, 2)

        # 打开/关闭按钮
        self.open_close_btn = QPushButton("📤 打开串口")
        self.open_close_btn.setStyleSheet(
            "QPushButton { background-color: #4CAF50; color: white; font-weight: bold; "
            "padding: 6px 16px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #45a049; }"
        )
        layout.addWidget(self.open_close_btn, 0, 3, 1, 2)

        # 波特率
        layout.addWidget(QLabel("波特率:"), 1, 0)
        self.baudrate_combo = QComboBox()
        for b in self.VALID_BAUDRATES:
            self.baudrate_combo.addItem(str(b), b)
        self.baudrate_combo.setCurrentText("9600")
        layout.addWidget(self.baudrate_combo, 1, 1)

        # 数据位
        layout.addWidget(QLabel("数据位:"), 1, 2)
        self.data_bits_combo = QComboBox()
        for b in self.VALID_DATA_BITS:
            self.data_bits_combo.addItem(str(b), b)
        self.data_bits_combo.setCurrentText("8")
        layout.addWidget(self.data_bits_combo, 1, 3)

        # 停止位
        layout.addWidget(QLabel("停止位:"), 2, 0)
        self.stop_bits_combo = QComboBox()
        for b in self.VALID_STOP_BITS:
            self.stop_bits_combo.addItem(str(b), b)
        self.stop_bits_combo.setCurrentText("1.0")
        layout.addWidget(self.stop_bits_combo, 2, 1)

        # 校验位
        layout.addWidget(QLabel("校验位:"), 2, 2)
        self.parity_combo = QComboBox()
        for val, label in self.VALID_PARITIES:
            self.parity_combo.addItem(label, val)
        layout.addWidget(self.parity_combo, 2, 3)

        self.setLayout(layout)

    def _connect_signals(self):
        self.open_close_btn.clicked.connect(self._on_open_close_clicked)
        self.refresh_btn.clicked.connect(self._populate_ports)

    def _populate_ports(self):
        """扫描可用串口并填充下拉列表"""
        current = self.port_combo.currentText()
        self.port_combo.clear()

        # 尝试通过 pyserial 获取串口列表
        ports = []
        try:
            import serial.tools.list_ports
            ports = [p.device for p in serial.tools.list_ports.comports()]
        except ImportError:
            pass

        # Mock 模式下提供示例端口
        if os.environ.get("MOCK_SERIAL") == "1" or not ports:
            ports = ["COM1", "COM2", "COM3", "/dev/ttyUSB0", "/dev/ttyS0"]

        # 去重
        seen = set()
        for p in ports:
            if p not in seen:
                self.port_combo.addItem(p)
                seen.add(p)

        # 恢复之前的选中项
        idx = self.port_combo.findText(current)
        if idx >= 0:
            self.port_combo.setCurrentIndex(idx)

    def get_config(self) -> SerialPortConfig:
        """获取当前配置"""
        return SerialPortConfig(
            port=self.port_combo.currentText().strip(),
            baudrate=int(self.baudrate_combo.currentData()),
            data_bits=int(self.data_bits_combo.currentData()),
            stop_bits=float(self.stop_bits_combo.currentData()),
            parity=str(self.parity_combo.currentData()),
        )

    def set_controls_enabled(self, enabled: bool):
        """启用/禁用配置控件"""
        self.port_combo.setEnabled(enabled)
        self.baudrate_combo.setEnabled(enabled)
        self.data_bits_combo.setEnabled(enabled)
        self.stop_bits_combo.setEnabled(enabled)
        self.parity_combo.setEnabled(enabled)
        self.refresh_btn.setEnabled(enabled)

    def is_open(self) -> bool:
        return self._is_open

    def _on_open_close_clicked(self):
        """打开/关闭串口切换"""
        if not self._is_open:
            self._try_open()
        else:
            self._do_close()

    def _try_open(self):
        """尝试打开串口"""
        config = self.get_config()
        ok, msg = config.validate()
        if not ok:
            _safe_message(self, "warning", "配置错误", msg)
            return

        if self._backend.open(config):
            self._is_open = True
            self.open_close_btn.setText("📥 关闭串口")
            self.open_close_btn.setStyleSheet(
                "QPushButton { background-color: #f44336; color: white; font-weight: bold; "
                "padding: 6px 16px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #da190b; }"
            )
            self.set_controls_enabled(False)
        else:
            _safe_message(self, "warning", "打开失败",
                                f"无法打开串口 {config.port}，请检查配置和连接。")

    def _do_close(self):
        """关闭串口"""
        if self._backend.close():
            self._is_open = False
            self.open_close_btn.setText("📤 打开串口")
            self.open_close_btn.setStyleSheet(
                "QPushButton { background-color: #4CAF50; color: white; font-weight: bold; "
                "padding: 6px 16px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #45a049; }"
            )
            self.set_controls_enabled(True)


# =====================================================================
# SendWidget — 发送控件组
# =====================================================================

class SendWidget(QGroupBox):
    """发送控件组：HEX模式、追加换行、发送按钮、文本输入区"""

    def __init__(self, parent=None):
        super().__init__("发送", parent)
        self._init_ui()
        self._connect_signals()

    def _init_ui(self):
        layout = QVBoxLayout()

        # 顶部工具栏
        toolbar = QHBoxLayout()
        self.hex_check = QCheckBox("HEX 模式")
        self.hex_check.setToolTip("以十六进制格式发送数据")
        toolbar.addWidget(self.hex_check)

        self.append_newline_check = QCheckBox("追加换行")
        self.append_newline_check.setToolTip("发送时自动追加换行符 \\n")
        self.append_newline_check.setChecked(True)
        toolbar.addWidget(self.append_newline_check)

        toolbar.addStretch()

        self.send_btn = QPushButton("📤 发送")
        self.send_btn.setEnabled(False)
        self.send_btn.setStyleSheet(
            "QPushButton { background-color: #2196F3; color: white; font-weight: bold; "
            "padding: 6px 20px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #0b7dda; }"
            "QPushButton:disabled { background-color: #cccccc; color: #666666; }"
        )
        toolbar.addWidget(self.send_btn)
        layout.addLayout(toolbar)

        # 发送输入区
        self.input_edit = QPlainTextEdit()
        self.input_edit.setPlaceholderText("输入要发送的数据...")
        self.input_edit.setMaximumHeight(100)
        self.input_edit.setStyleSheet(
            "QPlainTextEdit { font-family: 'Courier New', monospace; font-size: 12px; }"
        )
        layout.addWidget(self.input_edit)

        self.setLayout(layout)

    def _connect_signals(self):
        self.send_btn.clicked.connect(self._on_send_clicked)

    def set_send_enabled(self, enabled: bool):
        """启用/禁用发送功能"""
        self.send_btn.setEnabled(enabled)

    def get_text(self) -> str:
        """获取输入框文本"""
        return self.input_edit.toPlainText()

    def is_hex_mode(self) -> bool:
        """是否 HEX 模式"""
        return self.hex_check.isChecked()

    def is_append_newline(self) -> bool:
        """是否追加换行"""
        return self.append_newline_check.isChecked()

    def _on_send_clicked(self):
        """发送按钮点击回调（由父窗口绑定实际发送逻辑）"""
        # 此信号由 MainWindow 绑定
        pass


# =====================================================================
# ReceiveWidget — 接收显示控件组
# =====================================================================

class ReceiveWidget(QGroupBox):
    """接收显示控件组：时间戳、自动滚屏、清空、保存、显示区"""

    def __init__(self, parent=None):
        super().__init__("接收", parent)
        self._init_ui()
        self._connect_signals()

    def _init_ui(self):
        layout = QVBoxLayout()

        # 顶部工具栏
        toolbar = QHBoxLayout()
        self.timestamp_check = QCheckBox("时间戳")
        self.timestamp_check.setToolTip("在接收数据前显示时间戳")
        self.timestamp_check.setChecked(True)
        toolbar.addWidget(self.timestamp_check)

        self.auto_scroll_check = QCheckBox("自动滚屏")
        self.auto_scroll_check.setToolTip("自动滚动到最新数据")
        self.auto_scroll_check.setChecked(True)
        toolbar.addWidget(self.auto_scroll_check)

        toolbar.addStretch()

        self.clear_btn = QPushButton("🗑 清空")
        self.clear_btn.setToolTip("清空接收区")
        self.clear_btn.setStyleSheet(
            "QPushButton { background-color: #ff9800; color: white; "
            "padding: 4px 12px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #e68900; }"
        )
        toolbar.addWidget(self.clear_btn)

        self.save_btn = QPushButton("💾 保存日志")
        self.save_btn.setToolTip("将接收数据保存到文件")
        self.save_btn.setStyleSheet(
            "QPushButton { background-color: #607d8b; color: white; "
            "padding: 4px 12px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #506a7a; }"
        )
        toolbar.addWidget(self.save_btn)

        layout.addLayout(toolbar)

        # 接收数据显示区
        self.display = QPlainTextEdit()
        self.display.setReadOnly(True)
        self.display.setStyleSheet(
            "QPlainTextEdit { font-family: 'Courier New', monospace; font-size: 12px; "
            "background-color: #1e1e1e; color: #d4d4d4; }"
        )
        self.display.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        layout.addWidget(self.display)

        self.setLayout(layout)

    def _connect_signals(self):
        self.clear_btn.clicked.connect(self.clear_display)
        self.save_btn.clicked.connect(self._on_save_log)

    def append_frame(self, frame: SerialFrame):
        """向显示区追加一帧数据"""
        show_ts = self.timestamp_check.isChecked()
        line = frame.formatted(show_timestamp=show_ts)
        self.display.appendPlainText(line)

        # 自动滚屏
        if self.auto_scroll_check.isChecked():
            scrollbar = self.display.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

    def get_all_text(self) -> str:
        """获取显示区全部文本"""
        return self.display.toPlainText()

    def clear_display(self):
        """清空显示区"""
        self.display.clear()

    def _on_save_log(self):
        """保存日志到文件（触发文件对话框）"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存日志", "serial_log.txt",
            "文本文件 (*.txt);;所有文件 (*)"
        )
        if file_path:
            # 由 MainWindow 回调处理
            pass


# =====================================================================
# MainWindow — 主窗口
# =====================================================================

class MainWindow(QMainWindow):
    """串口调试助手主窗口"""

    def __init__(self, backend=None, parent=None):
        # 防御性检查：确保 QApplication 存在，防止无 App 时创建 QWidget 导致崩溃
        _ensure_qapplication()

        super().__init__(parent)
        self._frames: list[SerialFrame] = []

        # 创建后端
        if backend is None:
            self._backend = create_backend()
        else:
            self._backend = backend

        self._init_ui()
        self._connect_signals()
        self._init_timers()

    def _init_ui(self):
        """初始化界面"""
        self.setWindowTitle("串口调试助手")
        self.setMinimumSize(800, 600)

        # 中心部件
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(6)

        # 串口配置区域
        self.port_widget = PortWidget(self._backend)
        main_layout.addWidget(self.port_widget)

        # 分割器：发送区域 + 接收区域
        splitter = QSplitter(Qt.Vertical)

        # 发送区域
        self.send_widget = SendWidget()
        splitter.addWidget(self.send_widget)

        # 接收区域
        self.receive_widget = ReceiveWidget()
        splitter.addWidget(self.receive_widget)

        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)

        main_layout.addWidget(splitter, 1)

        # 状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪 - 请配置串口参数后打开")

    def _connect_signals(self):
        """连接信号"""
        # 发送按钮
        self.send_widget.send_btn.clicked.connect(self._on_send_clicked)
        # 保存日志
        self.receive_widget.save_btn.clicked.connect(self._on_save_log)

    def _init_timers(self):
        """初始化定时器"""
        # 接收轮询定时器
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._poll_receive)
        self._poll_timer.setInterval(50)  # 50ms 轮询

    # ---- 公开接口 ----

    def get_frames(self) -> list[SerialFrame]:
        """获取所有帧记录"""
        return list(self._frames)

    # ---- 私有方法 ----

    def _on_send_clicked(self):
        """发送按钮点击处理"""
        if not self._backend.is_open():
            _safe_message(self, "warning", "未打开串口", "请先打开串口再发送数据。")
            return

        text = self.send_widget.get_text()
        if not text:
            return

        hex_mode = self.send_widget.is_hex_mode()
        append_nl = self.send_widget.is_append_newline()

        if hex_mode:
            # HEX 模式：将 HEX 字符串转为 bytes
            data, err = hex_to_bytes(text)
            if err:
                _safe_message(self, "warning", "HEX 格式错误", err)
                return
        else:
            # 文本模式：直接编码
            data = text.encode("utf-8")

        # 追加换行
        if append_nl:
            data += b"\n"

        self._on_send_data(data)

    def _on_send_data(self, data: bytes):
        """实际发送数据（可被测试直接调用）"""
        if not data:
            return
        if not self._backend.send(data):
            _safe_message(self, "warning", "发送失败", "数据发送失败，请检查串口连接。")
            return

        # 记录发送帧
        frame = SerialFrame(
            data=data,
            timestamp=time.time(),
            direction="TX",
            hex_mode=self.send_widget.is_hex_mode(),
        )
        self._frames.append(frame)
        self.receive_widget.append_frame(frame)
        self.status_bar.showMessage(f"已发送 {len(data)} 字节")

    def _poll_receive(self):
        """轮询接收数据"""
        while True:
            data = self._backend.receive(timeout=0.01)
            if data is None:
                break
            frame = SerialFrame(
                data=data,
                timestamp=time.time(),
                direction="RX",
                hex_mode=False,
            )
            self._frames.append(frame)
            self.receive_widget.append_frame(frame)
            self.status_bar.showMessage(f"已接收 {len(data)} 字节")

    def _on_save_log(self):
        """保存日志"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存日志", "serial_log.txt",
            "文本文件 (*.txt);;所有文件 (*)"
        )
        if not file_path:
            return

        if not self._frames:
            _safe_message(self, "information", "无数据", "没有收发数据可保存。")
            return

        success = save_log(self._frames, file_path)
        if success:
            self.status_bar.showMessage(f"日志已保存到: {file_path}")
        else:
            _safe_message(self, "warning", "保存失败", f"无法保存日志到: {file_path}")

    def open_serial(self) -> bool:
        """编程方式打开串口（用于测试）"""
        config = self.port_widget.get_config()
        ok, msg = config.validate()
        if not ok:
            return False
        if self._backend.open(config):
            self.port_widget._is_open = True
            self.port_widget.open_close_btn.setText("📥 关闭串口")
            self.port_widget.set_controls_enabled(False)
            self.send_widget.set_send_enabled(True)
            self._poll_timer.start()
            self.status_bar.showMessage(f"串口 {config.port} 已打开")
            return True
        return False

    def close_serial(self) -> bool:
        """编程方式关闭串口（用于测试）"""
        if self._backend.close():
            self.port_widget._is_open = False
            self.port_widget.open_close_btn.setText("📤 打开串口")
            self.port_widget.set_controls_enabled(True)
            self.send_widget.set_send_enabled(False)
            self._poll_timer.stop()
            self.status_bar.showMessage("串口已关闭")
            return True
        return False

    def closeEvent(self, event):
        """窗口关闭事件"""
        if self._backend.is_open():
            self._backend.close()
        self._poll_timer.stop()
        super().closeEvent(event)


# =====================================================================
# 工厂函数
# =====================================================================

def create_test_app() -> MainWindow:
    """创建测试用主窗口实例（用于 GUI 冒烟测试）

    自动确保 QApplication 存在，防止测试框架遗漏导致 Qt 崩溃。
    环境要求:
        MOCK_SERIAL=1 环境变量
    
    Returns:
        MainWindow 实例
    """
    # 防御性：确保 QApplication 已创建（无 App 时创建 QWidget 会导致 SIGABRT）
    _ensure_qapplication()

    backend = create_backend()
    window = MainWindow(backend=backend)
    window.show()
    return window


# =====================================================================
# 入口
# =====================================================================

def main():
    """应用入口函数"""
    # 设置 Mock 模式（如无真实串口）
    if "MOCK_SERIAL" not in os.environ:
        os.environ.setdefault("MOCK_SERIAL", "1")

    app = QApplication(sys.argv)
    app.setApplicationName("串口调试助手")

    window = create_test_app()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
