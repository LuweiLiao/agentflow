"""
test_gui_smoke.py — PyQt GUI 冒烟测试

覆盖:
  - 模块导入测试
  - 主窗口创建
  - 控件存在性验证
  - Mock 模式发送/接收流程

运行方式:
  QT_QPA_PLATFORM=offscreen python -m pytest tests/test_gui_smoke.py -v

注意事项:
  - 需要 PyQt5 和 QT_QPA_PLATFORM=offscreen 环境
  - 无 PyQt5 时自动跳过 GUI 测试
"""

from __future__ import annotations

import os
import sys
import time

# 确保能找到 serial_core
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ---- PyQt5 可用性检测 ----
try:
    from PyQt5.QtWidgets import QApplication, QComboBox, QPushButton, \
        QCheckBox, QPlainTextEdit, QGroupBox, QMainWindow
    from PyQt5.QtCore import Qt
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False

# 导入被测模块
try:
    from app import MainWindow, create_test_app, PortWidget, SendWidget, ReceiveWidget
    from serial_core import (
        SerialPortConfig, SerialFrame, MockSerialBackend,
        hex_to_bytes, bytes_to_hex,
    )
    APP_AVAILABLE = True
except ImportError as e:
    APP_AVAILABLE = False
    IMPORT_ERROR = str(e)


# =====================================================================
# 测试用例
# =====================================================================

def test_module_import():
    """P0: 模块导入测试"""
    assert APP_AVAILABLE, f"app.py 导入失败: {IMPORT_ERROR}"


def test_serial_core_import():
    """P0: 核心模块导入测试"""
    from serial_core import (
        SerialPortConfig, SerialFrame, MockSerialBackend,
        create_backend, hex_to_bytes, bytes_to_hex,
        is_valid_hex, format_frame, save_log,
    )
    assert SerialPortConfig is not None
    assert SerialFrame is not None
    assert MockSerialBackend is not None


def test_create_test_app():
    """P0: 创建测试应用实例"""
    if not PYQT5_AVAILABLE:
        return  # 跳过

    # 设置 Mock 模式
    os.environ["MOCK_SERIAL"] = "1"

    app = QApplication.instance() or QApplication(sys.argv)
    window = create_test_app()
    assert window is not None
    assert isinstance(window, QMainWindow)
    assert isinstance(window, MainWindow)

    # 验证控件存在
    assert hasattr(window, 'port_widget')
    assert hasattr(window, 'send_widget')
    assert hasattr(window, 'receive_widget')

    window.close()


def test_port_widget_exists():
    """P0: PortWidget 控件验证"""
    if not PYQT5_AVAILABLE:
        return

    os.environ["MOCK_SERIAL"] = "1"
    app = QApplication.instance() or QApplication(sys.argv)
    from serial_core import MockSerialBackend
    backend = MockSerialBackend()
    widget = PortWidget(backend)
    assert widget is not None
    assert isinstance(widget, QGroupBox)

    # 验证子控件
    assert hasattr(widget, 'port_combo')
    assert hasattr(widget, 'baudrate_combo')
    assert hasattr(widget, 'data_bits_combo')
    assert hasattr(widget, 'stop_bits_combo')
    assert hasattr(widget, 'parity_combo')
    assert hasattr(widget, 'open_close_btn')
    assert hasattr(widget, 'refresh_btn')

    # 验证类型
    assert isinstance(widget.port_combo, QComboBox)
    assert isinstance(widget.baudrate_combo, QComboBox)
    assert isinstance(widget.open_close_btn, QPushButton)

    widget.deleteLater()


def test_port_widget_config():
    """P0: PortWidget 配置读取"""
    if not PYQT5_AVAILABLE:
        return

    os.environ["MOCK_SERIAL"] = "1"
    app = QApplication.instance() or QApplication(sys.argv)
    from serial_core import MockSerialBackend
    backend = MockSerialBackend()
    widget = PortWidget(backend)

    # 设置端口
    widget.port_combo.setEditText("COM_TEST")
    config = widget.get_config()
    assert config.port == "COM_TEST"
    assert config.baudrate == 9600
    assert config.data_bits == 8
    assert config.stop_bits == 1.0
    assert config.parity == "N"

    widget.deleteLater()


def test_port_widget_open_close():
    """P0: PortWidget 打开/关闭串口"""
    if not PYQT5_AVAILABLE:
        return

    os.environ["MOCK_SERIAL"] = "1"
    app = QApplication.instance() or QApplication(sys.argv)
    from serial_core import MockSerialBackend
    backend = MockSerialBackend()
    widget = PortWidget(backend)

    # 设置有效端口并打开
    widget.port_combo.setEditText("COM_MOCK")
    assert widget.is_open() is False

    # 点击打开
    widget._on_open_close_clicked()
    assert widget.is_open() is True
    assert backend.is_open() is True

    # 点击关闭
    widget._on_open_close_clicked()
    assert widget.is_open() is False
    assert backend.is_open() is False

    widget.deleteLater()


def test_send_widget_exists():
    """P0: SendWidget 控件验证"""
    if not PYQT5_AVAILABLE:
        return

    app = QApplication.instance() or QApplication(sys.argv)
    widget = SendWidget()
    assert widget is not None
    assert isinstance(widget, QGroupBox)

    # 验证子控件
    assert hasattr(widget, 'hex_check')
    assert hasattr(widget, 'append_newline_check')
    assert hasattr(widget, 'send_btn')
    assert hasattr(widget, 'input_edit')

    assert isinstance(widget.hex_check, QCheckBox)
    assert isinstance(widget.send_btn, QPushButton)
    assert isinstance(widget.input_edit, QPlainTextEdit)

    widget.deleteLater()


def test_receive_widget_exists():
    """P0: ReceiveWidget 控件验证"""
    if not PYQT5_AVAILABLE:
        return

    app = QApplication.instance() or QApplication(sys.argv)
    widget = ReceiveWidget()
    assert widget is not None
    assert isinstance(widget, QGroupBox)

    # 验证子控件
    assert hasattr(widget, 'timestamp_check')
    assert hasattr(widget, 'auto_scroll_check')
    assert hasattr(widget, 'clear_btn')
    assert hasattr(widget, 'save_btn')
    assert hasattr(widget, 'display')

    assert isinstance(widget.timestamp_check, QCheckBox)
    assert isinstance(widget.clear_btn, QPushButton)
    assert isinstance(widget.display, QPlainTextEdit)

    widget.deleteLater()


def test_receive_widget_append_frame():
    """P0: ReceiveWidget 显示帧"""
    if not PYQT5_AVAILABLE:
        return

    app = QApplication.instance() or QApplication(sys.argv)
    widget = ReceiveWidget()

    # 创建测试帧
    ts = 3600.0  # 01:00:00
    frame = SerialFrame(data=b"Hello World", timestamp=ts, direction="RX")
    widget.append_frame(frame)

    text = widget.get_all_text()
    assert "Hello World" in text
    assert "RX:" in text

    # HEX 模式帧
    frame_hex = SerialFrame(data=b"\x0a\x1b", timestamp=ts, direction="TX", hex_mode=True)
    widget.append_frame(frame_hex)
    text2 = widget.get_all_text()
    assert "0A 1B" in text2

    widget.deleteLater()


def test_receive_widget_clear():
    """P0: ReceiveWidget 清空功能"""
    if not PYQT5_AVAILABLE:
        return

    app = QApplication.instance() or QApplication(sys.argv)
    widget = ReceiveWidget()

    frame = SerialFrame(data=b"test", timestamp=0.0, direction="RX")
    widget.append_frame(frame)
    assert "test" in widget.get_all_text()

    widget.clear_display()
    assert widget.get_all_text() == ""

    widget.deleteLater()


def test_main_window_mock_send_receive():
    """P0: 主窗口 Mock 发送/接收流程"""
    if not PYQT5_AVAILABLE:
        return

    os.environ["MOCK_SERIAL"] = "1"
    app = QApplication.instance() or QApplication(sys.argv)
    from serial_core import MockSerialBackend
    backend = MockSerialBackend()
    window = MainWindow(backend=backend)

    # 打开串口
    window.port_widget._on_open_close_clicked()
    assert window._backend.is_open() is True

    # 模拟发送
    window._on_send_data(b"Hello")
    assert len(window._frames) == 1
    assert window._frames[0].direction == "TX"
    assert window._frames[0].data == b"Hello"

    # 模拟接收（通过 Mock 注入）
    backend.inject_rx(b"World")
    window._poll_receive()
    assert len(window._frames) == 2
    assert window._frames[1].direction == "RX"
    assert window._frames[1].data == b"World"

    # 验证接收区显示
    text = window.receive_widget.get_all_text()
    assert "Hello" in text
    assert "World" in text

    window.close()


def test_main_window_save_log():
    """P0: 主窗口日志保存"""
    if not PYQT5_AVAILABLE:
        return

    import tempfile

    os.environ["MOCK_SERIAL"] = "1"
    app = QApplication.instance() or QApplication(sys.argv)
    from serial_core import MockSerialBackend
    backend = MockSerialBackend()
    window = MainWindow(backend=backend)

    # 打开串口并模拟收发
    window.port_widget._on_open_close_clicked()
    window._on_send_data(b"LOG_TEST_DATA")

    # 获取 frames 并使用 save_log
    frames = window.get_frames()
    assert len(frames) >= 1

    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        log_path = f.name

    from serial_core import save_log
    result = save_log(frames, log_path)
    assert result is True

    # 验证文件内容
    with open(log_path, 'r', encoding='utf-8') as f:
        content = f.read()
    assert "LOG_TEST_DATA" in content
    assert "TX:" in content

    os.unlink(log_path)
    window.close()


def test_main_window_window_title():
    """P1: 主窗口标题"""
    if not PYQT5_AVAILABLE:
        return

    os.environ["MOCK_SERIAL"] = "1"
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    assert "串口调试助手" in window.windowTitle()
    window.close()


def test_send_widget_text_mode():
    """P1: SendWidget 文本模式发送"""
    if not PYQT5_AVAILABLE:
        return

    app = QApplication.instance() or QApplication(sys.argv)
    widget = SendWidget()

    # 文本模式
    widget.hex_check.setChecked(False)
    widget.input_edit.setPlainText("测试文本")
    text = widget.get_text()
    assert text == "测试文本"

    widget.deleteLater()
