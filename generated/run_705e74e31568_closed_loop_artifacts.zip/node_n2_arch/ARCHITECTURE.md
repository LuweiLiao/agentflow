# PyQt 串口调试助手 — 架构设计说明书 (ARCHITECTURE)

> 版本: 1.0  
> 基于 SPEC.md / PRD.md / checklist.md / test_matrix.md / file_manifest.md 综合设计

---

## 目录

1. [总体架构](#1-总体架构)
2. [三层边界定义](#2-三层边界定义)
3. [模块详细设计](#3-模块详细设计)
4. [接口契约](#4-接口契约)
5. [数据流与状态管理](#5-数据流与状态管理)
6. [闭环反馈集成](#6-闭环反馈集成)
7. [技术选型理由](#7-技术选型理由)
8. [构建顺序与依赖关系](#8-构建顺序与依赖关系)
9. [目录结构快照](#9-目录结构快照)

---

## 1. 总体架构

本系统采用 **严格三层分离** 架构：

```
┌──────────────────────────────────────────────────────────────┐
│                        🖥️ GUI 层 (gui/)                      │
│  main_window.py, port_widget.py, send_widget.py               │
│  receive_widget.py, utils.py, main.py                        │
│  职责: 用户交互、控件编排、事件响应                            │
│  依赖: PyQt5 (运行时), core/* (逻辑调用)                      │
├──────────────────────────────────────────────────────────────┤
│                        ⚙️ 核心逻辑层 (core/)                  │
│  config.py, codec.py, frame.py, backend.py, logger.py        │
│  职责: 串口参数、编解码、帧模型、后端抽象、日志格式化           │
│  依赖: Python 标准库 (可脱离 PyQt5 运行)                      │
├──────────────────────────────────────────────────────────────┤
│                        🧪 测试层 (tests/)                    │
│  test_config.py, test_codec.py, test_frame.py                 │
│  test_backend.py, test_logger.py, test_gui_smoke.py          │
│  职责: 单元测试 + 冒烟测试 + 覆盖率验证                       │
│  依赖: pytest, pytest-cov; gui smoke 需 PyQt5(offscreen)     │
└──────────────────────────────────────────────────────────────┘
```

### 1.1 设计原则

| 原则 | 说明 |
|------|------|
| **依赖单向** | GUI → core → 标准库，杜绝 core 反向依赖 gui |
| **接口契约化** | 跨层调用通过定义在 core 中的抽象接口进行 |
| **Mock 优先** | MockSerialBackend 支持无硬件自测 |
| **可测试性** | core 层全部可脱离 GUI 运行测试 |
| **闭环反馈** | Agent 编排中测试失败 → 证据反馈 → 修复重测 |

---

## 2. 三层边界定义

### 2.1 核心逻辑层 (core/)

**包含模块：** config.py, codec.py, frame.py, backend.py, logger.py

**允许的 import：** 仅 Python 标准库 (`dataclasses`, `time`, `os`, `typing`, `struct` 等)

**禁止的 import：** `PyQt5`, `pyserial`（backend.py 中的 SerialBackend 使用 pyserial，但 MockSerialBackend 不用；实际 import 加 try/except 保护）

**可测试性要求：** 在无 PyQt5、无 pyserial、无真实串口的环境下，`pytest tests/test_config.py tests/test_codec.py tests/test_frame.py tests/test_backend.py tests/test_logger.py` 必须全部通过。

### 2.2 GUI 层 (gui/)

**包含模块：** main_window.py, port_widget.py, send_widget.py, receive_widget.py, utils.py, main.py

**允许的 import：** `PyQt5`, `core/*`, 标准库

**关键约束：** 所有对 core 的调用必须通过 core 层接口进行，不允许绕过接口直接操作内部实现细节。

**Mock 集成：** 通过 `os.environ.get("MOCK_SERIAL") == "1"` 在 main.py 中决定使用 MockSerialBackend 还是真实 SerialBackend。

**无 PyQt5 降级：** gui 模块 import 失败时，测试层应能优雅跳过 GUI 冒烟测试。

### 2.3 测试层 (tests/)

**包含文件：** test_config.py, test_codec.py, test_frame.py, test_backend.py, test_logger.py, test_gui_smoke.py

**覆盖范围：**
- `tests/test_config.py` → `core.config` (P0:7, P1:3, 合计:10)
- `tests/test_codec.py` → `core.codec` (P0:8, P1:4, 合计:12)
- `tests/test_frame.py` → `core.frame` (P0:6, P1:2, 合计:8)
- `tests/test_backend.py` → `core.backend` (P0:8, P1:2, 合计:10)
- `tests/test_logger.py` → `core.logger` (P0:4, P1:2, 合计:6)
- `tests/test_gui_smoke.py` → `gui.*` (P0:4, P1:0, 合计:4)

**合计：50 用例（P0:37, P1:13）**

**覆盖率目标：**

| 模块 | 行覆盖率 | 分支覆盖率 |
|------|---------|-----------|
| core/config.py | 100% | 100% |
| core/codec.py | 100% | 100% |
| core/frame.py | 95%+ | 90%+ |
| core/backend.py | 95%+ | 90%+ |
| core/logger.py | 95%+ | 90%+ |
| gui/*.py | 60%+ (smoke) | — |
| **总体** | **90%+** | **85%+** |

---

## 3. 模块详细设计

### 3.1 core/config.py — SerialPortConfig

```python
@dataclass(frozen=True)
class SerialPortConfig:
    port: str = ""           # 串口名称，如 "COM1" 或 "/dev/ttyUSB0"
    baudrate: int = 9600     # 波特率
    data_bits: int = 8       # 数据位: 5,6,7,8
    stop_bits: float = 1.0   # 停止位: 1.0, 1.5, 2.0
    parity: str = "N"        # 校验位: N,E,O,S,M

    VALID_BAUDRATES = {9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600}
    VALID_DATA_BITS = {5, 6, 7, 8}
    VALID_STOP_BITS = {1.0, 1.5, 2.0}
    VALID_PARITIES = {"N", "E", "O", "S", "M"}

    def validate(self) -> tuple[bool, str]:
        """校验配置合法性，返回 (是否合法, 错误信息)"""
        ...
```

**设计理由：**
- frozen=True 保证不可变性，避免配置在运行时被意外修改
- validate() 返回 (bool, str) 而非抛出异常，便于 GUI 层获取友好错误消息
- 验证常量定义为类属性，便于测试和扩展

### 3.2 core/codec.py — HEX 编解码

```python
def hex_to_bytes(s: str) -> tuple[bytes, str]:
    """HEX字符串 → (bytes数据, 错误信息)
    - 忽略空白字符和0x前缀
    - 非法字符 → (b"", "包含非法字符")
    - 奇数长度 → (b"", "HEX 字符串长度不能为奇数")
    - 正常返回 (bytes, "")
    """

def bytes_to_hex(data: bytes) -> str:
    """bytes → 大写空格分隔 HEX 字符串
    如 b'\\x0a\\x1b' → "0A 1B"
    """

def is_valid_hex(s: str) -> bool:
    """判断字符串是否为合法 HEX 输入"""
```

**设计理由：**
- hex_to_bytes 返回双值元组而非抛出异常，方便 GUI 层在用户输入错误时精确提示
- 自动忽略 0x 前缀和空白，提升用户体验（用户可粘贴"0x0A 0x1B"或"0A1B"等格式）
- bytes_to_hex 固定大写+空格分隔，保证显示一致性
- is_valid_hex 作为快速预检，用于输入框实时校验

### 3.3 core/frame.py — SerialFrame

```python
@dataclass(frozen=True)
class SerialFrame:
    data: bytes            # 原始数据
    timestamp: float       # Unix 时间戳（time.time()）
    direction: str         # "TX" 或 "RX"
    hex_mode: bool = False # 是否以 HEX 格式显示

    def __post_init__(self):
        if self.direction not in ("TX", "RX"):
            raise ValueError(f"direction 必须为 'TX' 或 'RX'，收到: {self.direction}")

    def formatted(self) -> str:
        """格式化输出:
        文本模式: "[12:34:56.789] TX: Hello"
        HEX 模式: "[12:34:56.789] RX: 0A 1B 2C"
        """

    def hex_str(self) -> str:
        """返回空格分隔的大写 HEX 字符串"""

    def text_str(self) -> str:
        """解码为文本（忽略无法解码的字节）"""
```

**设计理由：**
- frozen=True 保证帧的不可变性，作为数据传递对象安全可靠
- direction 限定 TX/RX，确保方向语义清晰
- formatted() 聚合时间戳、方向、数据三要素，供 GUI 和日志统一使用
- hex_str/text_str 分离，让消费者按需选择显示格式

### 3.4 core/backend.py — 串口后端抽象

```python
from abc import ABC, abstractmethod
from typing import Optional

class SerialBackend(ABC):
    """串口后端抽象基类"""

    @abstractmethod
    def open(self, config: "SerialPortConfig") -> bool:
        """打开串口，成功返回 True"""

    @abstractmethod
    def close(self) -> bool:
        """关闭串口"""

    @abstractmethod
    def send(self, data: bytes) -> bool:
        """发送数据"""

    @abstractmethod
    def receive(self, timeout: float = 0.1) -> Optional[bytes]:
        """接收数据，超时返回 None"""

    @abstractmethod
    def is_open(self) -> bool:
        """是否已打开"""


class MockSerialBackend(SerialBackend):
    """Mock 串口后端，用于无硬件自测"""

    def __init__(self):
        self._is_open = False
        self._config = None
        self.sent_log: list[bytes] = []      # 记录所有发送的数据
        self.rx_queue: list[bytes] = []      # 接收队列 (FIFO)
        self._closed = False

    def open(self, config: "SerialPortConfig") -> bool:
        ok, _ = config.validate()
        if not ok:
            return False
        if self._is_open:
            return False  # 重复打开
        self._config = config
        self._is_open = True
        return True

    def close(self) -> bool:
        self._is_open = False
        self._config = None
        self._closed = True
        return True

    def send(self, data: bytes) -> bool:
        if not self._is_open:
            return False
        self.sent_log.append(data)
        return True

    def receive(self, timeout: float = 0.1) -> Optional[bytes]:
        if not self._is_open or not self.rx_queue:
            return None
        return self.rx_queue.pop(0)

    def is_open(self) -> bool:
        return self._is_open

    def inject_rx(self, data: bytes) -> None:
        """测试用：向接收队列注入数据"""
        self.rx_queue.append(data)

    def reset(self) -> None:
        """清空所有缓存"""
        self.sent_log.clear()
        self.rx_queue.clear()
        self._is_open = False
        self._config = None
        self._closed = False


def create_backend() -> SerialBackend:
    """工厂方法：根据 MOCK_SERIAL 环境变量创建对应的后端"""
    import os
    if os.environ.get("MOCK_SERIAL") == "1":
        return MockSerialBackend()
    # 真实 SerialBackend 使用 pyserial
    from ._real_backend import RealSerialBackend
    return RealSerialBackend()
```

**设计理由：**
- 抽象基类定义契约，MockSerialBackend 和 RealSerialBackend 遵循同一接口
- 工厂方法 create_backend() 封装创建逻辑，环境变量驱动 Mock 切换
- MockSerialBackend 的 sent_log/rx_queue 是公开列表，便于测试断言
- inject_rx() 是 Mock 特有的测试接口，不在抽象基类中声明

### 3.5 core/logger.py — 日志模块

```python
def format_frame(frame: "SerialFrame") -> str:
    """将 SerialFrame 格式化为日志行
    格式: [HH:MM:SS.mmm] TX/RX: 数据
    """

def save_log(frames: list["SerialFrame"], path: str) -> bool:
    """将帧列表写入日志文件
    返回 True 表示成功，False 表示失败（如权限不足）
    """
```

**设计理由：**
- format_frame 与 frame.formatted() 逻辑一致但独立，便于日志格式定制
- save_log 接收帧列表而非单个帧，支持批量/整体保存
- 返回 bool 而非抛出异常，GUI 层可直接判断是否需要弹错误提示

### 3.6 GUI 控件分解

#### 3.6.1 port_widget.py — 串口配置控件组

```
┌─────────────────────────────────────────────┐
│  端口: [▼ COM1   ]  波特率: [▼ 9600     ]   │
│  数据位: [▼ 8]  停止位: [▼ 1.0]  校验位: [▼ N]│
│  [◉ 打开串口]  [🔄 刷新端口]                  │
└─────────────────────────────────────────────┘
```

**接口：**
- `PortWidget(backend, parent=None)` — 构造，绑定后端
- `get_config() -> SerialPortConfig` — 获取当前配置
- `set_controls_enabled(enabled: bool)` — 启用/禁用配置控件
- `refresh_ports()` — 刷新端口列表
- `open_close_clicked()` — 打开/关闭切换
- `signal: config_changed(SerialPortConfig)` — 配置变更信号

#### 3.6.2 send_widget.py — 发送控件组

```
┌─────────────────────────────────────────────┐
│  [☐ HEX模式] [☐ 追加换行]     [📤 发送]      │
│  ┌───────────────────────────────────────┐   │
│  │ 发送输入框 (QPlainTextEdit)            │   │
│  └───────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
```

**接口：**
- `SendWidget(codec, parent=None)` — 构造，绑定编解码器
- `get_text() -> str` — 获取输入文本
- `send_clicked()` — 发送按钮点击处理
- `signal: send_requested(data: bytes)` — 发送数据信号

#### 3.6.3 receive_widget.py — 接收控件组

```
┌─────────────────────────────────────────────┐
│  [☐ 时间戳] [☐ 自动滚屏] [🧹 清空] [💾 保存日志]│
│  ┌───────────────────────────────────────┐   │
│  │ 接收显示区 (QPlainTextEdit, 只读)      │   │
│  │ [12:34:56] RX: Hello                  │   │
│  │ [12:34:57] TX: 0A 1B 2C              │   │
│  └───────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
```

**接口：**
- `ReceiveWidget(logger, parent=None)` — 构造
- `append_frame(frame: SerialFrame)` — 追加帧到显示区
- `clear()` — 清空接收区
- `get_all_frames() -> list[SerialFrame]` — 获取所有帧（用于保存日志）
- `signal: save_log_requested()` — 保存日志请求信号

#### 3.6.4 main_window.py — 主窗口

**职责：**
1. 组装 PortWidget, SendWidget, ReceiveWidget
2. 管理接收定时器 QTimer
3. 处理工具栏/状态栏
4. 协调打开/关闭/发送/接收/保存等业务流程

**核心流程：**

```python
class MainWindow(QMainWindow):
    def __init__(self, backend=None):
        # 若未传入 backend，通过 create_backend() 自动创建
        ...
        self._setup_timer()       # 接收定时器
        self._connect_signals()   # 信号连接

    def _on_open_close(self):
        if self._backend.is_open():
            self._close_serial()
        else:
            self._open_serial()

    def _open_serial(self):
        config = self._port_widget.get_config()
        ok, err = config.validate()
        if not ok:
            QMessageBox.warning(self, "配置错误", err)
            return
        if self._backend.open(config):
            self._port_widget.set_controls_enabled(False)
            self._open_close_btn.setText("关闭串口")
            self._timer.start(100)  # 100ms 轮询接收
            self._update_status("已打开")
        else:
            QMessageBox.warning(self, "错误", "打开串口失败")

    def _on_receive_timer(self):
        data = self._backend.receive(timeout=0.01)
        if data is not None:
            frame = SerialFrame(data, time.time(), "RX",
                                hex_mode=self._hex_send_cb.isChecked())
            self._receive_widget.append_frame(frame)
```

#### 3.6.5 utils.py — GUI 辅助函数

```python
def scan_ports() -> list[str]:
    """扫描系统可用串口列表"""

def format_timestamp(ts: float, show_msec: bool = True) -> str:
    """格式化时间戳为 [HH:MM:SS.mmm]"""
```

### 3.7 main.py — 入口

```python
import sys
import os
from PyQt5.QtWidgets import QApplication
from src.core.backend import create_backend
from src.gui.main_window import MainWindow

def main():
    app = QApplication(sys.argv)
    backend = create_backend()
    window = MainWindow(backend=backend)
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
```

**MOCK 模式检测：** `create_backend()` 内部通过 `os.environ.get("MOCK_SERIAL")` 决定使用 MockSerialBackend 或 RealSerialBackend。GUI 标题栏自动追加 `(MOCK)` 标识。

---

## 4. 接口契约

### 4.1 跨层调用契约

| 调用方 | 被调用方 | 接口 | 参数 | 返回值 |
|--------|---------|------|------|--------|
| gui/* | core.config | `SerialPortConfig(port, baudrate, ...)` | 配置参数 | 对象 |
| gui/* | core.config | `.validate()` | 无 | `(bool, str)` |
| gui/send_widget | core.codec | `hex_to_bytes(s)` | str | `(bytes, str)` |
| gui/send_widget | core.codec | `is_valid_hex(s)` | str | bool |
| gui/receive_widget | core.frame | `SerialFrame(data, ts, dir, hex)` | bytes, float, str, bool | 对象 |
| gui/receive_widget | core.frame | `.formatted()` | 无 | str |
| gui/main_window | core.backend | `.open(config)` | SerialPortConfig | bool |
| gui/main_window | core.backend | `.send(data)` | bytes | bool |
| gui/main_window | core.backend | `.receive(timeout)` | float | Optional[bytes] |
| gui/main_window | core.backend | `.close()` | 无 | bool |
| gui/main_window | core.backend | `.is_open()` | 无 | bool |
| gui/main_window | core.logger | `save_log(frames, path)` | list, str | bool |

### 4.2 信号/槽契约（GUI 内部）

| 信号 | 发送者 | 接收者 | 参数 |
|------|--------|--------|------|
| `send_requested` | SendWidget | MainWindow | `data: bytes` |
| `save_log_requested` | ReceiveWidget | MainWindow | 无 |
| `config_changed` | PortWidget | MainWindow | `SerialPortConfig` |

---

## 5. 数据流与状态管理

### 5.1 发送数据流

```
用户输入文本
     │
     ▼
SendWidget 检测 HEX 模式
     │
     ├── 文本模式: text.encode("utf-8") → bytes
     │
     └── HEX 模式: codec.hex_to_bytes(text)
                        │
                    ┌────┴────┐
                    │ 失败     │ 成功
                    ▼         ▼
                QMessageBox  继续
                    │
                    ▼
            emit send_requested(bytes)
                    │
                    ▼
            MainWindow._on_send(data)
                    │
                    ▼
            backend.send(data)
                    │
                    ▼
            构造 TX SerialFrame
                    │
                    ▼
            receive_widget.append_frame(frame)
```

### 5.2 接收数据流

```
QTimer 每 100ms 触发
     │
     ▼
MainWindow._on_receive_timer()
     │
     ▼
backend.receive(timeout=0.01)
     │
     ├── None → 跳过
     │
     └── bytes
          │
          ▼
     构造 RX SerialFrame(data, time.time(), "RX", hex_mode)
          │
          ▼
     receive_widget.append_frame(frame)
          │
          ▼
     格式化显示（时间戳+方向+数据）
          │
          ▼
     自动滚屏（如果开启）
```

### 5.3 状态管理

系统维护以下状态机：

```
串口状态: CLOSED → OPENING → OPEN → CLOSING → CLOSED
         │
         └── 失败 → CLOSED（显示错误信息）

UI 状态:
  CLOSED: 配置控件启用, 按钮文字"打开串口"
  OPEN:   配置控件禁用, 按钮文字"关闭串口", 定时器运行
```

所有状态通过 MainWindow 集中管理，PortWidget/SendWidget/ReceiveWidget 只负责各自区域的显示逻辑。

---

## 6. 闭环反馈集成

### 6.1 Agent 编排流程

```
┌──────────┐    SPEC.md,PRD     ┌──────────┐
│ n1_spec   │ ───────────────→ │ n2_arch   │
│ (规格细化) │                  │ (架构设计) │ ← 当前节点
└──────────┘                   └─────┬────┘
                                     │ ARCHITECTURE.md
                                     ▼
                              ┌──────────┐
                              │ n3_dev    │
                              │ (开发实现) │
                              └─────┬────┘
                                    │ src/*, tests/*
                                    ▼
                              ┌──────────┐
                    ┌────────│ n4_test   │
                    │        │ (测试验证) │
                    │        └─────┬────┘
                    │              │ PASS / FAIL
                    │              ▼
                    │        ┌──────────┐
                    │        │ n5_review │
                    │        │ (审查)     │
                    │        └─────┬────┘
                    │              │ PASS
                    │              ▼
                    │         ✅ 完成
                    │
                    └── FAIL ──→ feedback_history + n3_dev (返修)
```

### 6.2 反馈数据格式

测试节点失败时产生：

```json
{
  "feedback": [
    {
      "file": "tests/test_codec.py",
      "test": "test_hex_to_bytes_invalid_char",
      "line": 42,
      "assertion": "assert result == (b'', '包含非法字符')",
      "actual": "(b'', '包含非法字符xx')",
      "error_type": "AssertionError",
      "message": "Test test_hex_to_bytes_invalid_char FAILED: expected (b'', '包含非法字符'), got ..."
    }
  ],
  "summary": "2/50 tests failed",
  "passed": 48,
  "failed": 2,
  "total": 50
}
```

### 6.3 开发节点返修策略

开发节点（n3_dev）接收 `feedback_history` 参数（列表形式），按以下步骤修复：

1. 解析 feedback 中的 `file` 和 `line` 定位问题
2. 根据 `assertion` 和 `actual` 理解差异
3. 修复对应源文件
4. 输出修复摘要

### 6.4 质量门控

| 门控点 | 检查项 | 通过条件 |
|--------|--------|----------|
| n1→n2 | SPEC.md 存在 | 包含"闭环"和"HEX"关键词 |
| n2→n3 | ARCHITECTURE.md 存在 | 包含三层边界和接口定义 |
| n3→n4 | src/* 和 tests/* 存在 | 所有模块有对应测试 |
| n4→n5 | pytest 全部通过 | 50/50 通过, 覆盖率达标 |
| n5→END | 审查通过 | 无遗留问题 |

---

## 7. 技术选型理由

### 7.1 PyQt5 (>= 5.15)

| 选型项 | 选择 | 理由 |
|--------|------|------|
| GUI 框架 | PyQt5 | 成熟的 Python Qt 绑定，功能完整，文档丰富 |
| 替代方案 | tkinter | 原生控件简陋，缺乏现代化组件 |
| 替代方案 | PySide2/6 | 与 PyQt5 API 90% 兼容但许可不同（LGPL），本项目选 GPL 可接受的 PyQt5 |
| 替代方案 | wxPython | 控件丰富但社区较小，学习成本高 |
| 版本选择 | 5.15 LTS | 稳定且广泛支持的版本 |

### 7.2 pytest (>= 7.4)

| 选型项 | 选择 | 理由 |
|--------|------|------|
| 测试框架 | pytest | 简洁的 assert、fixture 系统、插件生态丰富 |
| 替代方案 | unittest | 模板代码多，fixture 支持弱 |
| 覆盖率 | pytest-cov | 与 pytest 原生集成，报告格式丰富 |
| Qt 测试 | pytest-qt | 提供 qtbot fixture（可选依赖） |

### 7.3 核心架构模式

| 模式 | 应用 | 理由 |
|------|------|------|
| 策略模式 | SerialBackend / MockSerialBackend | 运行时切换真实/Mock 后端 |
| 工厂模式 | create_backend() | 封装对象创建逻辑 |
| 观察者模式 | Qt Signal/Slot | GUI 控件间松耦合通信 |
| 不可变对象 | SerialPortConfig, SerialFrame | 避免数据被意外修改 |
| MVC 变体 | core(模型) + gui(视图+控制器) | 核心逻辑与 GUI 彻底分离 |

### 7.4 测试策略

| 层 | 测试方式 | 环境要求 |
|----|----------|----------|
| core 单元测试 | pytest 直接运行 | 仅需 Python 标准库 |
| GUI smoke 测试 | pytest + QT_QPA_PLATFORM=offscreen | 需 PyQt5 但不需显示器 |
| 手动测试 | `MOCK_SERIAL=1 python src/main.py` | 需 PyQt5 但不需硬件 |
| 覆盖率 | `pytest --cov=src/core --cov-report=term-missing` | 同 pytest |

---

## 8. 构建顺序与依赖关系

### 8.1 推荐构建顺序（依赖驱动）

```
Step 1: core/config.py          ← 无依赖
Step 2: core/codec.py           ← 无依赖
Step 3: core/frame.py           ← 无依赖
Step 4: core/backend.py         ← 依赖 config.py
Step 5: core/logger.py          ← 依赖 frame.py
Step 6: tests/test_config.py    ← 依赖 config.py
Step 7: tests/test_codec.py     ← 依赖 codec.py
Step 8: tests/test_frame.py     ← 依赖 frame.py
Step 9: tests/test_backend.py   ← 依赖 backend.py
Step 10: tests/test_logger.py   ← 依赖 logger.py
────────────────────────────────────────
Step 11: gui/utils.py           ← 依赖 core.codec, pyserial
Step 12: gui/port_widget.py     ← 依赖 core.config, core.backend, gui.utils
Step 13: gui/send_widget.py     ← 依赖 core.codec
Step 14: gui/receive_widget.py  ← 依赖 core.frame, core.logger
Step 15: gui/main_window.py     ← 依赖 gui/port, send, receive
Step 16: gui/main.py            ← 依赖 gui/main_window, core.backend
Step 17: tests/test_gui_smoke.py ← 依赖 gui.*
────────────────────────────────────────
Step 18: 全量测试与闭环验证
```

### 8.2 依赖关系图

```
config.py ──→ backend.py ──→ gui/port_widget.py ──┐
                    │                              │
                    └──→ gui/main_window.py ───────┤
                                                  │
codec.py ──→ gui/send_widget.py ──────────────────┤
           → gui/utils.py                        │
                                                  │
frame.py ──→ logger.py ──→ gui/receive_widget.py ─┤
                                                  │
                                     gui/main.py ─┘
```

---

## 9. 目录结构快照

```
serial-debug-tool/
├── SPEC.md                          # 规格说明书（质量门控入口）
├── ARCHITECTURE.md                  # 本文件 — 架构设计方案
├── requirements.txt                 # 项目依赖
│
├── src/                             # 源代码
│   ├── __init__.py
│   │
│   ├── core/                        # ⚙️ 核心逻辑层
│   │   ├── __init__.py
│   │   ├── config.py                # SerialPortConfig — 串口配置
│   │   ├── codec.py                 # HEX 编解码工具
│   │   ├── frame.py                 # SerialFrame — 数据帧模型
│   │   ├── backend.py               # SerialBackend / MockSerialBackend
│   │   └── logger.py                # 日志格式化与保存
│   │
│   ├── gui/                         # 🖥️ GUI 层
│   │   ├── __init__.py
│   │   ├── main_window.py           # 主窗口 — 窗口组装与业务流程
│   │   ├── port_widget.py           # 串口配置控件组
│   │   ├── send_widget.py           # 发送区域控件组
│   │   ├── receive_widget.py        # 接收显示控件组
│   │   └── utils.py                 # 辅助函数（端口扫描、时间戳格式化等）
│   │
│   └── main.py                      # 入口：创建 QApplication + MainWindow
│
├── tests/                           # 🧪 测试层
│   ├── __init__.py
│   ├── test_config.py               # SerialPortConfig 测试（10 用例）
│   ├── test_codec.py                # HEX 编解码测试（12 用例）
│   ├── test_frame.py                # SerialFrame 测试（8 用例）
│   ├── test_backend.py              # MockSerialBackend 测试（10 用例）
│   ├── test_logger.py               # 日志模块测试（6 用例）
│   └── test_gui_smoke.py            # GUI 冒烟测试，QT_QPA_PLATFORM=offscreen（4 用例）
│
├── docs/
│   └── analysis/
│       ├── PRD.md                   # 产品需求文档
│       ├── checklist.md             # 验收清单
│       ├── test_matrix.md           # 测试矩阵与反馈格式
│       └── file_manifest.md         # 文件清单与依赖关系
│
└── .agentflow/                      # AgentFlow 工作流配置（自动生成）
    └── flow.json
```

---

## 附录 A：文件大小参考

| 文件 | 预估行数 | 备注 |
|------|---------|------|
| core/config.py | 40-60 | 数据类 + 校验逻辑 |
| core/codec.py | 50-80 | 编解码函数 |
| core/frame.py | 40-60 | 数据类 + 格式化 |
| core/backend.py | 80-120 | 抽象基类 + Mock 实现 + 工厂 |
| core/logger.py | 30-50 | 格式化 + 文件写入 |
| gui/utils.py | 30-50 | 端口扫描 + 时间戳 |
| gui/port_widget.py | 80-120 | 配置控件组 |
| gui/send_widget.py | 60-100 | 发送控件组 |
| gui/receive_widget.py | 80-120 | 接收控件组 |
| gui/main_window.py | 150-200 | 主窗口编排 |
| main.py | 15-25 | 入口 |
| tests/*.py | 各 50-120 | 测试用例 |

**预估总计：约 2200-2700 行**

---

## 附录 B：异常场景处理

| 场景 | 检测时机 | 处理方式 |
|------|----------|----------|
| 空配置打开串口 | 点击打开时 | 校验失败→状态栏提示 |
| 串口被占用 | 调用 backend.open() | 返回 False→弹错误对话框 |
| HEX 输入非法 | 点击发送时 | codec.hex_to_bytes() 返回错误→弹警告→不清空输入框 |
| 串口未打开时发送 | 点击发送时 | 检查 is_open()→状态栏提示"串口未打开" |
| 保存日志路径无权限 | 保存时 | save_log 返回 False→弹 critical 对话框 |
| PyQt5 未安装 | import 时 | gui smoke 测试 skip，core 测试正常运行 |
| 接收超时 | QTimer 触发时 | receive() 返回 None→跳过本次轮询 |
