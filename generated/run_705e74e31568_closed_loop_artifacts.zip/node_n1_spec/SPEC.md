# PyQt 串口调试助手 — 技术规格说明书 (SPEC)

## 1. 项目概述

基于 PyQt5 的串口调试助手，核心逻辑与 GUI 彻底解耦，支持 MOCK 模式自测。通过 AgentFlow 编排实现**闭环**反馈开发流程：开发 → 测试 → 审查 → 返修 → 再测试，直至全部通过。

## 2. 核心逻辑模块

### 2.1 SerialPortConfig (config.py)

不可变数据类，存储串口参数并提供校验。

| 字段 | 类型 | 默认值 | 合法范围 |
|------|------|--------|----------|
| port | str | "" | 非空字符串 |
| baudrate | int | 9600 | 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600 |
| data_bits | int | 8 | 5, 6, 7, 8 |
| stop_bits | float | 1.0 | 1.0, 1.5, 2.0 |
| parity | str | "N" | "N"(无), "E"(偶), "O"(奇), "S"(空格), "M"(标记) |

**方法：** `validate()` → `tuple[bool, str]`

### 2.2 SerialFrame (frame.py)

表示一帧收发数据。

| 字段 | 类型 | 说明 |
|------|------|------|
| data | bytes | 原始数据 |
| timestamp | float | Unix 时间戳 |
| direction | str | "TX" / "RX" |
| hex_mode | bool | 是否为 HEX 模式 |

**方法：** `formatted()`, `hex_str()`, `text_str()`

### 2.3 HEX 编解码 (codec.py)

| 函数 | 签名 | 说明 |
|------|------|------|
| `hex_to_bytes(s: str) -> tuple[bytes, str]` | HEX字符串→(数据,错误信息) | 忽略空白/0x前缀；奇数长度/非法字符时报错 |
| `bytes_to_hex(data: bytes) -> str` | 字节→大写HEX字符串 | 如 `b'\x0A\x1B'` → `"0A 1B"` |
| `is_valid_hex(s: str) -> bool` | 判断是否为合法HEX输入 | |

**HEX 错误处理：**
- 非法字符 → `(b"", "包含非法字符")`
- 奇数长度 → `(b"", "HEX 字符串长度不能为奇数")`

### 2.4 SerialBackend / MockSerialBackend (backend.py)

- `MOCK_SERIAL=1` 时使用 MockSerialBackend
- MockSerialBackend 提供 `inject_rx(data)` 用于测试注入

### 2.5 日志模块 (logger.py)

- `format_frame(frame) -> str`
- `save_log(frames, path) -> bool`
- 日志格式：`[时间戳] TX/RX: 数据`

## 3. GUI 规格

### 3.1 控件清单

| ID | 控件 | 说明 |
|----|------|------|
| C01 | QComboBox | 端口选择 |
| C02 | QComboBox | 波特率 |
| C03 | QComboBox | 数据位 |
| C04 | QComboBox | 停止位 |
| C05 | QComboBox | 校验位 |
| C06 | QPushButton | 打开/关闭串口 |
| C07 | QPushButton | 刷新端口 |
| C08 | QCheckBox | HEX 模式发送 |
| C09 | QCheckBox | 追加换行 |
| C10 | QPushButton | 发送按钮 |
| C11 | QPlainTextEdit | 发送输入框 |
| C12 | QCheckBox | 显示时间戳 |
| C13 | QCheckBox | 自动滚屏 |
| C14 | QPushButton | 清空接收区 |
| C15 | QPushButton | 保存日志 |
| C16 | QPlainTextEdit | 接收显示区(只读) |

### 3.2 交互规则

| 操作 | 行为 |
|------|------|
| 打开串口 | 校验配置 → backend.open() → 切换按钮文字，禁用配置控件 |
| 关闭串口 | backend.close() → 恢复按钮和控件 |
| 发送(文本) | 读取文本 → 编码 → backend.send() |
| 发送(HEX) | 读取文本 → hex_to_bytes() → 解析失败弹警告 → backend.send() |
| 接收循环 | QTimer 定时 backend.receive() → 构造 SerialFrame → 添加到接收区 |
| 保存日志 | QFileDialog → save_log() |

## 4. 闭环反馈流程

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│  开发节点  │ ──→ │  测试节点  │ ──→ │  审查节点  │
│ (develop) │     │  (test)  │     │ (review) │
└──────────┘     └──────────┘     └──────────┘
      ↑                 │               │
      │                 │  失败+反馈     │
      └─────────────────┴───────────────┘
```

**反馈格式：**
```json
{
  "feedback": [
    {"file": "path", "test": "test_name", "line": 42,
     "assertion": "...", "actual": "...", "error_type": "AssertionError"}
  ],
  "summary": "N/M tests failed",
  "passed": N, "failed": M, "total": T
}
```

## 5. 测试矩阵

| 测试文件 | 用例数 | P0/P1 |
|----------|--------|-------|
| tests/test_config.py | 10 | 7/3 |
| tests/test_codec.py | 12 | 8/4 |
| tests/test_frame.py | 8 | 6/2 |
| tests/test_backend.py | 10 | 8/2 |
| tests/test_logger.py | 6 | 4/2 |
| tests/test_gui_smoke.py | 4 | 4/0 |
| **合计** | **50** | **37/13** |

## 6. 文件清单

```
serial-debug-tool/
├── SPEC.md                    # 本文件
├── requirements.txt
├── src/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py          # SerialPortConfig
│   │   ├── codec.py           # HEX 编解码
│   │   ├── frame.py           # SerialFrame
│   │   ├── backend.py         # SerialBackend / MockSerialBackend
│   │   └── logger.py          # 日志格式化/保存
│   ├── gui/
│   │   ├── __init__.py
│   │   ├── main_window.py     # 主窗口
│   │   ├── port_widget.py     # 串口配置控件
│   │   ├── send_widget.py     # 发送控件
│   │   ├── receive_widget.py  # 接收控件
│   │   └── utils.py           # 辅助函数
│   └── main.py                # 入口
├── tests/
│   ├── __init__.py
│   ├── test_config.py
│   ├── test_codec.py
│   ├── test_frame.py
│   ├── test_backend.py
│   ├── test_logger.py
│   └── test_gui_smoke.py      # 使用 QT_QPA_PLATFORM=offscreen
└── docs/
    └── analysis/
        ├── PRD.md
        ├── checklist.md
        ├── test_matrix.md
        └── file_manifest.md
```

## 7. MOCK 模式规格

```python
import os
backend = MockSerialBackend() if os.environ.get("MOCK_SERIAL") == "1" else SerialBackend()
```

MockSerialBackend 行为：
- `open(valid_config)` → `True`, `is_open()` → `True`
- `open(invalid_config)` → `False`
- `send(data)` → 追加到 `sent_log`
- `receive(timeout)` → 从 `rx_queue` pop，无数据返回 None
- `inject_rx(data)` → 向 rx_queue 注入测试数据
- `reset()` → 清空所有缓存

## 8. 覆盖率目标

| 模块 | 行覆盖率 | 分支覆盖率 |
|------|---------|-----------|
| core/config.py | 100% | 100% |
| core/codec.py | 100% | 100% |
| core/frame.py | 95%+ | 90%+ |
| core/backend.py | 95%+ | 90%+ |
| core/logger.py | 95%+ | 90%+ |
| **总体** | **90%+** | **85%+** |

## 9. 环境要求

| 依赖 | 版本 | 用途 |
|------|------|------|
| Python | >= 3.10 | 运行时 |
| PyQt5 | >= 5.15 | GUI |
| pyserial | >= 3.5 | 串口通信 |
| pytest | >= 7.4 | 测试框架 |
| pytest-cov | >= 4.1 | 覆盖率 |
