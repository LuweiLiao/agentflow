# 测试矩阵

## 测试文件结构

| 测试文件 | 测试类 | 覆盖模块 | 用例数 | P0/P1 |
|----------|--------|----------|--------|-------|
| `tests/test_config.py` | `TestSerialPortConfig` | `core.config` | 10 | 7/3 |
| `tests/test_codec.py` | `TestHexCodec` | `core.codec` | 12 | 8/4 |
| `tests/test_frame.py` | `TestSerialFrame` | `core.frame` | 8 | 6/2 |
| `tests/test_backend.py` | `TestMockSerialBackend` | `core.backend` | 10 | 8/2 |
| `tests/test_logger.py` | `TestLogger` | `core.logger` | 6 | 4/2 |
| `tests/test_gui_smoke.py` | `TestGuiSmoke` | `gui.*` | 4 | 4/0 |
| **合计** | | | **50** | **37/13** |

---

## 详细测试用例

### test_config.py — TestSerialPortConfig (10 用例)

| # | 用例名 | 输入 | 预期结果 | P0/P1 |
|---|--------|------|----------|-------|
| 1 | `test_valid_config` | port="COM1", baudrate=115200, data_bits=8, stop_bits=1.0, parity="N" | `(True, "")` | P0 |
| 2 | `test_empty_port` | port="", baudrate=9600, ... | `(False, "端口号不能为空")` | P0 |
| 3 | `test_invalid_baudrate` | baudrate=12345 | `(False, "非法波特率")` | P0 |
| 4 | `test_invalid_data_bits` | data_bits=9 | `(False, "非法数据位")` | P0 |
| 5 | `test_invalid_stop_bits` | stop_bits=2.5 | `(False, "非法停止位")` | P0 |
| 6 | `test_invalid_parity` | parity="X" | `(False, "非法校验位")` | P0 |
| 7 | `test_immutable` | 尝试修改 config.port | `AttributeError` | P0 |
| 8 | `test_all_baudrates` | 遍历所有合法波特率 | 全部通过 | P1 |
| 9 | `test_all_parities` | 遍历所有合法校验位 | 全部通过 | P1 |
| 10 | `test_valid_stop_bits_all` | stop_bits=1.0/1.5/2.0 | 全部通过 | P1 |

### test_codec.py — TestHexCodec (12 用例)

| # | 用例名 | 输入 | 预期结果 | P0/P1 |
|---|--------|------|----------|-------|
| 1 | `test_hex_to_bytes_normal` | "0A 1B 2C" | `(b'\x0a\x1b\x2c', "")` | P0 |
| 2 | `test_hex_to_bytes_no_space` | "0A1B2C" | `(b'\x0a\x1b\x2c', "")` | P0 |
| 3 | `test_hex_to_bytes_lowercase` | "0a1b2c" | `(b'\x0a\x1b\x2c', "")` | P0 |
| 4 | `test_hex_to_bytes_with_0x` | "0x0A 0x1B" | `(b'\x0a\x1b', "")` | P0 |
| 5 | `test_hex_to_bytes_invalid_char` | "GG" | `(b"", "包含非法字符")` | P0 |
| 6 | `test_hex_to_bytes_odd_length` | "A" | `(b"", "奇数长度")` | P0 |
| 7 | `test_hex_to_bytes_empty` | "" | `(b"", "")` | P1 |
| 8 | `test_hex_to_bytes_mixed_spaces` | " 0A  1B " | `(b'\x0a\x1b', "")` | P1 |
| 9 | `test_bytes_to_hex` | b'\x0a\x1b\x2c' | `"0A 1B 2C"` | P0 |
| 10 | `test_bytes_to_hex_empty` | b'' | `""` | P1 |
| 11 | `test_is_valid_hex_true` | "0A 1B 2C" | `True` | P0 |
| 12 | `test_is_valid_hex_false` | "XYZ" | `False` | P0 |

### test_frame.py — TestSerialFrame (8 用例)

| # | 用例名 | 输入 | 预期结果 | P0/P1 |
|---|--------|------|----------|-------|
| 1 | `test_create_text_frame` | data=b"Hello", direction="TX" | frame.data == b"Hello", frame.direction == "TX" | P0 |
| 2 | `test_create_hex_frame` | data=b'\x0a\x1b', direction="RX", hex_mode=True | frame.hex_mode == True | P0 |
| 3 | `test_invalid_direction` | direction="XX" | 抛出 ValueError | P0 |
| 4 | `test_formatted_text_tx` | data=b"Hello", dir="TX", hex=False | 包含 "TX: Hello" | P0 |
| 5 | `test_formatted_hex_rx` | data=b'\x0a\x1b', dir="RX", hex=True | 包含 "RX: 0A 1B" | P0 |
| 6 | `test_hex_str` | data=b'\x00\xff' | `"00 FF"` | P0 |
| 7 | `test_text_str_ascii` | data=b"Hello" | `"Hello"` | P1 |
| 8 | `test_text_str_non_ascii` | data=b'\x00\x01\x02' | 不崩溃，返回可读字符串 | P1 |

### test_backend.py — TestMockSerialBackend (10 用例)

| # | 用例名 | 输入 | 预期结果 | P0/P1 |
|---|--------|------|----------|-------|
| 1 | `test_open_valid` | 合法配置 | `True`, `is_open()` == True | P0 |
| 2 | `test_open_invalid` | 非法配置 | `False`, `is_open()` == False | P0 |
| 3 | `test_close` | 先 open 后 close | `is_open()` == False | P0 |
| 4 | `test_send` | send(b"Hello") | sent_log == [b"Hello"] | P0 |
| 5 | `test_receive_no_data` | 无注入数据 | `None` | P0 |
| 6 | `test_receive_with_data` | inject_rx(b"OK") → receive() | b"OK" | P0 |
| 7 | `test_send_receive_roundtrip` | send+inject+receive | 发送和接收互不影响 | P0 |
| 8 | `test_multiple_receive` | inject 多条 → 多次 receive | 按 FIFO 取出 | P0 |
| 9 | `test_reset` | reset() 后 sent_log 和 rx_queue 清空 | 均为空 | P1 |
| 10 | `test_open_twice` | open → open (未 close) | 第二次返回 False 或抛出异常 | P1 |

### test_logger.py — TestLogger (6 用例)

| # | 用例名 | 输入 | 预期结果 | P0/P1 |
|---|--------|------|----------|-------|
| 1 | `test_format_text_tx` | 文本 TX 帧 | 格式 `[HH:MM:SS.mmm] TX: Hello` | P0 |
| 2 | `test_format_hex_rx` | HEX RX 帧 | 格式 `[HH:MM:SS.mmm] RX: 0A 1B` | P0 |
| 3 | `test_save_log` | 帧列表 + 临时文件路径 | 文件存在，内容正确 | P0 |
| 4 | `test_save_log_empty` | 空帧列表 | 文件存在，内容为空 | P1 |
| 5 | `test_save_log_permission_error` | 只读路径 | 返回 False | P1 |
| 6 | `test_save_log_multiple_frames` | 多帧写入 | 每行一条，顺序正确 | P0 |

### test_gui_smoke.py — TestGuiSmoke (4 用例)

| # | 用例名 | 输入 | 预期结果 | P0/P1 |
|---|--------|------|----------|-------|
| 1 | `test_import_main_window` | `from src.gui.main_window import MainWindow` | 不抛出 ImportError | P0 |
| 2 | `test_create_main_window_offscreen` | `QApplication` + MainWindow | 窗口创建成功，标题正确 | P0 |
| 3 | `test_controls_exist` | 检查各控件是否存在 | 所有控件 ID 存在 | P0 |
| 4 | `test_mock_mode_string` | 检查状态栏/标题包含 MOCK | Mock 模式下有标识 | P0 |

---

## 覆盖率目标

| 模块 | 行覆盖率目标 | 分支覆盖率目标 |
|------|-------------|---------------|
| `core/config.py` | 100% | 100% |
| `core/codec.py` | 100% | 100% |
| `core/frame.py` | 95%+ | 90%+ |
| `core/backend.py` | 95%+ | 90%+ |
| `core/logger.py` | 95%+ | 90%+ |
| `gui/*.py` | 60%+（仅 smoke） | — |
| **总体** | **90%+** | **85%+** |

---

## 失败反馈证据格式

当测试失败时，传递给开发节点的 feedback 必须包含以下结构：

```json
{
  "feedback": [
    {
      "file": "tests/test_codec.py",
      "test": "test_hex_to_bytes_invalid_char",
      "line": 42,
      "assertion": "assert result == (b'', '包含非法字符')",
      "actual": "(b'', '包含非法字符xx')",
      "error_type": "AssertionError",
      "message": "Test test_hex_to_bytes_invalid_char FAILED: expected (b'', '包含非法字符'), got (b'', '包含非法字符xx')"
    },
    {
      "file": "tests/test_backend.py",
      "test": "test_open_valid",
      "line": 18,
      "assertion": "assert backend.open(config) == True",
      "actual": "False",
      "error_type": "AssertionError",
      "message": "..."
    }
  ],
  "summary": "2/50 tests failed: test_codec.py#42, test_backend.py#18",
  "passed": 48,
  "failed": 2,
  "total": 50
}
```
