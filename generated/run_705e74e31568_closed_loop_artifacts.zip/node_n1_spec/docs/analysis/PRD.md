# PyQt 串口调试助手 — 细粒度 PRD

## 1. 概述

基于 PyQt5 的串口调试助手，核心逻辑与 GUI 彻底解耦，支持 MOCK 模式自测，通过 AgentFlow 编排实现闭环开发流程。

---

## 2. 项目结构

```
serial-debug-tool/
├── src/
│   ├── __init__.py
│   ├── core/                    # 核心逻辑层（可脱离 GUI 测试）
│   │   ├── __init__.py
│   │   ├── config.py            # SerialPortConfig — 串口配置数据结构
│   │   ├── frame.py             # SerialFrame — 接收帧 / 发送帧模型
│   │   ├── backend.py           # SerialBackend / MockSerialBackend
│   │   ├── codec.py             # HEX 编解码工具
│   │   └── logger.py            # 日志格式化 / 保存
│   ├── gui/
│   │   ├── __init__.py
│   │   ├── main_window.py       # MainWindow — 主窗口
│   │   ├── port_widget.py       # 串口配置控件组
│   │   ├── send_widget.py       # 发送区域控件组
│   │   ├── receive_widget.py    # 接收显示控件组
│   │   └── utils.py             # GUI 辅助函数
│   └── main.py                  # 入口
├── tests/
│   ├── __init__.py
│   ├── test_config.py           # 配置校验测试
│   ├── test_codec.py            # HEX 编码解码测试
│   ├── test_frame.py            # 帧格式测试
│   ├── test_backend.py          # 后端（含 Mock）测试
│   ├── test_logger.py           # 日志测试
│   └── test_gui_smoke.py        # GUI 冒烟测试（offscreen）
├── docs/
│   ├── analysis/
│   │   └── PRD.md               # 本文档
│   └── review/                  # 审查记录
└── requirements.txt
```

---

## 3. 核心模块规格

### 3.1 `SerialPortConfig` (config.py)

不可变数据类，存储串口参数并提供校验。

| 字段 | 类型 | 默认值 | 合法范围 |
|------|------|--------|----------|
| port | str | "" | 非空字符串 |
| baudrate | int | 9600 | 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600 |
| data_bits | int | 8 | 5, 6, 7, 8 |
| stop_bits | float | 1.0 | 1.0, 1.5, 2.0 |
| parity | str | "N" | "N"(无), "E"(偶), "O"(奇), "S"(空格), "M"(标记) |

**校验规则：**
- `validate()` → `tuple[bool, str]` 返回 (是否合法, 错误信息)
- port 为空 → 不合法
- baudrate 不在允许列表 → 不合法
- data_bits 不在 {5,6,7,8} → 不合法
- stop_bits 不在 {1.0, 1.5, 2.0} → 不合法
- parity 不在 {"N","E","O","S","M"} → 不合法

### 3.2 `SerialFrame` (frame.py)

表示一帧收发数据。

| 字段 | 类型 | 说明 |
|------|------|------|
| data | bytes | 原始数据 |
| timestamp | float | Unix 时间戳 |
| direction | str | "TX" / "RX" |
| hex_mode | bool | 是否为 HEX 模式 |

**方法：**
- `formatted()` → str：格式化输出，如 `[12:34:56.789] TX: 0A 1B 2C` 或 `[12:34:56.789] RX: Hello`
- `hex_str()` → str：返回空格分隔的 HEX 字符串
- `text_str()` → str：返回解码后的文本（忽略无法解码的字节）

### 3.3 `SerialBackend` / `MockSerialBackend` (backend.py)

#### SerialBackend（抽象基类）
- `open(config: SerialPortConfig) -> bool`
- `close() -> bool`
- `send(data: bytes) -> bool`
- `receive(timeout: float) -> Optional[bytes]`
- `is_open() -> bool`

#### MockSerialBackend
- 环境变量 `MOCK_SERIAL=1` 时自动启用
- `open()`：记录配置并返回 True
- `close()`：重置状态
- `send(data)`：将数据存入内部 `sent_buffer`
- `receive(timeout)`：从 `mock_rx_buffer` 取出数据；若为空则返回 None
- 提供 `inject_rx(data: bytes)` 方法用于测试注入接收数据

### 3.4 `HEX 编解码` (codec.py)

| 函数 | 签名 | 说明 |
|------|------|------|
| `hex_to_bytes(s: str) -> tuple[bytes, str]` | 输入HEX字符串 → (数据, 错误信息) | 忽略空白、0x前缀；奇数长度/非法字符时报错 |
| `bytes_to_hex(data: bytes) -> str` | 字节 → 大写HEX字符串 | 如 `b'\x0A\x1B'` → `"0A 1B"` |
| `is_valid_hex(s: str) -> bool` | 判断是否为合法HEX输入 | |

**错误处理：**
- 输入含非HEX字符（0-9A-Fa-f，空格）→ 返回 `(b"", "包含非法字符")`
- 奇数长度（去除空格后）→ 返回 `(b"", "HEX 字符串长度不能为奇数")`

### 3.5 `日志模块` (logger.py)

- `format_frame(frame: SerialFrame) -> str`：格式化帧为日志行
- `save_log(frames: list[SerialFrame], path: str) -> bool`：保存日志到文件
- 日志格式：每行一个 `[时间戳] TX/RX: 数据`，HEX 模式用大写 HEX，文本模式用原始字符串
- 文件编码 UTF-8，换行符 LF

---

## 4. GUI 规格

### 4.1 主窗口布局

```
┌─────────────────────────────────────────────┐
│  串口调试助手 v1.0                           │
├─────────────────────────────────────────────┤
│  [串口配置区域]                               │
│  端口: [▼COM1]  波特率: [▼9600]  数据位: [▼8] │
│  停止位: [▼1.0]  校验位: [▼None]              │
│  [◉ 打开串口]  [刷新端口]                     │
├─────────────────────────────────────────────┤
│  [发送区域]                                   │
│  [⨁ HEX] [⨁ 追加换行]   [📤 发送]            │
│  ┌─────────────────────────────────────┐     │
│  │ 输入框 (QPlainTextEdit)              │     │
│  └─────────────────────────────────────┘     │
├─────────────────────────────────────────────┤
│  [接收区域]                                   │
│  [⨁ 时间戳] [⨁ 自动滚屏] [🧹 清空] [💾 保存日志]│
│  ┌─────────────────────────────────────┐     │
│  │ 接收显示 (QPlainTextEdit, 只读)       │     │
│  │ RX: Hello World                       │     │
│  │ 12:34:56 TX: 0A 1B 2C                │     │
│  └─────────────────────────────────────┘     │
├─────────────────────────────────────────────┤
│  状态栏: [COM1 已打开 115200 8N1]            │
└─────────────────────────────────────────────┘
```

### 4.2 控件清单

| ID | 控件类型 | 变量名 | 说明 |
|----|---------|--------|------|
| C01 | QComboBox | port_combo | 端口选择，自动扫描可用端口 |
| C02 | QComboBox | baudrate_combo | 波特率：9600,19200,38400,57600,115200,230400,460800,921600 |
| C03 | QComboBox | data_bits_combo | 数据位：5,6,7,8 |
| C04 | QComboBox | stop_bits_combo | 停止位：1.0,1.5,2.0 |
| C05 | QComboBox | parity_combo | 校验位：None(N), Even(E), Odd(O), Space(S), Mark(M) |
| C06 | QPushButton | open_close_btn | 打开/关闭串口，文字动态切换 |
| C07 | QPushButton | refresh_btn | 刷新可用端口列表 |
| C08 | QCheckBox | hex_send_cb | HEX 模式发送 |
| C09 | QCheckBox | append_newline_cb | 发送时追加换行符 \n |
| C10 | QPushButton | send_btn | 发送按钮 |
| C11 | QPlainTextEdit | send_text_edit | 发送输入框 |
| C12 | QCheckBox | show_timestamp_cb | 显示时间戳 |
| C13 | QCheckBox | auto_scroll_cb | 自动滚屏 |
| C14 | QPushButton | clear_btn | 清空接收区 |
| C15 | QPushButton | save_log_btn | 保存日志 |
| C16 | QPlainTextEdit | receive_text_edit | 接收显示区（只读） |

### 4.3 交互规则

1. **端口刷新**：点击刷新按钮 → 扫描系统串口 → 更新 port_combo 列表
2. **打开串口**：校验配置 → 调用 backend.open() → 成功则按钮变为"关闭串口"，禁用配置控件
3. **关闭串口**：调用 backend.close() → 按钮变为"打开串口"，启用配置控件
4. **发送（文本模式）**：读取输入框文本 → 若追加换行则加 \n → 编码为 bytes → backend.send()
5. **发送（HEX模式）**：读取输入框文本 → codec.hex_to_bytes() → 若解析失败则弹出警告 → backend.send()
6. **接收循环**：QTimer 定时调用 backend.receive() → 构造 SerialFrame → 追加到接收区
7. **时间戳**：勾选时每行前加 `[HH:MM:SS.mmm]`
8. **自动滚屏**：勾选时新内容自动滚动到底部
9. **保存日志**：QFileDialog 选路径 → 收集所有帧 → logger.save_log()

---

## 5. Mock 模式规格

### 5.1 启用方式

```python
import os
if os.environ.get("MOCK_SERIAL") == "1":
    backend = MockSerialBackend()
else:
    backend = SerialBackend()  # 使用 pyserial
```

### 5.2 MockSerialBackend 行为

- `open()`：校验配置，合法返回 True，非法返回 False
- `close()`：清空缓存
- `send(data)`：追加到 `sent_log: list[bytes]`
- `receive(timeout)`：从 `rx_queue: list[bytes]` pop 数据，无数据返回 None
- `inject_rx(data: bytes)`：测试用，向 rx_queue 注入数据
- `reset()`：清空所有缓存

---

## 6. 错误处理策略

| 场景 | 处理方式 |
|------|---------|
| 串口打开失败（port busy/不存在） | 状态栏显示红色错误信息，弹 QMessageBox.warning |
| 配置校验不通过 | 按钮保持禁用，状态栏显示具体错误 |
| HEX 解析失败 | QMessageBox.warning + 不清空输入框 |
| 发送失败（串口已关闭） | 状态栏提示"串口未打开" |
| 日志保存失败（路径无权限） | QMessageBox.critical |
| PyQt 未安装 | 核心逻辑测试全部跳过 GUI smoke test |
