# 验收清单

## A. 核心逻辑验收（可脱离 GUI 测试）

| 编号 | 验收项 | 验证方式 | 优先级 |
|------|--------|----------|--------|
| A01 | `SerialPortConfig` 可构造且字段不可变 | `config.port` 赋值抛出异常 | P0 |
| A02 | `SerialPortConfig.validate()` 对**合法配置**返回 `(True, "")` | 单元测试 | P0 |
| A03 | `SerialPortConfig.validate()` 对**空 port** 返回 `(False, 错误信息)` | 单元测试 | P0 |
| A04 | `SerialPortConfig.validate()` 对**非法波特率**返回 `(False, ...)` | 单元测试 | P0 |
| A05 | `SerialPortConfig.validate()` 对**非法 data_bits** 返回 `(False, ...)` | 单元测试 | P0 |
| A06 | `SerialPortConfig.validate()` 对**非法 stop_bits** 返回 `(False, ...)` | 单元测试 | P0 |
| A07 | `SerialPortConfig.validate()` 对**非法 parity** 返回 `(False, ...)` | 单元测试 | P0 |
| A08 | `hex_to_bytes("0A 1B 2C")` → `(b'\x0a\x1b\x2c', "")` | 单元测试 | P0 |
| A09 | `hex_to_bytes("0a1b2c")` → `(b'\x0a\x1b\x2c', "")` | 单元测试 | P0 |
| A10 | `hex_to_bytes("0x0A 0x1B")` → `(b'\x0a\x1b', "")`（忽略0x前缀） | 单元测试 | P0 |
| A11 | `hex_to_bytes("GG")` → `(b"", "包含非法字符")` | 单元测试 | P0 |
| A12 | `hex_to_bytes("A")` → `(b"", "奇数长度")` | 单元测试 | P0 |
| A13 | `bytes_to_hex(b'\x0a\x1b')` → `"0A 1B"` | 单元测试 | P0 |
| A14 | `is_valid_hex("0A 1B")` → `True` | 单元测试 | P0 |
| A15 | `is_valid_hex("XYZ")` → `False` | 单元测试 | P0 |
| A16 | `SerialFrame` 可构造，方向仅允许 "TX"/"RX" | 单元测试 | P0 |
| A17 | `SerialFrame.formatted()` 文本模式输出格式正确 | 单元测试 | P0 |
| A18 | `SerialFrame.formatted()` HEX 模式输出格式正确 | 单元测试 | P0 |
| A19 | `SerialFrame.hex_str()` 返回大写空格分隔 HEX | 单元测试 | P0 |
| A20 | `MockSerialBackend.open(valid_config)` → `True` | 单元测试 | P0 |
| A21 | `MockSerialBackend.open(invalid_config)` → `False` | 单元测试 | P0 |
| A22 | `MockSerialBackend.send(data)` 后数据可追溯 | 单元测试 | P0 |
| A23 | `MockSerialBackend.receive()` 返回注入的数据 | 单元测试 | P0 |
| A24 | `MockSerialBackend.receive()` 无数据时返回 `None` | 单元测试 | P0 |
| A25 | `MockSerialBackend.inject_rx()` + `receive()` 可循环读取 | 单元测试 | P0 |
| A26 | `format_frame()` 文本帧格式正确 | 单元测试 | P0 |
| A27 | `format_frame()` HEX 帧格式正确 | 单元测试 | P0 |
| A28 | `save_log()` 写入文件后可读且内容正确 | 单元测试（含临时文件） | P0 |
| A29 | `save_log()` 写入权限不足时返回 `False` | 单元测试 | P1 |

## B. GUI 验收（需 PyQt5）

| 编号 | 验收项 | 验证方式 | 优先级 |
|------|--------|----------|--------|
| B01 | `main.py` 启动不崩溃 | 手动运行 | P0 |
| B02 | 端口下拉列表显示可用串口 | 手动验证 | P0 |
| B03 | 点击"刷新"更新端口列表 | 手动验证 | P0 |
| B04 | 合法配置下点击"打开串口"成功 | 手动（Mock 模式） | P0 |
| B05 | 打开后按钮变为"关闭串口" | 手动验证 | P0 |
| B06 | 关闭后按钮恢复"打开串口" | 手动验证 | P0 |
| B07 | 文本发送：输入文本→发送→接收区显示 TX 行 | 手动验证 | P0 |
| B08 | HEX 发送：勾选 HEX→输入"0A 1B"→发送→显示 TX 行 | 手动验证 | P0 |
| B09 | HEX 非法输入弹出警告框 | 手动验证 | P0 |
| B10 | 勾选"追加换行"后发送内容带 \n | 单元测试 + 手动 | P1 |
| B11 | 接收数据显示在接收区 | Mock 注入 → 手动 | P0 |
| B12 | 勾选"时间戳"后每行带时间 | 手动验证 | P1 |
| B13 | 勾选"自动滚屏"后新内容自动滚动 | 手动验证 | P1 |
| B14 | "清空"按钮清除接收区 | 手动验证 | P0 |
| B15 | "保存日志"弹出文件选择对话框 | 手动验证 | P0 |
| B16 | 保存日志后文件内容正确 | 手动验证 + 文件检查 | P0 |
| B17 | 状态栏显示串口状态 | 手动验证 | P1 |
| B18 | 打开串口后配置控件被禁用 | 手动验证 | P1 |
| B19 | 关闭串口后配置控件恢复启用 | 手动验证 | P1 |
| B20 | `MOCK_SERIAL=1` 环境下 GUI 正常启动工作 | 手动验证 | P0 |

## C. 闭环反馈验收

| 编号 | 验收项 | 验证方式 | 优先级 |
|------|--------|----------|--------|
| C01 | 测试失败时输出具体错误证据（文件名+行号+断言信息） | Agent 编排日志 | P0 |
| C02 | 失败信息被格式化为 feedback 传递给开发节点 | workflow 流转 | P0 |
| C03 | 开发节点根据 feedback 修复后重新进入测试 | workflow 流转 | P0 |
| C04 | 所有 P0 测试通过后流程终止 | CI 风格验证 | P0 |

## D. 环境兼容验收

| 编号 | 验收项 | 验证方式 | 优先级 |
|------|--------|----------|--------|
| D01 | `pytest tests/` 全部通过（含覆盖率） | 命令执行 | P0 |
| D02 | `MOCK_SERIAL=1 python -m pytest tests/test_gui_smoke.py` 通过 | 命令执行 | P0 |
| D03 | 无 PyQt5 环境时核心逻辑测试全部通过 | pip uninstall 后测试 | P1 |
| D04 | `python src/main.py` 正常启动 GUI | 命令执行 | P0 |
