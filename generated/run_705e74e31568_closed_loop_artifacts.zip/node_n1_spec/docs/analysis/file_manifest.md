# 文件清单 & 依赖关系

## 文件总览

```
serial-debug-tool/
├── requirements.txt              # 项目依赖
├── src/
│   ├── __init__.py               # 空文件
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py             # → 被 backend.py, gui/*.py, tests/test_config.py 依赖
│   │   ├── codec.py              # → 被 gui/send_widget.py, tests/test_codec.py 依赖
│   │   ├── frame.py              # → 被 logger.py, gui/*.py, tests/test_frame.py 依赖
│   │   ├── backend.py            # → 被 gui/*.py, tests/test_backend.py 依赖
│   │   └── logger.py             # → 被 gui/main_window.py, tests/test_logger.py 依赖
│   ├── gui/
│   │   ├── __init__.py
│   │   ├── main_window.py        # → 组合 port_widget, send_widget, receive_widget
│   │   ├── port_widget.py        # → 串口配置控件（QComboBox, QPushButton）
│   │   ├── send_widget.py        # → 发送区域控件（QCheckBox, QPlainTextEdit, QPushButton）
│   │   ├── receive_widget.py     # → 接收显示控件（QCheckBox, QPlainTextEdit, QPushButton）
│   │   └── utils.py              # → 端口扫描、时间戳格式化等辅助函数
│   └── main.py                   # → 入口：创建 QApplication + MainWindow
├── tests/
│   ├── __init__.py
│   ├── test_config.py            # 依赖: src.core.config
│   ├── test_codec.py             # 依赖: src.core.codec
│   ├── test_frame.py             # 依赖: src.core.frame
│   ├── test_backend.py           # 依赖: src.core.backend (+ config)
│   ├── test_logger.py            # 依赖: src.core.logger (+ frame)
│   └── test_gui_smoke.py         # 依赖: src.gui.* (可能跳过)
└── docs/
    └── analysis/
        ├── PRD.md
        ├── checklist.md
        ├── test_matrix.md
        └── file_manifest.md      # 本文档
```

## 依赖图（按构建顺序）

```
1. config.py          ← 无内部依赖
2. codec.py           ← 无内部依赖
3. frame.py           ← 无内部依赖
4. backend.py         ← 依赖 config.py
5. logger.py          ← 依赖 frame.py
6. utils.py           ← 依赖 serial (pyserial) + codec.py
7. port_widget.py     ← 依赖 config.py, utils.py, backend.py
8. send_widget.py     ← 依赖 codec.py
9. receive_widget.py  ← 依赖 frame.py, logger.py
10. main_window.py    ← 依赖 port_widget, send_widget, receive_widget, backend, config, logger
11. main.py           ← 依赖 main_window.py
12-17. 测试文件       ← 按对应模块依赖
```

## 关键接口契约

### config.py → backend.py
```
SerialPortConfig(port, baudrate, data_bits, stop_bits, parity)
  .validate() → (bool, str)
```

### backend.py → gui/*
```
SerialBackend / MockSerialBackend
  .open(config) → bool
  .close() → bool
  .send(data: bytes) → bool
  .receive(timeout=0.1) → bytes | None
  .is_open() → bool
  .inject_rx(data: bytes) → None      # 仅 Mock
```

### codec.py → gui/send_widget.py
```
hex_to_bytes(s: str) → (bytes, str)
bytes_to_hex(data: bytes) → str
is_valid_hex(s: str) → bool
```

### frame.py → logger.py, gui/receive_widget.py
```
SerialFrame(data, timestamp, direction, hex_mode)
  .formatted() → str
  .hex_str() → str
  .text_str() → str
```

### logger.py → gui/main_window.py
```
format_frame(frame) → str
save_log(frames: list, path: str) → bool
```

## 环境要求

| 依赖 | 版本 | 用途 |
|------|------|------|
| Python | >= 3.10 | 运行时（3.12.3 已确认） |
| PyQt5 | >= 5.15 | GUI |
| PyQt5.sip | >= 12.13 | PyQt5 依赖 |
| pyserial | >= 3.5 | 真实串口通信 |
| pytest | >= 7.4 | 测试框架 |
| pytest-cov | >= 4.1 | 覆盖率报告 |
| pytest-qt | >= 4.2 | Qt 测试辅助（可选） |

## MOCK_SERIAL 环境变量行为

```
MOCK_SERIAL=1  → MockSerialBackend 激活，无需真实串口
MOCK_SERIAL=0 或未设置 → SerialBackend 使用 pyserial
```
