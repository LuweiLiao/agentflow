"""
serial_core.py — 串口调试助手核心逻辑层入口文件

本文件重新导出 src.core.serial_core 的所有公开 API，
使得可以在项目根目录直接 import 或 py_compile 使用。

使用方式：
    from serial_core import SerialPortConfig, SerialFrame, MockSerialBackend, ...
"""

from src.core.serial_core import (
    # 配置
    SerialPortConfig,
    # HEX 编解码
    hex_to_bytes,
    bytes_to_hex,
    is_valid_hex,
    # 帧
    SerialFrame,
    # 后端
    SerialBackend,
    MockSerialBackend,
    create_backend,
    # 日志
    format_frame,
    save_log,
)

__all__ = [
    "SerialPortConfig",
    "hex_to_bytes",
    "bytes_to_hex",
    "is_valid_hex",
    "SerialFrame",
    "SerialBackend",
    "MockSerialBackend",
    "create_backend",
    "format_frame",
    "save_log",
]
