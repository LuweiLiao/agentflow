"""
serial_core.py — 串口调试助手核心逻辑层

包含模块：
- SerialPortConfig    : 串口配置数据类及校验
- HEX 编解码          : hex_to_bytes / bytes_to_hex / is_valid_hex
- SerialFrame         : 收发帧数据模型
- SerialBackend / MockSerialBackend : 串口后端抽象与Mock实现
- 日志模块            : format_frame / save_log

设计原则：
- 仅依赖 Python 标准库，完全脱离 PyQt5
- 所有接口返回 (bool, str) 双值而非抛异常，便于 GUI 层友好提示
- MOCK_SERIAL=1 环境变量驱动 MockSerialBackend 切换
"""

from __future__ import annotations

import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


# =====================================================================
# 1. SerialPortConfig — 串口配置
# =====================================================================

@dataclass(frozen=True)
class SerialPortConfig:
    """串口配置参数（不可变数据类）"""
    port: str = ""
    baudrate: int = 9600
    data_bits: int = 8
    stop_bits: float = 1.0
    parity: str = "N"

    # 合法值集合
    VALID_BAUDRATES: set = frozenset({9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600})
    VALID_DATA_BITS: set = frozenset({5, 6, 7, 8})
    VALID_STOP_BITS: set = frozenset({1.0, 1.5, 2.0})
    VALID_PARITIES: set = frozenset({"N", "E", "O", "S", "M"})

    def validate(self) -> tuple[bool, str]:
        """校验配置合法性

        Returns:
            (True, "") 或 (False, "错误描述")
        """
        if not self.port or not self.port.strip():
            return False, "端口名称不能为空"

        if self.baudrate not in self.VALID_BAUDRATES:
            valid = sorted(self.VALID_BAUDRATES)
            return False, f"波特率 {self.baudrate} 无效，合法值: {valid}"

        if self.data_bits not in self.VALID_DATA_BITS:
            valid = sorted(self.VALID_DATA_BITS)
            return False, f"数据位 {self.data_bits} 无效，合法值: {valid}"

        if self.stop_bits not in self.VALID_STOP_BITS:
            valid = sorted(self.VALID_STOP_BITS)
            return False, f"停止位 {self.stop_bits} 无效，合法值: {valid}"

        if self.parity not in self.VALID_PARITIES:
            return False, f"校验位 '{self.parity}' 无效，合法值: {sorted(self.VALID_PARITIES)}"

        return True, ""

    def to_pyserial_kwargs(self) -> dict:
        """转换为 pyserial 的参数 dict（供真实串口使用）"""
        parity_map = {
            "N": "N",
            "E": "E",
            "O": "O",
            "S": "S",
            "M": "M",
        }
        return {
            "port": self.port,
            "baudrate": self.baudrate,
            "bytesize": self.data_bits,
            "stopbits": self.stop_bits,
            "parity": parity_map[self.parity],
            "timeout": 0.1,
        }


# =====================================================================
# 2. HEX 编解码
# =====================================================================

def _strip_0x_prefix(token: str) -> str:
    """移除单个 token 中的 0x/0X 前缀"""
    token = token.strip()
    if token.startswith("0x") or token.startswith("0X"):
        token = token[2:]
    return token


def _clean_hex_string(s: str) -> str:
    """清理 HEX 字符串：移除空白、0x 前缀，保留合法十六进制字符

    支持 "0A 1B 2C"、"0x0A 0x1B"、"0x0A0x1B" 等多种格式。
    """
    # 先按空白分割成 tokens
    tokens = s.strip().split()
    if not tokens:
        return ""

    # 每个 token 去掉 0x 前缀后拼接
    cleaned_parts = []
    for token in tokens:
        cleaned = _strip_0x_prefix(token)
        if cleaned:
            cleaned_parts.append(cleaned)

    return "".join(cleaned_parts)


def is_valid_hex(s: str) -> bool:
    """判断字符串是否为合法 HEX 输入

    - 允许空白字符和 0x/0X 前缀
    - 允许大写 A-F 和小写 a-f
    - 数字 0-9
    """
    if not s or not s.strip():
        return False
    cleaned = _clean_hex_string(s)
    if not cleaned:
        return False
    # 长度必须为偶数
    if len(cleaned) % 2 != 0:
        return False
    try:
        int(cleaned, 16)
        return True
    except ValueError:
        return False


def hex_to_bytes(s: str) -> tuple[bytes, str]:
    """HEX 字符串 → (bytes数据, 错误信息)

    规则:
    - 忽略空白字符和 0x/0X 前缀
    - 合法字符: 0-9, a-f, A-F
    - 非法字符 → (b"", "包含非法字符")
    - 奇数长度 → (b"", "HEX 字符串长度不能为奇数")
    - 正常返回 (bytes, "")

    Args:
        s: HEX 字符串，如 "0A 1B 2C" 或 "0x0A 0x1B" 或 "0A1B2C"

    Returns:
        (bytes, "") 成功
        (b"", "错误信息") 失败
    """
    if not s or not s.strip():
        return b"", "HEX 字符串不能为空"

    cleaned = _clean_hex_string(s)

    if not cleaned:
        return b"", "HEX 字符串不能为空"

    # 检查非法字符
    valid_chars = set("0123456789abcdefABCDEF")
    for ch in cleaned:
        if ch not in valid_chars:
            return b"", f"包含非法字符 '{ch}'"

    # 检查奇数长度
    if len(cleaned) % 2 != 0:
        return b"", "HEX 字符串长度不能为奇数"

    try:
        data = bytes.fromhex(cleaned)
        return data, ""
    except ValueError as e:
        return b"", str(e)


def bytes_to_hex(data: bytes, sep: str = " ") -> str:
    """bytes → 大写 HEX 字符串

    Args:
        data: 字节数据
        sep: 分隔符，默认空格

    Returns:
        大写 HEX 字符串，如 b"\\x0a\\x1b" → "0A 1B"
    """
    if not data:
        return ""
    return sep.join(f"{b:02X}" for b in data)


# =====================================================================
# 3. SerialFrame — 收发帧
# =====================================================================

@dataclass(frozen=True)
class SerialFrame:
    """表示一帧收发数据（不可变）"""
    data: bytes
    timestamp: float
    direction: str      # "TX" 或 "RX"
    hex_mode: bool = False

    def __post_init__(self):
        if self.direction not in ("TX", "RX"):
            raise ValueError(
                f"direction 必须为 'TX' 或 'RX'，收到: {self.direction}"
            )

    def formatted(self, show_timestamp: bool = True) -> str:
        """格式化输出

        文本模式 (hex_mode=False):
            "[12:34:56.789] TX: Hello"

        HEX 模式 (hex_mode=True):
            "[12:34:56.789] RX: 0A 1B 2C"

        Args:
            show_timestamp: 是否显示时间戳前缀

        Returns:
            格式化字符串
        """
        ts_str = ""
        if show_timestamp:
            local_time = time.localtime(self.timestamp)
            millis = int((self.timestamp - int(self.timestamp)) * 1000)
            ts_str = time.strftime("[%H:%M:%S", local_time) + f".{millis:03d}] "

        if self.hex_mode:
            data_str = self.hex_str()
        else:
            data_str = self.text_str()

        return f"{ts_str}{self.direction}: {data_str}"

    def hex_str(self) -> str:
        """返回空格分隔的大写 HEX 字符串"""
        return bytes_to_hex(self.data)

    def text_str(self) -> str:
        """解码为文本（忽略无法解码的字节）"""
        return self.data.decode("utf-8", errors="replace")

    def to_dict(self) -> dict:
        """转为可序列化字典"""
        return {
            "data_hex": self.hex_str(),
            "timestamp": self.timestamp,
            "direction": self.direction,
            "hex_mode": self.hex_mode,
        }


# =====================================================================
# 4. SerialBackend / MockSerialBackend — 串口后端
# =====================================================================

class SerialBackend(ABC):
    """串口后端抽象基类——定义操作契约"""

    @abstractmethod
    def open(self, config: SerialPortConfig) -> bool:
        """打开串口"""
        ...

    @abstractmethod
    def close(self) -> bool:
        """关闭串口"""
        ...

    @abstractmethod
    def send(self, data: bytes) -> bool:
        """发送数据"""
        ...

    @abstractmethod
    def receive(self, timeout: float = 0.1) -> Optional[bytes]:
        """接收数据，超时返回 None"""
        ...

    @abstractmethod
    def is_open(self) -> bool:
        """是否已打开"""
        ...


class MockSerialBackend(SerialBackend):
    """Mock 串口后端——用于无硬件自测

    特性:
    - sent_log: 记录所有发送数据
    - rx_queue: 接收队列 (FIFO)
    - inject_rx(data): 向接收队列注入数据
    - reset(): 清空所有缓存
    """

    def __init__(self):
        self._is_open = False
        self._config: Optional[SerialPortConfig] = None
        self.sent_log: list[bytes] = []
        self.rx_queue: list[bytes] = []

    def open(self, config: SerialPortConfig) -> bool:
        ok, _ = config.validate()
        if not ok:
            return False
        if self._is_open:
            return False  # 防止重复打开
        self._config = config
        self._is_open = True
        return True

    def close(self) -> bool:
        if not self._is_open:
            return False  # 未打开时关闭失败
        self._is_open = False
        self._config = None
        return True

    def send(self, data: bytes) -> bool:
        if not self._is_open:
            return False
        self.sent_log.append(data)
        return True

    def receive(self, timeout: float = 0.1) -> Optional[bytes]:
        if not self._is_open or not self.rx_queue:
            return None
        return self.rx_queue.pop(0)

    def is_open(self) -> bool:
        return self._is_open

    # ---- Mock 测试专用接口 ----

    def inject_rx(self, data: bytes) -> None:
        """向接收队列注入数据"""
        self.rx_queue.append(data)

    def reset(self) -> None:
        """清空所有缓存和状态"""
        self.sent_log.clear()
        self.rx_queue.clear()
        self._is_open = False
        self._config = None


def create_backend() -> SerialBackend:
    """工厂方法：根据 MOCK_SERIAL 环境变量创建对应的后端

    Returns:
        MOCK_SERIAL=1 时返回 MockSerialBackend
        否则尝试导入 RealSerialBackend（需 pyserial）
    """
    if os.environ.get("MOCK_SERIAL") == "1":
        return MockSerialBackend()

    # 真实串口后端需安装 pyserial
    try:
        import serial  # noqa: F401
        from ._real_backend import RealSerialBackend
        return RealSerialBackend()
    except ImportError:
        # 无 pyserial 时回退到 Mock
        return MockSerialBackend()


# =====================================================================
# 5. 日志模块
# =====================================================================

def format_frame(frame: SerialFrame) -> str:
    """将 SerialFrame 格式化为日志行

    格式: [HH:MM:SS.mmm] TX/RX: 数据

    Args:
        frame: 待格式化的帧

    Returns:
        格式化后的日志行字符串（不含换行符）
    """
    return frame.formatted(show_timestamp=True)


def save_log(frames: list[SerialFrame], path: str) -> bool:
    """将帧列表写入日志文件

    Args:
        frames: 帧列表
        path: 文件路径

    Returns:
        True 成功，False 失败（如权限不足）
    """
    try:
        with open(path, "w", encoding="utf-8") as f:
            for frame in frames:
                f.write(format_frame(frame) + "\n")
        return True
    except (OSError, PermissionError):
        return False
