"""
test_serial_core.py — 核心逻辑层单元测试

覆盖范围:
  - SerialPortConfig 配置校验 (10 用例)
  - HEX 编解码合法/非法输入 (12 用例)
  - SerialFrame 帧格式化 (8 用例)
  - MockSerialBackend 收发/状态 (10 用例)
  - 日志格式化和保存 (6 用例)

运行方式:
  cd <project_root>
  python -m pytest tests/test_serial_core.py -v

完全不依赖 PyQt5 / pyserial。
"""

from __future__ import annotations

import os
import sys
import tempfile
import time

# 将被测模块路径加入 sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.core.serial_core import (
    SerialPortConfig,
    SerialFrame,
    MockSerialBackend,
    create_backend,
    hex_to_bytes,
    bytes_to_hex,
    is_valid_hex,
    format_frame,
    save_log,
)


# =====================================================================
# 1. SerialPortConfig 配置校验 (10 用例)
# =====================================================================

class TestSerialPortConfig:
    """覆盖: P0 x7, P1 x3 = 10 用例"""

    # ---- P0 用例 ----

    def test_valid_default_config(self):
        """P0: 默认配置合法"""
        cfg = SerialPortConfig(port="COM1")
        ok, msg = cfg.validate()
        assert ok is True, f"默认配置应合法: {msg}"
        assert msg == ""

    def test_valid_linux_port(self):
        """P0: Linux 串口路径合法"""
        cfg = SerialPortConfig(port="/dev/ttyUSB0")
        ok, msg = cfg.validate()
        assert ok is True

    def test_valid_all_fields(self):
        """P0: 全字段合法组合"""
        cfg = SerialPortConfig(
            port="COM3", baudrate=115200, data_bits=7,
            stop_bits=1.5, parity="E"
        )
        ok, msg = cfg.validate()
        assert ok is True, f"合法组合应通过: {msg}"

    def test_invalid_port_empty(self):
        """P0: 空端口名称不合法"""
        cfg = SerialPortConfig(port="")
        ok, msg = cfg.validate()
        assert ok is False
        assert "端口名称不能为空" in msg

    def test_invalid_baudrate(self):
        """P0: 非法波特率"""
        cfg = SerialPortConfig(port="COM1", baudrate=12345)
        ok, msg = cfg.validate()
        assert ok is False
        assert "波特率" in msg

    def test_invalid_data_bits(self):
        """P0: 非法数据位"""
        cfg = SerialPortConfig(port="COM1", data_bits=9)
        ok, msg = cfg.validate()
        assert ok is False
        assert "数据位" in msg

    def test_invalid_stop_bits(self):
        """P0: 非法停止位"""
        cfg = SerialPortConfig(port="COM1", stop_bits=3.0)
        ok, msg = cfg.validate()
        assert ok is False
        assert "停止位" in msg

    # ---- P1 用例 ----

    def test_invalid_parity(self):
        """P1: 非法校验位"""
        cfg = SerialPortConfig(port="COM1", parity="X")
        ok, msg = cfg.validate()
        assert ok is False
        assert "校验位" in msg

    def test_valid_baudrate_boundary(self):
        """P1: 波特率边界值 921600"""
        cfg = SerialPortConfig(port="COM1", baudrate=921600)
        ok, msg = cfg.validate()
        assert ok is True

    def test_to_pyserial_kwargs(self):
        """P1: to_pyserial_kwargs 参数映射正确"""
        cfg = SerialPortConfig(
            port="/dev/ttyS0", baudrate=38400, data_bits=7,
            stop_bits=2.0, parity="O"
        )
        kwargs = cfg.to_pyserial_kwargs()
        assert kwargs["port"] == "/dev/ttyS0"
        assert kwargs["baudrate"] == 38400
        assert kwargs["bytesize"] == 7
        assert kwargs["stopbits"] == 2.0
        assert kwargs["parity"] == "O"
        assert kwargs["timeout"] == 0.1


# =====================================================================
# 2. HEX 编解码 (12 用例)
# =====================================================================

class TestHexCodec:
    """覆盖: P0 x8, P1 x4 = 12 用例"""

    # ---- P0 用例 ----

    def test_bytes_to_hex_empty(self):
        """P0: 空字节转 HEX"""
        assert bytes_to_hex(b"") == ""

    def test_bytes_to_hex_simple(self):
        """P0: bytes 转大写 HEX 空格分隔"""
        assert bytes_to_hex(b"\x0a\x1b") == "0A 1B"

    def test_bytes_to_hex_no_sep(self):
        """P0: bytes 转 HEX 无分隔符"""
        assert bytes_to_hex(b"\x0a\x1b", sep="") == "0A1B"

    def test_hex_to_bytes_valid_spaced(self):
        """P0: 合法空格分隔 HEX → bytes"""
        result, err = hex_to_bytes("0A 1B 2C")
        assert err == ""
        assert result == b"\x0a\x1b\x2c"

    def test_hex_to_bytes_valid_nospace(self):
        """P0: 无空格 HEX → bytes"""
        result, err = hex_to_bytes("0A1B2C")
        assert err == ""
        assert result == b"\x0a\x1b\x2c"

    def test_hex_to_bytes_with_0x_prefix(self):
        """P0: 带 0x 前缀的 HEX (支持多处 0x 前缀)"""
        result, err = hex_to_bytes("0x0A 0x1B")
        assert err == "", f"期望无错误，得到: {err}"
        assert result == b"\x0a\x1b"

    def test_hex_to_bytes_invalid_chars(self):
        """P0: 非法字符报错"""
        result, err = hex_to_bytes("0A ZZ 1B")
        assert err != ""
        assert "非法字符" in err
        assert result == b""

    def test_hex_to_bytes_odd_length(self):
        """P0: 奇数长度报错"""
        result, err = hex_to_bytes("0A1")
        assert err != ""
        assert "奇数" in err
        assert result == b""

    # ---- P1 用例 ----

    def test_is_valid_hex_valid(self):
        """P1: 合法 HEX 判断（含 0x 前缀）"""
        assert is_valid_hex("0A 1B 2C") is True
        assert is_valid_hex("0x0A 0x1B") is True
        assert is_valid_hex("FFEE") is True

    def test_is_valid_hex_invalid(self):
        """P1: 非法 HEX 判断"""
        assert is_valid_hex("") is False
        assert is_valid_hex("   ") is False
        assert is_valid_hex("0AZZ") is False
        assert is_valid_hex("A") is False  # 奇数长度

    def test_hex_to_bytes_empty(self):
        """P1: 空字符串转 bytes"""
        result, err = hex_to_bytes("")
        assert err != ""
        assert result == b""

    def test_hex_to_bytes_lowercase(self):
        """P1: 小写 HEX 输入"""
        result, err = hex_to_bytes("0a 1b 2c")
        assert err == ""
        assert result == b"\x0a\x1b\x2c"


# =====================================================================
# 3. SerialFrame 帧格式化 (8 用例)
# =====================================================================

class TestSerialFrame:
    """覆盖: P0 x6, P1 x2 = 8 用例"""

    # ---- P0 用例 ----

    def test_frame_creation_tx(self):
        """P0: 创建 TX 帧"""
        ts = 1234567890.0
        frame = SerialFrame(data=b"Hello", timestamp=ts, direction="TX")
        assert frame.data == b"Hello"
        assert frame.direction == "TX"
        assert frame.hex_mode is False

    def test_frame_creation_rx(self):
        """P0: 创建 RX 帧"""
        frame = SerialFrame(data=b"World", timestamp=0.0, direction="RX")
        assert frame.direction == "RX"

    def test_frame_invalid_direction(self):
        """P0: 非法 direction 抛出 ValueError"""
        try:
            SerialFrame(data=b"", timestamp=0.0, direction="INVALID")
            assert False, "应抛出 ValueError"
        except ValueError as e:
            assert "direction" in str(e)

    def test_frame_timestamp_sequence(self):
        """P0: 两帧时间戳先后关系"""
        t1 = 1000.0
        t2 = 2000.0
        f1 = SerialFrame(data=b"A", timestamp=t1, direction="TX")
        f2 = SerialFrame(data=b"B", timestamp=t2, direction="RX")
        assert f2.timestamp > f1.timestamp

    def test_frame_hex_str(self):
        """P0: hex_str 输出"""
        frame = SerialFrame(data=b"\x0a\x1b\x2c", timestamp=0.0, direction="TX")
        assert frame.hex_str() == "0A 1B 2C"

    def test_frame_text_str(self):
        """P0: text_str 输出"""
        frame = SerialFrame(data=b"Hello", timestamp=0.0, direction="RX")
        assert frame.text_str() == "Hello"

    # ---- P1 用例 ----

    def test_frame_formatted_text(self):
        """P1: 文本模式 formatted 输出格式"""
        ts = 3600.0  # 01:00:00.000
        frame = SerialFrame(data=b"Test", timestamp=ts, direction="TX", hex_mode=False)
        result = frame.formatted(show_timestamp=True)
        # 格式: [01:00:00.000] TX: Test
        assert "TX:" in result
        assert "Test" in result
        assert result.startswith("[")

    def test_frame_formatted_hex(self):
        """P1: HEX 模式 formatted 输出"""
        ts = 3600.0
        frame = SerialFrame(data=b"\x0a\x0b", timestamp=ts, direction="RX", hex_mode=True)
        result = frame.formatted(show_timestamp=True)
        assert "RX:" in result
        assert "0A 0B" in result

    def test_frame_formatted_no_timestamp(self):
        """P1: 不显示时间戳"""
        frame = SerialFrame(data=b"hello", timestamp=0.0, direction="TX")
        result = frame.formatted(show_timestamp=False)
        assert result.startswith("TX:")
        assert "[" not in result

    def test_frame_to_dict(self):
        """P1: to_dict 序列化"""
        frame = SerialFrame(data=b"\x01\x02", timestamp=100.0, direction="RX", hex_mode=True)
        d = frame.to_dict()
        assert d["data_hex"] == "01 02"
        assert d["timestamp"] == 100.0
        assert d["direction"] == "RX"
        assert d["hex_mode"] is True


# =====================================================================
# 4. MockSerialBackend 收发/状态 (10 用例)
# =====================================================================

class TestMockSerialBackend:
    """覆盖: P0 x8, P1 x2 = 10 用例"""

    # ---- P0 用例 ----

    def test_open_valid_config(self):
        """P0: 合法配置打开成功"""
        backend = MockSerialBackend()
        cfg = SerialPortConfig(port="COM1")
        assert backend.open(cfg) is True
        assert backend.is_open() is True

    def test_open_invalid_config(self):
        """P0: 非法配置打开失败"""
        backend = MockSerialBackend()
        cfg = SerialPortConfig(port="")  # 空端口
        assert backend.open(cfg) is False
        assert backend.is_open() is False

    def test_double_open_fails(self):
        """P0: 重复打开失败"""
        backend = MockSerialBackend()
        cfg = SerialPortConfig(port="COM1")
        assert backend.open(cfg) is True
        assert backend.open(cfg) is False  # 重复打开

    def test_close(self):
        """P0: 正常关闭"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM1"))
        assert backend.close() is True
        assert backend.is_open() is False

    def test_send_when_open(self):
        """P0: 已打开时发送成功"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM1"))
        assert backend.send(b"hello") is True
        assert backend.sent_log == [b"hello"]

    def test_send_when_closed(self):
        """P0: 未打开时发送失败"""
        backend = MockSerialBackend()
        assert backend.send(b"hello") is False

    def test_receive_with_data(self):
        """P0: 有数据时 receive 返回数据"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM1"))
        backend.inject_rx(b"data1")
        backend.inject_rx(b"data2")
        assert backend.receive() == b"data1"
        assert backend.receive() == b"data2"

    def test_receive_no_data(self):
        """P0: 无数据时 receive 返回 None"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM1"))
        assert backend.receive() is None

    # ---- P1 用例 ----

    def test_inject_rx_fifo_order(self):
        """P1: 注入数据 FIFO 顺序"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM1"))
        backend.inject_rx(b"first")
        backend.inject_rx(b"second")
        backend.inject_rx(b"third")
        assert backend.receive() == b"first"
        assert backend.receive() == b"second"
        assert backend.receive() == b"third"
        assert backend.receive() is None

    def test_reset_clears_all(self):
        """P1: reset 清空所有状态"""
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM1"))
        backend.send(b"test")
        backend.inject_rx(b"rx")
        backend.reset()
        assert backend.is_open() is False
        assert backend.sent_log == []
        assert backend.rx_queue == []
        assert backend.receive() is None

    def test_close_when_not_open(self):
        """P1: 未打开时 close 返回 False"""
        backend = MockSerialBackend()
        assert backend.close() is False


# =====================================================================
# 5. 日志模块 (6 用例)
# =====================================================================

class TestLogger:
    """覆盖: P0 x4, P1 x2 = 6 用例"""

    # ---- P0 用例 ----

    def test_format_frame_text(self):
        """P0: 文本帧格式化"""
        ts = 3600.0  # 01:00:00.000
        frame = SerialFrame(data=b"Hello", timestamp=ts, direction="TX")
        result = format_frame(frame)
        assert "TX:" in result
        assert "Hello" in result
        assert result.startswith("[")

    def test_format_frame_hex(self):
        """P0: HEX 帧格式化"""
        ts = 3661.0  # 01:01:01.000
        frame = SerialFrame(data=b"\x0a\x0b", timestamp=ts, direction="RX", hex_mode=True)
        result = format_frame(frame)
        assert "RX:" in result
        assert "0A 0B" in result

    def test_save_log_success(self):
        """P0: save_log 成功写入"""
        frames = [
            SerialFrame(data=b"line1", timestamp=0.0, direction="TX"),
            SerialFrame(data=b"line2", timestamp=1.0, direction="RX"),
        ]
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".log") as f:
            tmp_path = f.name

        try:
            result = save_log(frames, tmp_path)
            assert result is True

            with open(tmp_path, "r", encoding="utf-8") as f:
                content = f.read()
            lines = content.strip().split("\n")
            assert len(lines) == 2
            assert "TX:" in lines[0]
            assert "RX:" in lines[1]
            assert "line1" in lines[0]
            assert "line2" in lines[1]
        finally:
            os.unlink(tmp_path)

    def test_save_log_empty_list(self):
        """P0: 空帧列表保存为空文件"""
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".log") as f:
            tmp_path = f.name

        try:
            result = save_log([], tmp_path)
            assert result is True
            with open(tmp_path, "r", encoding="utf-8") as f:
                content = f.read()
            assert content == ""
        finally:
            os.unlink(tmp_path)

    # ---- P1 用例 ----

    def test_save_log_invalid_path(self):
        """P1: 无效路径返回 False"""
        result = save_log([], "/nonexistent_dir/xyz.log")
        assert result is False

    def test_save_log_multiple_frames(self):
        """P1: 多帧顺序保存"""
        frames = [
            SerialFrame(data=b"A", timestamp=0.0 + i, direction="TX" if i % 2 == 0 else "RX")
            for i in range(10)
        ]
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".log") as f:
            tmp_path = f.name

        try:
            result = save_log(frames, tmp_path)
            assert result is True
            with open(tmp_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            assert len(lines) == 10
        finally:
            os.unlink(tmp_path)


# =====================================================================
# 6. 工厂方法 / MOCK_SERIAL 环境变量
# =====================================================================

class TestCreateBackend:
    """覆盖: create_backend 工厂方法 (2 用例)"""

    def test_create_backend_mock_env(self):
        """P0: MOCK_SERIAL=1 时创建 MockSerialBackend"""
        old_val = os.environ.get("MOCK_SERIAL")
        os.environ["MOCK_SERIAL"] = "1"
        try:
            backend = create_backend()
            assert isinstance(backend, MockSerialBackend)
        finally:
            if old_val is None:
                del os.environ["MOCK_SERIAL"]
            else:
                os.environ["MOCK_SERIAL"] = old_val

    def test_create_backend_default_no_pyserial(self):
        """P0: 无 MOCK_SERIAL 且无 pyserial 时自动回退 Mock"""
        old_val = os.environ.get("MOCK_SERIAL")
        if "MOCK_SERIAL" in os.environ:
            del os.environ["MOCK_SERIAL"]
        try:
            backend = create_backend()
            # 由于没有 pyserial，应回退到 MockSerialBackend
            assert isinstance(backend, MockSerialBackend)
        finally:
            if old_val is not None:
                os.environ["MOCK_SERIAL"] = old_val


# =====================================================================
# 7. 集成测试 — 完整收发流程 (2 用例)
# =====================================================================

class TestIntegration:
    """P1: 核心层集成场景"""

    def test_full_tx_rx_cycle(self):
        """模拟完整 TX → RX 流程"""
        backend = MockSerialBackend()
        cfg = SerialPortConfig(port="COM1", baudrate=115200)
        assert backend.open(cfg) is True

        # TX: 发送数据
        tx_data = b"AT+OK\r\n"
        assert backend.send(tx_data) is True
        assert backend.sent_log == [tx_data]

        # RX: 注入并接收回显
        rx_data = b"OK\r\n"
        backend.inject_rx(rx_data)
        received = backend.receive()
        assert received == rx_data

        # 构造帧并验证
        tx_frame = SerialFrame(data=tx_data, timestamp=time.time(), direction="TX")
        rx_frame = SerialFrame(data=received, timestamp=time.time(), direction="RX")
        assert tx_frame.direction == "TX"
        assert rx_frame.direction == "RX"
        assert tx_frame.data == tx_data
        assert rx_frame.data == rx_data

    def test_save_and_load_log(self):
        """保存帧到日志并可读"""
        frames = [
            SerialFrame(data=b"START", timestamp=1000.0, direction="TX"),
            SerialFrame(data=b"DATA", timestamp=1001.0, direction="RX"),
            SerialFrame(data=b"END", timestamp=1002.0, direction="TX"),
        ]
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".log") as f:
            tmp_path = f.name
        try:
            assert save_log(frames, tmp_path) is True
            with open(tmp_path, "r", encoding="utf-8") as f:
                lines = f.read().strip().split("\n")
            assert len(lines) == 3
            for i, frame in enumerate(frames):
                assert frame.data.decode() in lines[i]
        finally:
            os.unlink(tmp_path)
