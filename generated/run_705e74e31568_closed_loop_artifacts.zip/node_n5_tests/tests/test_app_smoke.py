"""
test_app_smoke.py — 整应用冒烟测试（App-Level Smoke Test）

覆盖范围（闭环验证）：
  1. 模块导入测试（app + serial_core）
  2. 核心逻辑可单元测试（不依赖 PyQt5）
  3. PyQt5 缺失时降级导入测试
  4. GUI offscreen 控件实例化（PortWidget / SendWidget / ReceiveWidget）
  5. 主窗口创建与 Mock 模式端到端收发
  6. 日志保存功能
  7. HEX 模式发送/接收验证

运行方式：
  # 核心逻辑测试（无 PyQt5 也可运行）
  python -m pytest tests/test_app_smoke.py::TestImportSmoke tests/test_app_smoke.py::TestCoreSmoke -v

  # GUI 冒烟测试（需 PyQt5 + offscreen）
  QT_QPA_PLATFORM=offscreen MOCK_SERIAL=1 python -m pytest tests/test_app_smoke.py -v

设计原则：
  - 测试不启动阻塞事件循环
  - 不依赖真实串口硬件
  - 任何时候创建 QWidget 前必须存在 QApplication 实例
  - 失败时输出详细证据
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
import traceback

# 将被测模块路径加入 sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ---- PyQt5 可用性检测 ----
try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QGroupBox, QComboBox,
        QPushButton, QCheckBox, QPlainTextEdit,
    )
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False


def ensure_qapp():
    """获取或创建 QApplication 单例（创建 Qt 控件前必须调用）"""
    if not PYQT5_AVAILABLE:
        return None
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    return app


# =====================================================================
# 1. 模块导入冒烟
# =====================================================================

class TestImportSmoke:
    """覆盖：app.py 和 serial_core.py 模块级导入"""

    def test_import_app_module(self):
        """P0: app.py 模块可导入"""
        import app as app_module
        assert app_module is not None
        assert hasattr(app_module, 'MainWindow')
        assert hasattr(app_module, 'PortWidget')
        assert hasattr(app_module, 'SendWidget')
        assert hasattr(app_module, 'ReceiveWidget')
        assert hasattr(app_module, 'create_test_app')

    def test_import_serial_core_module(self):
        """P0: serial_core.py 模块可导入"""
        import serial_core as sc
        assert sc is not None
        assert hasattr(sc, 'SerialPortConfig')
        assert hasattr(sc, 'SerialFrame')
        assert hasattr(sc, 'MockSerialBackend')
        assert hasattr(sc, 'create_backend')
        assert hasattr(sc, 'hex_to_bytes')
        assert hasattr(sc, 'bytes_to_hex')
        assert hasattr(sc, 'is_valid_hex')
        assert hasattr(sc, 'format_frame')
        assert hasattr(sc, 'save_log')

    def test_import_src_core(self):
        """P0: src.core.serial_core 可直接导入"""
        from src.core.serial_core import (
            SerialPortConfig, SerialFrame, MockSerialBackend,
            create_backend, hex_to_bytes, bytes_to_hex,
            is_valid_hex, format_frame, save_log,
        )
        assert SerialPortConfig is not None
        assert SerialFrame is not None
        assert MockSerialBackend is not None

    def test_app_exports_expected_names(self):
        """P0: app.py 导出所有 GUI 类"""
        import app
        expected = ['MainWindow', 'PortWidget', 'SendWidget',
                    'ReceiveWidget', 'create_test_app']
        for name in expected:
            assert hasattr(app, name), f"app.py 缺少导出: {name}"

    def test_serial_core_exports_all_api(self):
        """P0: serial_core.py 导出全部公开 API"""
        import serial_core
        expected = [
            'SerialPortConfig', 'SerialFrame', 'SerialBackend',
            'MockSerialBackend', 'create_backend',
            'hex_to_bytes', 'bytes_to_hex', 'is_valid_hex',
            'format_frame', 'save_log',
        ]
        for name in expected:
            assert hasattr(serial_core, name), f"serial_core.py 缺少导出: {name}"


# =====================================================================
# 2. 核心逻辑冒烟（不依赖 PyQt5）
# =====================================================================

class TestCoreSmoke:
    """覆盖：配置校验 / HEX 编解码 / 帧格式化 / Mock 后端 / 日志保存"""

    # ---- 配置校验 ----

    def test_serial_config_valid_default(self):
        """P0: 默认配置合法"""
        from src.core.serial_core import SerialPortConfig
        cfg = SerialPortConfig(port="COM1")
        ok, msg = cfg.validate()
        assert ok, f"默认配置应合法: {msg}"

    def test_serial_config_invalid_empty_port(self):
        """P0: 空端口非法"""
        from src.core.serial_core import SerialPortConfig
        cfg = SerialPortConfig(port="")
        ok, msg = cfg.validate()
        assert not ok
        assert "端口名称不能为空" in msg

    def test_serial_config_invalid_baudrate(self):
        """P0: 非法波特率"""
        from src.core.serial_core import SerialPortConfig
        cfg = SerialPortConfig(port="COM1", baudrate=9999)
        ok, msg = cfg.validate()
        assert not ok
        assert "波特率" in msg

    def test_serial_config_to_pyserial_kwargs(self):
        """P0: 转 pyserial 参数正确"""
        from src.core.serial_core import SerialPortConfig
        cfg = SerialPortConfig(port="COM1", baudrate=115200,
                               data_bits=8, stop_bits=1.0, parity="N")
        kwargs = cfg.to_pyserial_kwargs()
        assert kwargs["port"] == "COM1"
        assert kwargs["baudrate"] == 115200
        assert kwargs["bytesize"] == 8
        assert kwargs["stopbits"] == 1.0
        assert kwargs["parity"] == "N"

    # ---- HEX 编解码 ----

    def test_hex_encode_decode_roundtrip(self):
        """P0: HEX 编解码往返一致"""
        from src.core.serial_core import hex_to_bytes, bytes_to_hex
        original = b"\x01\x02\xAB\xFF"
        hex_str = bytes_to_hex(original)
        decoded, err = hex_to_bytes(hex_str)
        assert err == "", f"解码错误: {err}"
        assert decoded == original, f"往返不一致: {decoded} != {original}"

    def test_hex_invalid_chars_rejected(self):
        """P0: 非法 HEX 字符被拒绝"""
        from src.core.serial_core import hex_to_bytes
        result, err = hex_to_bytes("GG HH")
        assert err != "", "应报告非法字符错误"
        assert result == b""

    def test_hex_odd_length_rejected(self):
        """P0: 奇数长度 HEX 被拒绝"""
        from src.core.serial_core import hex_to_bytes
        result, err = hex_to_bytes("A")
        assert err != "", "应报告奇数长度错误"

    def test_hex_with_0x_prefix(self):
        """P0: 0x 前缀的 HEX 可解码"""
        from src.core.serial_core import hex_to_bytes
        result, err = hex_to_bytes("0x0A 0x1B")
        assert err == "", f"解码错误: {err}"
        assert result == b"\x0a\x1b", f"结果不符: {result}"

    def test_is_valid_hex(self):
        """P0: is_valid_hex 正确判断"""
        from src.core.serial_core import is_valid_hex
        assert is_valid_hex("0A 1B 2C")
        assert is_valid_hex("FFEE")
        assert not is_valid_hex("")
        assert not is_valid_hex("GG")
        assert not is_valid_hex("A")  # 奇数长度

    # ---- 帧格式化 ----

    def test_serial_frame_tx_rx(self):
        """P0: TX/RX 帧创建"""
        from src.core.serial_core import SerialFrame
        tx = SerialFrame(data=b"Hello", timestamp=1000.0, direction="TX")
        rx = SerialFrame(data=b"World", timestamp=1001.0, direction="RX")
        assert tx.direction == "TX"
        assert rx.direction == "RX"
        assert tx.data == b"Hello"
        assert rx.data == b"World"

    def test_serial_frame_formatted_output(self):
        """P0: 格式化输出包含方向和数据"""
        from src.core.serial_core import SerialFrame
        frame = SerialFrame(data=b"Test", timestamp=3600.0,
                           direction="TX", hex_mode=False)
        result = frame.formatted(show_timestamp=True)
        assert "TX:" in result
        assert "Test" in result
        assert result.startswith("[")

    def test_serial_frame_hex_output(self):
        """P0: HEX 模式输出 HEX 字符串"""
        from src.core.serial_core import SerialFrame
        frame = SerialFrame(data=b"\x0a\x1b", timestamp=0.0,
                           direction="RX", hex_mode=True)
        result = frame.formatted(show_timestamp=True)
        assert "RX:" in result
        assert "0A 1B" in result

    def test_serial_frame_to_dict(self):
        """P0: 帧序列化到字典"""
        from src.core.serial_core import SerialFrame
        frame = SerialFrame(data=b"\x01\x02", timestamp=100.0,
                           direction="RX", hex_mode=True)
        d = frame.to_dict()
        assert d["data_hex"] == "01 02"
        assert d["timestamp"] == 100.0
        assert d["direction"] == "RX"
        assert d["hex_mode"] is True

    # ---- Mock 后端 ----

    def test_mock_backend_open_close(self):
        """P0: Mock 后端打开/关闭"""
        from src.core.serial_core import MockSerialBackend, SerialPortConfig
        backend = MockSerialBackend()
        cfg = SerialPortConfig(port="COM_TEST")
        assert backend.open(cfg) is True
        assert backend.is_open() is True
        assert backend.close() is True
        assert backend.is_open() is False

    def test_mock_backend_send_receive(self):
        """P0: Mock 后端发送接收"""
        from src.core.serial_core import MockSerialBackend, SerialPortConfig
        backend = MockSerialBackend()
        backend.open(SerialPortConfig(port="COM_TEST"))
        assert backend.send(b"Hello") is True
        assert len(backend.sent_log) == 1
        backend.inject_rx(b"World")
        data = backend.receive()
        assert data == b"World"

    def test_mock_backend_double_open_fails(self):
        """P0: 重复打开失败"""
        from src.core.serial_core import MockSerialBackend, SerialPortConfig
        backend = MockSerialBackend()
        assert backend.open(SerialPortConfig(port="COM1")) is True
        assert backend.open(SerialPortConfig(port="COM2")) is False

    # ---- 日志保存 ----

    def test_save_log_to_file(self):
        """P0: 保存日志到文件成功"""
        from src.core.serial_core import SerialFrame, save_log
        frames = [
            SerialFrame(data=b"Hello", timestamp=1000.0, direction="TX"),
            SerialFrame(data=b"World", timestamp=1001.0, direction="RX"),
        ]
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt',
                                         delete=False) as f:
            log_path = f.name

        try:
            result = save_log(frames, log_path)
            assert result is True
            with open(log_path, 'r', encoding='utf-8') as f:
                content = f.read()
            assert "Hello" in content
            assert "World" in content
        finally:
            if os.path.exists(log_path):
                os.unlink(log_path)


# =====================================================================
# 3. PyQt5 降级测试
# =====================================================================

class TestPyQt5Fallback:
    """覆盖：PyQt5 不可用时 app.py 降级行为"""

    def test_serial_core_always_importable(self):
        """P0: serial_core 任何时候都可导入（无 PyQt5 依赖）"""
        import serial_core
        assert serial_core is not None
        from serial_core import SerialPortConfig
        cfg = SerialPortConfig(port="COM1")
        ok, _ = cfg.validate()
        assert ok

    def test_pyqt5_availability_detected(self):
        """P0: PYQT5_AVAILABLE 标志存在且为 bool"""
        import app
        assert hasattr(app, 'PYQT5_AVAILABLE')
        assert isinstance(app.PYQT5_AVAILABLE, bool)


# =====================================================================
# 4. GUI Offscreen 冒烟测试
# =====================================================================

class TestGuiOffscreenSmoke:
    """覆盖：窗口创建、控件实例化、Mock 模式收发（需 PyQt5 + offscreen）"""

    def test_create_main_window(self):
        """P0: 创建主窗口"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        window = MainWindow()
        try:
            assert window is not None
            assert isinstance(window, QMainWindow)
            assert "串口调试助手" in window.windowTitle()
        finally:
            window.close()

    def test_main_window_has_widgets(self):
        """P0: 主窗口包含核心子控件"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        window = MainWindow()
        try:
            assert hasattr(window, 'port_widget')
            assert hasattr(window, 'send_widget')
            assert hasattr(window, 'receive_widget')
            assert hasattr(window, '_backend')
            assert hasattr(window, '_frames')
        finally:
            window.close()

    def test_port_widget_instantiation(self):
        """P0: PortWidget 实例化"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import PortWidget
        from serial_core import MockSerialBackend
        backend = MockSerialBackend()
        widget = PortWidget(backend)
        try:
            assert widget is not None
            assert isinstance(widget, QGroupBox)
            assert hasattr(widget, 'port_combo')
            assert hasattr(widget, 'baudrate_combo')
            assert hasattr(widget, 'open_close_btn')
        finally:
            widget.deleteLater()

    def test_port_widget_config(self):
        """P0: PortWidget 配置读取"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import PortWidget
        from serial_core import MockSerialBackend
        backend = MockSerialBackend()
        widget = PortWidget(backend)
        try:
            widget.port_combo.setEditText("COM_TEST")
            config = widget.get_config()
            assert config.port == "COM_TEST"
            assert config.baudrate == 9600
            assert config.data_bits == 8
            assert config.stop_bits == 1.0
            assert config.parity == "N"
        finally:
            widget.deleteLater()

    def test_port_widget_open_close(self):
        """P0: PortWidget 打开/关闭串口"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import PortWidget
        from serial_core import MockSerialBackend
        backend = MockSerialBackend()
        widget = PortWidget(backend)
        try:
            widget.port_combo.setEditText("COM_MOCK")
            assert widget.is_open() is False
            widget._on_open_close_clicked()
            assert widget.is_open() is True
            assert backend.is_open() is True
            widget._on_open_close_clicked()
            assert widget.is_open() is False
            assert backend.is_open() is False
        finally:
            widget.deleteLater()

    def test_send_widget_instantiation(self):
        """P0: SendWidget 实例化"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        from app import SendWidget
        widget = SendWidget()
        try:
            assert widget is not None
            assert isinstance(widget, QGroupBox)
            assert hasattr(widget, 'hex_check')
            assert hasattr(widget, 'send_btn')
            assert hasattr(widget, 'input_edit')
        finally:
            widget.deleteLater()

    def test_receive_widget_instantiation(self):
        """P0: ReceiveWidget 实例化"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        from app import ReceiveWidget
        widget = ReceiveWidget()
        try:
            assert widget is not None
            assert isinstance(widget, QGroupBox)
            assert hasattr(widget, 'timestamp_check')
            assert hasattr(widget, 'clear_btn')
            assert hasattr(widget, 'display')
        finally:
            widget.deleteLater()

    def test_receive_widget_append_frame(self):
        """P0: ReceiveWidget 显示帧"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        from app import ReceiveWidget
        from serial_core import SerialFrame
        widget = ReceiveWidget()
        try:
            ts = 3600.0
            frame = SerialFrame(data=b"Hello World", timestamp=ts, direction="RX")
            widget.append_frame(frame)
            text = widget.get_all_text()
            assert "Hello World" in text
            assert "RX:" in text

            frame_hex = SerialFrame(data=b"\x0a\x1b", timestamp=ts,
                                    direction="TX", hex_mode=True)
            widget.append_frame(frame_hex)
            text2 = widget.get_all_text()
            assert "0A 1B" in text2
        finally:
            widget.deleteLater()

    def test_receive_widget_clear(self):
        """P0: ReceiveWidget 清空功能"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        from app import ReceiveWidget
        from serial_core import SerialFrame
        widget = ReceiveWidget()
        try:
            frame = SerialFrame(data=b"test", timestamp=0.0, direction="RX")
            widget.append_frame(frame)
            assert "test" in widget.get_all_text()
            widget.clear_display()
            assert widget.get_all_text() == ""
        finally:
            widget.deleteLater()

    def test_main_window_send_receive(self):
        """P0: 主窗口 Mock 发送/接收流程"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        from serial_core import MockSerialBackend
        backend = MockSerialBackend()
        window = MainWindow(backend=backend)
        try:
            window.port_widget._on_open_close_clicked()
            assert window._backend.is_open() is True

            window._on_send_data(b"Hello")
            assert len(window._frames) == 1
            assert window._frames[0].direction == "TX"
            assert window._frames[0].data == b"Hello"

            backend.inject_rx(b"World")
            window._poll_receive()
            assert len(window._frames) == 2
            assert window._frames[1].direction == "RX"
            assert window._frames[1].data == b"World"

            text = window.receive_widget.get_all_text()
            assert "Hello" in text
            assert "World" in text
        finally:
            window.close()

    def test_main_window_save_log(self):
        """P0: 主窗口日志保存"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        from serial_core import MockSerialBackend, save_log
        import tempfile

        backend = MockSerialBackend()
        window = MainWindow(backend=backend)
        try:
            window.port_widget._on_open_close_clicked()
            window._on_send_data(b"LOG_TEST_DATA")

            frames = window.get_frames()
            assert len(frames) >= 1

            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt',
                                             delete=False) as f:
                log_path = f.name

            result = save_log(frames, log_path)
            assert result is True

            with open(log_path, 'r', encoding='utf-8') as f:
                content = f.read()
            assert "LOG_TEST_DATA" in content
            assert "TX:" in content
        finally:
            window.close()
            if os.path.exists(log_path):
                os.unlink(log_path)

    def test_main_window_window_title(self):
        """P1: 主窗口标题"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        window = MainWindow()
        try:
            assert "串口调试助手" in window.windowTitle()
        finally:
            window.close()

    def test_send_widget_text_mode(self):
        """P1: SendWidget 文本模式发送"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        from app import SendWidget
        widget = SendWidget()
        try:
            widget.hex_check.setChecked(False)
            widget.input_edit.setPlainText("测试文本")
            text = widget.get_text()
            assert text == "测试文本"
        finally:
            widget.deleteLater()

    def test_send_empty_data(self):
        """P0: 发送空数据不报错"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        from serial_core import MockSerialBackend

        backend = MockSerialBackend()
        window = MainWindow(backend=backend)
        try:
            window.port_widget._on_open_close_clicked()
            window._on_send_data(b"")
            assert len(window._frames) == 0
        finally:
            window.close()

    def test_receive_no_data(self):
        """P0: 无接收数据时 _poll_receive 安全"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        from serial_core import MockSerialBackend

        backend = MockSerialBackend()
        window = MainWindow(backend=backend)
        try:
            window.port_widget._on_open_close_clicked()
            window._poll_receive()
            assert len(window._frames) == 0
        finally:
            window.close()

    def test_send_when_closed(self):
        """P0: 串口关闭时发送不崩溃"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        from serial_core import MockSerialBackend

        backend = MockSerialBackend()
        window = MainWindow(backend=backend)
        try:
            window._on_send_data(b"no_open")
            assert len(window._frames) == 0
        finally:
            window.close()

    def test_receive_widget_hex_frame(self):
        """P0: ReceiveWidget 显示 HEX 帧"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        from app import ReceiveWidget
        from serial_core import SerialFrame
        widget = ReceiveWidget()
        try:
            frame = SerialFrame(data=b"\x0a\x0b\x0c", timestamp=100.0,
                               direction="RX", hex_mode=True)
            widget.append_frame(frame)
            text = widget.get_all_text()
            assert "0A 0B 0C" in text
        finally:
            widget.deleteLater()

    def test_poll_receive_before_open(self):
        """P0: 串口未打开时轮询不崩溃"""
        if not PYQT5_AVAILABLE:
            return
        ensure_qapp()
        os.environ["MOCK_SERIAL"] = "1"
        from app import MainWindow
        window = MainWindow()
        try:
            window._poll_receive()
            assert True
        finally:
            window.close()
